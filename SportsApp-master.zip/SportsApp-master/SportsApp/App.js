import React from "react"
import * as Sentry from "sentry-expo"
import { SafeAreaProvider } from "react-native-safe-area-context"
import { initializeAsync } from "expo-facebook"
import { setTestDeviceIDAsync } from "expo-ads-admob"

import MainStack from "./components/routes/MainStack"

Sentry.init({
  dsn: "https://23336d7044ca4a13b49f938e39260b08@o99416.ingest.sentry.io/5708466",
  enableInExpoDevelopment: false,
  debug: false, // Set this to `false` in production.
  tracesSampleRate: 0.2,
  integrations: [
    new Sentry.Native.ReactNativeTracing()
  ]
})

// setTestDeviceIDAsync("EMULATOR")
initializeAsync("220774379983865", "Simple Workout").then((x) => console.log("init-done:" + x),
  (x) => console.log("init-failed:" + x))

export default class App extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      title: "Simple Workout",
      notes: {
        noteArray: []
      }
    }
  }

  render () {
    return (
      <SafeAreaProvider>
        <MainStack />
      </SafeAreaProvider>
    )
  }
}
