export const WeightType = {
  kg: 1,
  lb: 2
}

export const WeekDay = {
  sunday: 0,
  monday: 1
}

export const Default = {
  weightUnit: WeightType.kg,
  showPreview: false,
  autoHidePreview: false,
  showMillisec: false,
  autoCollapse: false,
  streakTarget: 1,
  streakEnable: true,
  streakStartDay: WeekDay.monday,
  streakNotificationTime: new Date(1577898000000)
}
