export const InputMode = {
  weight: 1,
  count: 2,
  timer: 4,
  stopwatch: 8
}
