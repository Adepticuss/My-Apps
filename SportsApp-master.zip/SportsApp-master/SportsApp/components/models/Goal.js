import React from "react"
import { Image } from "react-native"
import { Icon } from "react-native-elements"
import { WeightType } from "../constants/Settings"
import { getWeightIcon } from "../controllers/Icons"

export const GoalId = {
  weight: "1"
}

export function getGoalIcon (goalId, units, style) {
  if (goalId === GoalId.weight) {
    return <Image resizeMode='contain' style={style} source={getWeightIcon(units)} />
  }
}

export function createWeightGoal () {
  return {
    id: GoalId.weight,
    name: "Weight",
    icon: null,
    data: {
      goal: null,
      pastData: []
    }
  }
}

export function parseGoal (jsonText) {
  if (!jsonText) return null

  const json = JSON.parse(jsonText)
  if (!json) return null

  if (!json.id && !json.name) return null

  return {
    id: json.id,
    name: json.name,
    icon: json.icon,
    data: {
      goal: json.data?.goal,
      pastData: json.data?.pastData ?? []
    }
  }
}

export function createGoalData (value, timestamp, measure) {
  return {
    value: value,
    timestamp: timestamp,
    measure: measure
  }
}
