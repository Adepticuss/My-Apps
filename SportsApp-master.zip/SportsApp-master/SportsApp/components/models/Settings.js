import { Default } from "../constants/Settings"

export function createSettingsDefault () {
  return {
    weightUnit: Default.weightUnit,
    showMillisec: Default.showMillisec,
    autoCollapse: Default.autoCollapse,
    streak: {
      enabled: Default.streakEnable,
      target: Default.streakTarget,
      startDay: Default.streakStartDay,
      notificationTime: Default.streakNotificationTime
    }
  }
}

export function createSettings (weightUnit, showMillisec, autoCollapse, streakEnabled, streakTarget, streakStartDay, streakNotificationTime) {
  return {
    weightUnit: weightUnit,
    showMillisec: showMillisec,
    autoCollapse: autoCollapse,
    streak: {
      enabled: streakEnabled,
      target: streakTarget,
      startDay: streakStartDay,
      notificationTime: streakNotificationTime
    }
  }
}

export function parseSettings (jsonString) {
  if (!jsonString) return null

  const json = JSON.parse(jsonString)
  if (!json) return null

  if (typeof json.weightUnit === "undefined" ||
        typeof json.streak?.enabled === "undefined" ||
        typeof json.streak?.target === "undefined" ||
        typeof json.streak?.startDay === "undefined") {
    return null
  }

  return {
    weightUnit: json.weightUnit,
    showMillisec: json.showMillisec ?? Default.showMillisec,
    autoCollapse: json.autoCollapse ?? Default.autoCollapse,
    streak: {
      enabled: json.streak?.enabled,
      target: json.streak?.target,
      startDay: json.streak?.startDay,
      notificationTime: json.streak?.notificationTime ?? Default.streakNotificationTime
    }
  }
}
