import UUID from "react-native-uuid"

export function createNewStreak (target, startDay) {
  const s = {
    target: target,
    startDay: startDay
  }

  return {
    id: UUID.v4()?.substring(0, 8),
    startDate: +new Date(),
    endDate: null,
    settings: s,
    weeks: {}
  }
}

export function parseStreak (jsonString) {
  if (!jsonString) return null

  const json = JSON.parse(jsonString)
  if (!json) return null

  if (typeof json.count !== "undefined") return null
  if (!json.id ||
        !json.startDate ||
        !json.settings ||
        !json.weeks) return null

  return {
    id: json.id,
    startDate: json.startDate,
    endDate: json.endDate,
    settings: {
      target: json.settings?.target,
      startDay: json.settings?.startDay
    },
    weeks: json.weeks
  }
}

export function createWeekRecord (complete, target) {
  return {
    complete: complete,
    target: target
  }
}
