import * as Localization from "expo-localization"

export function createDefaultToken (token) {
  return {
    token: {
      value: token
    },
    time: {
      timezone: Localization.timezone
    },
    streak: {},
    language: {
      locale: Localization.locale
    }
  }
}

export function createToken (token, notificationTime, streak) {
  const base = createDefaultToken(token)

  // Setting time parameters
  if (typeof notificationTime !== "undefined") {
    const t = new Date(notificationTime)
    const notificationDateTime = new Date()
    notificationDateTime.setHours(t.getHours(), t.getMinutes())

    base.time.notificationTime = notificationDateTime
  }

  // Setting streak parameters
  if (typeof streak?.startDay !== "undefined") base.streak.startDay = streak.startDay
  if (typeof streak?.enabled !== "undefined") base.streak.enabled = streak.enabled

  return base
}

export function createStreakToken (token, complete, goal) {
  if (!token) return

  return {
    token: token,
    complete: complete,
    goal: goal
  }
}
