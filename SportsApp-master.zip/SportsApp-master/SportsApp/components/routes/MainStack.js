import React from "react"
import { StyleSheet } from "react-native"
import { NavigationContainer } from "@react-navigation/native"
import { createStackNavigator } from "@react-navigation/stack"
import * as Analytics from "expo-firebase-analytics"

import TabsScreen from "../screens/tabsScreen/TabsScreen"
import Main from "../screens/Main"
import AddExercise from "../screens/addExercise/NewAdd"
import Routine from "../screens/routine/Routine"
import Edit from "../screens/editOverview/NewEdit"
import History from "../screens/History"
import Settings from "../screens/settings/Settings"
import ExerciseDetails from "../screens/exerciseDetails/ExerciseDetails"
import Exercises from "../screens/Exercises"
// import AddExercise from '../screens/addExercise/AddExercise'
import BodyStats from "../screens/bodyStats/BodyStats"

import Fonts from "../styles/Fonts"
import { FontColor, Theme } from "../styles/Colors"

const Stack = createStackNavigator()

export default function MainStack (props) {
  return (
        <NavigationContainer onStateChange={(state) => {
          const index = state.index
          const route = state.routes[index]
          Analytics.setCurrentScreen(route.name, route.name)
        }}>
            <Stack.Navigator
                screenOptions={{
                  headerStyle: [styles.newHeader],
                  headerTitleStyle: [styles.textStyle],
                  headerLeftContainerStyle: [styles.backContainer],
                  headerTintColor: Theme.primary,
                  styles: [Fonts.default]
                }}>
                <Stack.Screen name="Start" component={TabsScreen} options={{ title: "Home", headerStyle: styles.newHeader, headerTitleStyle: styles.headerTitle }} />
                <Stack.Screen name="Home" component={Main} />
                <Stack.Screen name="CreateRoutine" component={AddExercise} options={{ title: "Create workout" }} />
                <Stack.Screen name="Routine" component={Routine} options={{ title: "Workout" }} />
                <Stack.Screen name="EditOverview" component={Edit} options={{ title: "Edit" }} />
                <Stack.Screen name="History" component={History} />
                <Stack.Screen name="Settings" component={Settings} />
                <Stack.Screen name="ExerciseDetails" component={ExerciseDetails} />
                <Stack.Screen name="Exercises" component={Exercises} />
                <Stack.Screen name="AddExercise" component={AddExercise} options={{ title: "Pick exercise" }} />
                <Stack.Screen name="BodyStats" component={BodyStats} options={{ title: "Goals" }} />
            </Stack.Navigator>
        </NavigationContainer>
  )
}

const styles = StyleSheet.create({
  headerTitle: {
    alignSelf: "flex-start",
    textAlign: "left"
  },
  newHeader: {
    backgroundColor: "#F6F6F6",
    borderWidth: 0,
    elevation: 0, // remove shadow on Android
    height: 100,
    shadowOpacity: 0 // remove shadow on iOS
  },
  textStyle: {
    color: FontColor.onBackground,
    fontSize: 20,
    fontWeight: "600",
    textAlignVertical: "center"
  }
})
