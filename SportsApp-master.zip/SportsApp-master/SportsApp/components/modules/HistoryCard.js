import React, { useState, useEffect } from "react"
import { View, StyleSheet, SectionList, FlatList, TouchableWithoutFeedback, Text } from "react-native"
import * as Analytics from "expo-firebase-analytics"

import { Icon } from "react-native-elements"

import Colors from "../styles/Colors"
import Buttons from "../styles/Buttons"
import Card from "../modules/basic/Cards"
import Storage from "../controllers/Storage"
import { getExercise } from "../controllers/ExerciseData"

export const Mode = {
  exercise: 1,
  date: 2,
  routine: 4
}

export function formatMillisecond (ms) {
  if (!ms || typeof ms !== "number") return

  const seconds = parseInt(ms / 1000)
  const minutes = parseInt(seconds / 60)

  let time = seconds % 60 + "s"
  if (minutes) {
    time = minutes + "m : " + time
  }

  return time
}

const ItemRow = ({ data }) => {
  let lw, lc, lt, le
  if (data?.weight) {
    lw = (
            <View style={[styles.cell, styles.weightCell, Buttons.centrify]}>
                <View style={styles.icon}>
                    <Icon name='weight-kilogram' color={Colors.silver} type='material-community' />
                </View>
                <Text style={[styles.number, styles.textExpanded]}>{data.weight}</Text>
            </View>)
  }

  const reps = data?.reps ?? data?.count
  if (reps) {
    lc = (
            <View style={[styles.cell, styles.countCell, Buttons.centrify]}>
                <View style={styles.icon}>
                    <Icon name='repeat' color={Colors.silver} type='material-community' />
                </View>
                <Text style={[styles.number, styles.textExpanded]}>{reps}</Text>
            </View>)
  }

  if (data?.time > 0) {
    if (typeof data.elapsed === "undefined" || data.elapsed === null) {
      lt = (
                <View style={[styles.cell, styles.countCell, Buttons.centrify]}>
                    <View style={styles.icon}>
                        <Icon name='stopwatch' type='entypo' color={Colors.silver} />
                    </View>
                    <Text style={[styles.number, styles.textExpanded]}>{formatMillisecond(data.time)}</Text>
                </View>)
    } else {
      const val = data.elapsed === 0 ? data.time : data.elapsed
      le = (
                <View style={[styles.cell, styles.countCell, Buttons.centrify]}>
                    <View style={styles.icon}>
                        <Icon name='av-timer' type='material-community' color={Colors.silver} />
                    </View>
                    <Text style={[styles.number, styles.textExpanded]}>{formatMillisecond(val)}</Text>
                </View>)
    }
  }

  if (!lw && !lc && !lt && !le) {
    return <View/>
  }

  return <View style={styles.repsRow}>{lw}{lc}{lt}{le}</View>
}

export const Item = ({ data }) => {
  const json = JSON.parse(data)

  // 1st - assume json is an array of sets
  let subitems = json

  // if not - try grabbing sets from 'reps' [legacy]
  if (!subitems?.length) subitems = subitems?.reps

  if (!subitems?.length) {
    return <View />
  }

  return (
        <View style={styles.item}>
            <FlatList data={subitems}
                        renderItem={({ item }) => <ItemRow data={item} />}
                        keyExtractor={(_, i) => i.toString()}
                        style={styles.list} />
        </View>

  )
}

const Title = ({ text, type }) => {
  const [titleText, setTitleText] = useState(text)

  useEffect(() => {
    if (type === Mode.exercise) {
      setTitleText(text)
    } else if (type === Mode.date) {
      const exercise = getExercise(text)
      if (exercise?.name) {
        setTitleText(exercise.name)
      } else {
        Storage.exercise.get(text, (val, e) => {
          if (!val) {
            setTitleText(text)
          } else {
            const j = JSON.parse(val)
            setTitleText(j?.name)
          }
        })
      }
    }
  }, [text])

  return (
        <View>
            <Text style={[styles.header, styles.textExpanded]}>{titleText}</Text>
        </View>

  )
}

export default function HistoryCard ({ name, type, data, expanded }) {
  const [expand, setExpand] = useState(false)
  const [localName, setLocalName] = useState("")
  const [last, setLast] = useState({})
  const [toLoad, setToLoad] = useState({})
  const [loaded, setLoaded] = useState([])

  useEffect(() => {
    const keys = Object.keys(data).sort((a, b) => a < b)
    const lastKey = keys[0]
    const lastItem = data[lastKey]
    setLast({ key: lastKey, item: lastItem })

    setToLoad(data)
  }, [data])

  useEffect(() => {
    setExpand(expanded ?? false)
  }, [expanded])

  useEffect(() => {
    if (type === Mode.exercise) {
      Storage.exercise.get(name, (val, e) => {
        if (!val) {
          setLocalName(name)
        } else {
          const j = JSON.parse(val)
          setLocalName(j?.name)
        }
      })
    } else {
      setLocalName(name)
    }
  }, [name])

  useEffect(() => {
    if (expand) load()
  }, [expand])

  let content
  if (expand) {
    content = (
            <View style={styles.contentExpanded}>
                <Text style={[styles.title, styles.textExpanded]}>{localName}</Text>
                <SectionList sections={loaded}
                                keyExtractor={(item, index) => item + index}
                                renderItem={({ item }) => <Item data={item} />}
                                renderSectionHeader={({ section: { title } }) => (
                                    <Title style={[styles.header, styles.textExpanded]} text={title} type={type} />
                                )} />
            </View>
    )
  } else {
    let quickInfo
    if (type === Mode.exercise) {
      quickInfo = (
                <Text style={[styles.quickInfo, styles.textBrief]}>Last workout on {last.key}, {last.item?.length} record{last.item?.length > 1 ? "s" : ""}</Text>
      )
    }

    content = (
            <View style={styles.contentBrief}>
                <Text style={[styles.title, styles.textBrief]}>{localName}</Text>
                {quickInfo}
                <View style={styles.expandIcon}>
                    <Icon name='arrow-expand' color={Colors.grey} type='material-community' />
                </View>
            </View>
    )
  }

  return (
        <TouchableWithoutFeedback onPress={() => setExpand(!expand)}>
            <View>
                <Card style={[styles.card, expand ? styles.cardExpanded : styles.cardBrief]}
                        content={content} />
            </View>
        </TouchableWithoutFeedback>
  )

  function load () {
    const keys = Object.keys(toLoad).sort((a, b) => a < b)
    if (type === Mode.exercise) {
      Analytics.logEvent("LoadExerciseHistory", { size: keys.length, name: name })
    } else if (type === Mode.date) {
      Analytics.logEvent("LoadDateHistory", { size: keys.length, name: name })
    }

    keys.forEach(key => {
      const item = toLoad[key]

      const totalCount = item?.length
      if (!(totalCount > 0)) {
        delete toLoad[key]
        return
      }

      let toLoadCount = totalCount
      const loadedItems = []

      item.forEach(subkey => {
        Storage.item.get(subkey, (history, e) => {
          if (!history) {
            toLoadCount -= 1
            updateLoaded(toLoadCount, loadedItems, key)
            return
          }

          loadedItems.push(history)

          toLoadCount -= 1
          updateLoaded(toLoadCount, loadedItems, key)
        })
      })
    })
  }

  function updateLoaded (loadCount, loadedItems, key) {
    if (loadCount === 0) {
      const data = {
        title: key,
        data: loadedItems
      }

      loaded.push(data)
      setLoaded([...loaded])
      delete toLoad[key]
    }
  }
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: 12,
    padding: 4
  },
  cardBrief: {
    backgroundColor: Colors.silver
  },
  cardExpanded: {
    backgroundColor: Colors.grey
  },
  cell: {
    backgroundColor: "black",
    borderRadius: 8,
    flex: 1,
    height: 34,
    margin: 2,
    padding: 4
  },
  contentBrief: {
    backgroundColor: Colors.silver,
    flex: 1
  },
  contentExpanded: {
    flex: 1
  },
  countCell: {
    alignSelf: "flex-end"
  },
  expandIcon: {
    bottom: 0,
    position: "absolute",
    right: 0
  },
  header: {
    fontSize: 18,
    padding: 4,
    textAlign: "center"
  },
  icon: {
    left: 8,
    position: "absolute"
  },
  item: {
    backgroundColor: Colors.alpha.medium,
    borderRadius: 8,
    margin: 4,
    padding: 2
  },
  quickInfo: {
    fontSize: 14,
    textAlign: "center"
  },
  repsRow: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  textBrief: {
    color: "black"
  },
  textExpanded: {
    color: "white"
  },
  title: {
    fontSize: 20,
    padding: 4,
    textAlign: "center"
  },
  weightCell: {
    alignSelf: "flex-start"
  }
})
