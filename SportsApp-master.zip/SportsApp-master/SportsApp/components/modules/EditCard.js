import React, { useState, useEffect } from "react"
import { View, StyleSheet, TouchableOpacity, Text } from "react-native"
import { Icon } from "react-native-elements"

import Card from "../modules/basic/Cards"
import { InputMode } from "../constants/Input"

import Colors from "../styles/Colors"

export const EditCardType = {
  current: 1,
  new: 2,
  remove: 3
}

const _defaultType = InputMode.count | InputMode.weight

export default function EditCard ({ exercise, type, click, removeClick, typeClick, drag, isActive }) {
  const [cardName, setCardName] = useState("")
  const [eType, setEType] = useState(_defaultType)

  useEffect(() => {
    if (exercise) {
      setCardName(exercise.name ?? exercise.text)
      setEType(exercise.type ?? _defaultType)
    }
  }, [exercise])

  const body = (<Text style={styles.exerciseText}>{cardName}</Text>)

  const buttonText = type === EditCardType.remove ? "<" : "X"

  const typeIcons = []
  if (eType & InputMode.count) {
    typeIcons.push(<Icon key={"reps"} name='repeat' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />)
  }
  if (eType & InputMode.weight) {
    typeIcons.push(<Icon key={"weight"} name='weight' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />)
  }
  if (eType & InputMode.timer) {
    typeIcons.push(<Icon key={"stopwatch"} name='av-timer' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />)
  }
  if (eType & InputMode.stopwatch) {
    typeIcons.push(<Icon key={"stopwatch"} name='stopwatch' type='entypo' color={Colors.alpha.medium} style={styles.typeIcon} />)
  }

  const typeButton = (
        <TouchableOpacity onPress={typeClick?.bind(this)} style={styles.typeButton}>
            {typeIcons}
        </TouchableOpacity>
  )

  const removeButton = (
        <TouchableOpacity onPress={removeClick?.bind(this)} style={[styles.removeButton]}>
            <Text style={styles.removeButtonText}>{buttonText}</Text>
        </TouchableOpacity>)

  const content = (
        <View style={styles.content}>
            {body}
            {typeButton}
            {removeButton}
        </View>
  )

  const cardStyle = [styles.card]
  if (type === EditCardType.new) {
    cardStyle.push(styles.cardNew)
  } else if (type === EditCardType.remove) {
    cardStyle.push(styles.cardRemove)
  }

  if (isActive) cardStyle.push(styles.active)

  return (
        <TouchableOpacity delayLongPress={100} onLongPress={drag} onPress={click} >
            <Card content={content} style={cardStyle} />
        </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  active: {
    opacity: 0.5
  },
  card: {
    backgroundColor: Colors.silver,
    padding: 8
  },
  cardNew: {
    backgroundColor: Colors.lightYellow
  },
  cardRemove: {
    backgroundColor: Colors.lightRed
  },
  content: {
    alignItems: "center",
    flexDirection: "row"
  },
  exerciseText: {
    flex: 1,
    fontSize: 16,
    padding: 2
  },
  removeButton: {
    alignItems: "center",
    borderColor: "rgba(0,0,0,0.5)",
    borderRadius: 8,
    borderWidth: 1,
    height: 32,
    justifyContent: "center",
    right: 0,
    width: 42
  },
  removeButtonText: {
    color: "rgba(0,0,0,0.5)"
  },
  typeButton: {
    alignItems: "center",
    borderColor: "rgba(0,0,0,0.5)",
    borderRadius: 8,
    borderWidth: 1,
    flexDirection: "row",
    height: 32,
    justifyContent: "center",
    marginRight: 4,
    padding: 2
  }
})
