import React from "react"
import { StyleSheet } from "react-native"
import { Input } from "react-native-elements"

import { Theme } from "../styles/Colors"

export function TextInput ({ placeholder, value, onChangeText }) {
  return (
        <Input
            placeholder={placeholder}
            value={value}
            onChangeText={onChangeText}
            containerStyle={Style.nameTextContainer}
            inputContainerStyle={Style.nameTextInputContainer}
        />
  )
}

const Style = StyleSheet.create({
  nameTextContainer: {
    flex: 1,
    flexDirection: "row"
  },
  nameTextInputContainer: {
    alignItems: "center",
    borderColor: Theme.primary,
    borderRadius: 9,
    borderWidth: 1,
    justifyContent: "center",
    paddingHorizontal: 12,
    paddingVertical: 4
  }
})
