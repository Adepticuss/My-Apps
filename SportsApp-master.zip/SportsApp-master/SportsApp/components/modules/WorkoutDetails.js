import React, { useState, useEffect } from "react"
import { View, Text, StyleSheet, FlatList, Platform } from "react-native"
import { Divider } from "react-native-elements"
import KeyboardSpacer from "react-native-keyboard-spacer"

import Storage from "../controllers/Storage"
import { getExercise } from "../controllers/ExerciseData"
import { Item, formatMillisecond } from "../modules/HistoryCard"
import { ButtonInput } from "../modules/basic/Inputs"
import { GetButtonText } from "../modules/basic/Buttons"
import { FontColor, Theme } from "../styles/Colors"
import { DataRow, DataItem } from "../screens/history/components/CardOpen"

const ExerciseOverview = ({ id, items }) => {
  const [name, setName] = useState()

  useEffect(() => {
    const name = getExercise(id)?.name
    if (name) {
      setName(name)
      return
    }

    Storage.exercise.get(id, (val, e) => {
      if (val) {
        const j = JSON.parse(val)
        setName(j?.name)
      }
    })
  }, [id])

  const reps = items?.length
    ? sanitizeReps(items)
    : sanitizeReps(items?.reps)
  if (reps.length === 0) return <View />

  return (
        <View style={styles.exerciseData}>
          <View style={styles.exerciseNameBlock}>
            <Text style={styles.exerciseNameText}>{name}</Text>
          </View>

          <FlatList data={items}
                      renderItem={({ item }) => <DataItem item={item} />}
                      keyExtractor={(_, index) => `data-row-${index}`}
                      style={styles.dataBlockList} />
        </View>
  )

  function sanitizeReps (reps) {
    const clean = []
    if (!reps?.length) return clean

    for (let i = 0; i < reps.length; i++) {
      const rep = reps[i]
      if (!rep) continue

      const data = {}

      if (rep.weight) data.weight = rep.weight
      if (rep.count) data.reps = rep.count
      if (rep.reps) data.reps = rep.reps
      if (rep.time) data.time = rep.time

      if (data.weight || data.reps || data.time) clean.push(data)
    }

    return clean
  }
}

export default function WorkoutDetail ({ data, duration, onAddClick, noteSaved }) {
  const [items, setItems] = useState([])
  const [noteText, setNoteText] = useState("")

  useEffect(() => {
    setItems(parseDataArray(data))
  }, [data])

  return (
        <View style={styles.card}>
            <Text style={styles.title}>Overview</Text>
            <Text style={styles.durationText}>Duration</Text>
            <Text style={styles.duration}>{formatMillisecond(duration)}</Text>
            <FlatList data={items}
                        renderItem={({ item }) => <ExerciseOverview id={item.key} items={item.item} />}
                        keyExtractor={(_, i) => i.toString()} />
            <View style={styles.noteBlock}>
              <ButtonInput value={noteText}
                            onChangeText={(text) => setNoteText(text)}
                            placeholder="note"
                            buttonText={noteSaved ? "✓" : "+"}
                            onPress={() => { onAddClick(noteText) }} />
            </View>

            { Platform.OS === "ios" ? <KeyboardSpacer /> : null }
        </View>
  )

  function parseDataArray (array) {
    if (!array) return []

    const items = []
    for (const key in array) {
      const parsed = parseDataItem(key, array[key])
      if (parsed) items.push(parsed)
    }

    return items
  }

  function parseDataItem (key, item) {
    return { key: key, item: item }
  }
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    borderRadius: 24,
    flex: 1
  },
  dataBlockList: {
    backgroundColor: Theme.background,
    borderRadius: 16,
    marginBottom: 16,
    marginTop: -8,
    padding: 8,
    paddingTop: 16,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  duration: {
    color: Theme.primary,
    fontSize: 28,
    padding: 4,
    paddingVertical: 8,
    textAlign: "center"
  },
  durationText: {
    color: FontColor.onSurface,
    fontSize: 20,
    fontWeight: "200",
    textAlign: "center"
  },
  exerciseData: {
    overflow: "visible",
    paddingHorizontal: 16
  },
  exerciseNameBlock: {
    backgroundColor: Theme.primary,
    borderRadius: 16,
    padding: 4,
    zIndex: 7
  },
  exerciseNameText: {
    color: FontColor.onPrimary,
    fontSize: 16,
    fontWeight: "300",
    textAlign: "center"
  },
  noteBlock: {
    paddingHorizontal: 16
  },
  title: {
    color: FontColor.onSurface,
    fontSize: 28,
    padding: 4,
    paddingBottom: 12,
    textAlign: "center"
  }
})
