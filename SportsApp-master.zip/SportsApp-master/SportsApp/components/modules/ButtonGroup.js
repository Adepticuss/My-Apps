import React, { useState, useEffect } from "react"
import { StyleSheet } from "react-native"
import { ButtonGroup } from "react-native-elements"

import { Theme, FontColor } from "../styles/Colors"

export default function CustomButtonGroup ({ selected, options, onChange }) {
  const [index, setIndex] = useState(selected)

  useEffect(() => {
    setIndex(selected)
  }, [selected])

  useEffect(() => {
    if (typeof index === "undefined") return
    onChange(index)
  }, [index])

  return (
      <ButtonGroup onPress={(index) => { setIndex(index) }}
                    selectedIndex={index}
                    buttons={options}
                    innerBorderStyle={{ width: 0 }}
                    containerStyle={styles.switchContainer}
                    selectedButtonStyle={styles.activeButton}
                    selectedTextStyle={styles.activeButtonText}
                    textStyle={styles.disabledButtonText} />
  )
}

const styles = StyleSheet.create({
  activeButton: {
    backgroundColor: Theme.primary,
    borderRadius: 16,
    margin: 4
  },
  activeButtonText: {
    color: FontColor.onPrimary,
    fontSize: 16,
    fontWeight: "400"
  },
  disabledButtonText: {
    color: FontColor.onBackground,
    fontSize: 16,
    fontWeight: "400"
  },
  switchContainer: {
    backgroundColor: Theme.surface,
    borderRadius: 16,
    borderWidth: 0,
    height: 44,
    overflow: "visible",
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  }
})
