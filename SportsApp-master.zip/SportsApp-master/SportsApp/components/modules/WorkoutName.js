import React from "react"
import { View, Text, StyleSheet } from "react-native"
import { Input } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"

import { FontColor, Theme } from "../styles/Colors"

export default function WorkoutName ({ workoutName, setWorkoutName, onFocusChange }) {
  return (
        <View style={Style.nameBlock}>
            <View style={Style.nameTitleBlock}>
                <Text style={Style.nameTitleTextBig}>Name</Text>
                <View style={Style.row}>
                    <Text style={Style.nameTitleTextSmall}>your workout</Text>
                    <Text style={Style.nameTitleTextExclamation}>!</Text>
                </View>
            </View>
            <Input
                placeholder='Workout name'
                value={workoutName}
                onChangeText={onChangeText.bind(this)}
                containerStyle={Style.nameTextContainer}
                inputContainerStyle={Style.nameTextInputContainer}
                onFocus={() => focusChange(true)}
                onEndEditing={() => focusChange(false)}
            />
        </View>
  )

  function onChangeText (v) {
    Analytics.logEvent("WorkoutNameTyping")
    setWorkoutName(v)
  }

  function focusChange (state) {
    if (typeof onFocusChange !== "function") return

    onFocusChange(state)
  }
}

const _margin = 12
const Style = StyleSheet.create({
  nameBlock: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flexDirection: "row",
    marginBottom: _margin,
    marginHorizontal: _margin,
    paddingVertical: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  nameTextContainer: {
    flex: 1,
    flexDirection: "row"
  },
  nameTextInputContainer: {
    alignItems: "center",
    borderColor: Theme.primary,
    borderRadius: 9,
    borderWidth: 1,
    justifyContent: "center",
    paddingHorizontal: 12,
    paddingVertical: 4
  },
  nameTitleBlock: {
    marginLeft: 16
  },
  nameTitleTextBig: {
    color: FontColor.onSurface,
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: -12
  },
  nameTitleTextExclamation: {
    color: Theme.primary,
    fontSize: 24,
    fontWeight: "bold"
  },
  nameTitleTextSmall: {
    color: FontColor.onSurface,
    fontSize: 16,
    marginBottom: 2
  },
  row: {
    alignItems: "flex-end",
    flexDirection: "row"
  }
})
