import React from "react"
import { View, Text, StyleSheet, TouchableOpacity, TouchableWithoutFeedback, Modal, Image } from "react-native"
import { Icon } from "react-native-elements"

import Colors, { Theme, FontColor } from "../styles/Colors"
import { InputMode } from "../constants/Input"

const TypeButton = ({ type, isActive, onPress }) => {
  return (
      <TouchableOpacity style={getButtonStyle(isActive)} onPress={buttonPress.bind(this)}>
          <View style={Style.row}>
              {getTypeIcons(type, isActive)}
          </View>
          <Text style={getTextStyle(isActive)}>{getTypeText(type)}</Text>
      </TouchableOpacity>
  )

  function buttonPress () {
    console.log("press")
    if (typeof onPress !== "function") return
    if (typeof type === "undefined") return
    onPress(type)
  }

  function getButtonStyle (isActive) {
    const style = [Style.typeButton]
    if (isActive === true) style.push(Style.typeButtonActive)
    return style
  }

  function getButtonIconStyle (isActive) {
    const style = [Style.typeButtonIcon]
    if (isActive === true) style.push(Style.typeButtonIconActive)
    return style
  }

  function getTextStyle (isActive) {
    const style = [Style.typeButtonText]
    if (isActive === true) style.push(Style.typeButtonTextActive)
    return style
  }

  function getTypeIcons (type, isActive) {
    const icons = []
    if (type & InputMode.count) {
      icons.push(<Image key='reps' resizeMode='contain' style={getButtonIconStyle(isActive)} source={require("../../assets/icons/exercise_types/reps.png")} />)
    }
    if (type & InputMode.weight) {
      icons.push(<Image key='weight' resizeMode='contain' style={getButtonIconStyle(isActive)} source={require("../../assets/icons/exercise_types/weight.png")} />)
    }
    if (type & InputMode.timer) {
      icons.push(<Image key='timer' resizeMode='contain' style={getButtonIconStyle(isActive)} source={require("../../assets/icons/exercise_types/timer.png")} />)
    }
    if (type & InputMode.stopwatch) {
      icons.push(<Image key='stopwatch' resizeMode='contain' style={getButtonIconStyle(isActive)} source={require("../../assets/icons/exercise_types/stopwatch.png")} />)
    }

    return icons
  }

  function getTypeText (type) {
    if ((type & InputMode.count) && (type & InputMode.weight)) {
      return "Reps + Weight"
    } else if (type & InputMode.count) {
      return "Reps"
    } else if (type & InputMode.weight) {
      return "Weight"
    } else if (type & InputMode.timer) {
      return "Timer"
    } else if (type & InputMode.stopwatch) {
      return "Stopwatch"
    }
  }
}

export function TypeButtons ({ type, onChange }) {
  return (
    <View>
      <View style={Style.typeButtonRow}>
          <TypeButton type={InputMode.count}
                      isActive={getIsActive(type, InputMode.count)}
                      onPress={onChange}
          />
          <TypeButton type={InputMode.weight}
                      isActive={getIsActive(type, InputMode.weight)}
                      onPress={onChange}
          />
          <TypeButton type={InputMode.count | InputMode.weight}
                      isActive={getIsActive(type, InputMode.count | InputMode.weight)}
                      onPress={onChange}
          />
      </View>
      <View style={Style.typeButtonRow}>
          <TypeButton type={InputMode.stopwatch}
                      isActive={getIsActive(type, InputMode.stopwatch)}
                      onPress={onChange}
          />
          <TypeButton type={InputMode.timer}
                      isActive={getIsActive(type, InputMode.timer)}
                      onPress={onChange}
          />
      </View>
    </View>
  )

  function getIsActive (type, buttonType) {
    return type == buttonType
  }
}

export default function TypeSelector ({ visible, type, typeClicked, closed }) {
  return (
        <Modal animationType="fade"
                transparent={true}
                visible={visible}
                onRequestClose={closed.bind(this)} >
            <TouchableWithoutFeedback onPress={closed.bind(this)}>
                <View style={styles.modalBack}>
                    <View style={styles.typeModal}>
                        <TouchableOpacity onPress={() => { typeClicked(InputMode.count) }} style={getTypeButtonStyle(InputMode.count)}>
                            <Icon name='repeat' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />
                            <Text style={styles.typeText}>Reps</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => { typeClicked(InputMode.weight) }} style={getTypeButtonStyle(InputMode.weight)}>
                            <Icon name='weight' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />
                            <Text style={styles.typeText}>Weight</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => { typeClicked(InputMode.count | InputMode.weight) }} style={getTypeButtonStyle(InputMode.count | InputMode.weight)}>
                            <View style={styles.iconsRow}>
                                <Icon name='repeat' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />
                                <Icon name='weight' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />
                            </View>

                            <Text style={styles.typeText}>Reps + Weight</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => { typeClicked(InputMode.timer) }} style={getTypeButtonStyle(InputMode.timer)}>
                            <Icon name='av-timer' type='material-community' color={Colors.alpha.medium} style={styles.typeIcon} />
                            <Text style={styles.typeText}>Timer</Text>
                        </TouchableOpacity>

                        <TouchableOpacity onPress={() => { typeClicked(InputMode.stopwatch) }} style={getTypeButtonStyle(InputMode.stopwatch)}>
                            <Icon name='stopwatch' type='entypo' color={Colors.alpha.medium} style={styles.typeIcon} />
                            <Text style={styles.typeText}>Stopwatch</Text>
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity onPress={closed.bind(this)} style={styles.modalCloseButton}>
                        <Text style={styles.modalCloseText}>Close</Text>
                    </TouchableOpacity>
                </View>
            </TouchableWithoutFeedback>
        </Modal>
  )

  function getTypeButtonStyle (buttonType) {
    const style = [styles.typeButton]
    if (type === buttonType) {
      style.push(styles.activeTypeButton)
    }

    return style
  }
}

const Style = StyleSheet.create({
  row: {
    alignItems: "flex-end",
    flexDirection: "row"
  },
  typeButton: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    height: 85,
    justifyContent: "center",
    marginHorizontal: 4,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07,
    width: 80
  },
  typeButtonActive: {
    backgroundColor: Theme.primary,
    shadowOpacity: 0
  },
  typeButtonIcon: {
    height: 24,
    marginHorizontal: 2,
    width: 24
  },
  typeButtonIconActive: {
    tintColor: FontColor.onPrimary
  },
  typeButtonRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 8
  },
  typeButtonText: {
    color: FontColor.onSurface,
    marginTop: 4,
    textAlign: "center"
  },
  typeButtonTextActive: {
    color: FontColor.onPrimary
  }
})

const styles = StyleSheet.create({
  activeTypeButton: {
    backgroundColor: Colors.blue
  },
  iconsRow: {
    flexDirection: "row",
    justifyContent: "center"
  },
  modalBack: {
    alignItems: "center",
    backgroundColor: Colors.alpha.light,
    flex: 1,
    justifyContent: "center"
  },
  modalCloseButton: {
    backgroundColor: Colors.alpha.heavy,
    borderBottomLeftRadius: 6,
    borderBottomRightRadius: 6,
    paddingLeft: 12,
    paddingRight: 12
  },
  modalCloseText: {
    color: Colors.silver,
    padding: 4,
    textAlign: "center"
  },
  typeButton: {
    backgroundColor: Colors.alpha.light,
    borderRadius: 4,
    margin: 8,
    padding: 4
  },
  typeModal: {
    backgroundColor: "white",
    borderRadius: 12
  },
  typeText: {
    textAlign: "center"
  }
})
