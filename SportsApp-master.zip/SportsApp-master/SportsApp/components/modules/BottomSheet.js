import React, { useEffect, useRef } from "react"
import { View, StyleSheet } from "react-native"
import BottomSheet, { BottomSheetModal, BottomSheetModalProvider, BottomSheetBackdrop } from "@gorhom/bottom-sheet"
import Animated from "react-native-reanimated"
import { BlurView } from "expo-blur"
import KeyboardSpacer from "react-native-keyboard-spacer"

export function CustomBottomSheetModal ({ show, renderContent, size, onClose }) {
  const bottomSheetRef = useRef(null)
  const fall = new Animated.Value(0)

  useEffect(() => {
    if (show === true) {
      bottomSheetRef.current.present()
      bottomSheetRef.current.expand()
      console.log("show" + typeof bottomSheetRef.current.present)
    } else {
      bottomSheetRef.current.close()
      bottomSheetRef.current.dismiss()
    }
  }, [show])

  const renderHeader = () => (
        <View style={styles.panelHeader}>
            <View style={styles.panelHandle} />
        </View>
  )

  return (
        <BottomSheetModal
            ref={bottomSheetRef}
            snapPoints={[1, size]}
            index={1}
            overDragResistanceFactor={1.5}
            handleComponent={renderHeader}
            backdropComponent={({ animatedIndex }) => <BottomSheetBackdrop animatedIndex={animatedIndex} style={StyleSheet.absoluteFill}/>}
            onChange={onSheetChange.bind(this)}
        >
            {renderContent()}
        </BottomSheetModal>
  )

  function onSheetChange (index) {
    console.log(index)
    if (index === 0) {
      console.log("hide" + typeof bottomSheetRef.current.dismiss)
      bottomSheetRef.current.close()
      bottomSheetRef.current.dismiss()
      sheetClose()
    } else if (index === -1) {
      sheetClose()
    }
  }

  function sheetClose () {
    if (typeof onClose !== "function") return
    onClose()
  }
}

export default function CustomBottomSheet ({ show, renderContent, size, onClose }) {
  const bottomSheetRef = useRef(null)
  const fall = new Animated.Value(0)

  useEffect(() => {
    if (show === true) {
      bottomSheetRef.current.expand()
      console.log("show" + typeof bottomSheetRef.current.present)
    }
  }, [show])

  const renderHeader = () => (
        <View style={styles.panelHeader}>
            <View style={styles.panelHandle} />
        </View>
  )

  /* if (typeof renderContent !== 'function') {
        return <View />
    }

    if (show !== true) {
        return <View />
    } */

  return (
        <BottomSheet
            ref={bottomSheetRef}
            snapPoints={[0, size]}
            index={1}
            overDragResistanceFactor={1.5}
            handleComponent={renderHeader}
            onChange={onSheetChange.bind(this)}
            children={renderContent}
        >
        </BottomSheet>
  )

  return (
            <BlurView intensity={50} style={StyleSheet.absoluteFill}>

            </BlurView>
  )

  return (
        <Animated.View style={[
          StyleSheet.absoluteFill,
          {
            zIndex: 1,
            opacity: Animated.add(0.1, Animated.sub(1, fall))
          }
        ]}>
            <BlurView intensity={50} style={StyleSheet.absoluteFill}>
                <BottomSheet
                    ref={bottomSheetRef}
                    snapPoints={[size, 0]}
                    initialSnap={1}
                    overdragResistanceFactor={0.5}
                    callbackNode={fall}
                    enabledBottomInitialAnimation={true}
                    renderContent={renderContent}
                    renderHeader={renderHeader}
                    onCloseEnd={sheetClose.bind(this)}
                />
            </BlurView>
        </Animated.View>
  )

  function onSheetChange (index) {
    console.log(index)
    if (index === 0) {
      console.log("hide" + typeof bottomSheetRef.current.dismiss)
      bottomSheetRef.current.close()
      sheetClose()
    }
  }

  function sheetClose () {
    if (typeof onClose !== "function") return
    onClose()
  }
}

const styles = StyleSheet.create({
  panelHandle: {
    backgroundColor: "black",
    borderRadius: 4,
    height: 3,
    width: 40,
    zIndex: 10
  },
  panelHeader: {
    alignItems: "center",
    backgroundColor: "white",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingVertical: 20
  }
})
