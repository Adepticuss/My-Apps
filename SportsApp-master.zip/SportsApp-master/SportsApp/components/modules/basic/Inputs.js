import React from "react"
import { StyleSheet, TextInput, View } from "react-native"
import { SearchBar, Input } from "react-native-elements"

import Button from "../../modules/basic/Buttons"
import { TextButton } from "../../modules/Buttons"
import Colors from "../../styles/Colors"
import Fonts from "../../styles/Fonts"

export function SearchInput ({ value, style, onChangeText, placeholder }) {
  let s = [styles.searchInputBack]
  if (style) s = [...s, ...style]

  return (
        <SearchBar
            lightTheme={true}
            containerStyle={s}
            inputContainerStyle={styles.searchInputFront}
            onChangeText={onChangeText}
            value={value}
            placeholder={placeholder}>
        </SearchBar>
  )
}

export function ButtonInput ({ value, style, onChangeText, onPress, buttonContent, buttonText, buttonStyle, placeholder }) {
  let s = [styles.buttonInput]
  if (style) s = [...s, ...style]

  let bs = [styles.inputButton]
  if (buttonStyle) bs = [...bs, ...buttonStyle]

  return (
        <View style={s}>

            <Input value={value} onChangeText={onChangeText} placeholder={placeholder} containerStyle={[styles.flexInput]} />

            <TextButton text={buttonText} onPress={onPress} />

        </View>
  )
}

const styles = StyleSheet.create({
  buttonInput: {
    alignItems: "center",
    flexDirection: "row"
  },
  flexInput: {
    flex: 1
  },
  inputButton: {
    backgroundColor: Colors.blue,
    height: 36,
    marginLeft: 0,
    width: 57
  },
  searchInputBack: {
    backgroundColor: "rgba(0,0,0,0)"
  },
  searchInputFront: {
    backgroundColor: Colors.silver
  },
  textInput: {
    borderBottomWidth: 2,
    borderColor: Colors.yellow + "aa",
    borderRadius: 4,
    borderTopWidth: 2,
    fontSize: 22,
    margin: 6,
    padding: 8,
    textAlign: "center"
  }
})
