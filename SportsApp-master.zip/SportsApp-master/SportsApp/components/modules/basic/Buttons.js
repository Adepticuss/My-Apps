import React from "react"
import { StyleSheet, Text, TouchableOpacity } from "react-native"

import Colors from "../../styles/Colors"
import Fonts from "../../styles/Fonts"

export default function Button ({ content, style, onPress, disabled }) {
  let s = [styles.button]
  if (style) s = [...s, ...style]

  return (
        <TouchableOpacity onPress={onPress} style={s} disabled={disabled} >
            {content}
        </TouchableOpacity>
  )
}

export function TextButton ({ text, style, onPress, disabled }) {
  return (
        <Button content={GetButtonText(text)} style={style} onPress={onPress} disabled={disabled} />
  )
}

export function RoundTextButton ({ text, style, onPress, disabled }) {
  return (
        <RoundButton content={GetButtonText(text)} style={style} onPress={onPress} disabled={disabled} />
  )
}

export function RoundButton ({ content, style, onPress, disabled }) {
  let s = [styles.roundButton]
  if (style) s = [...s, ...style]

  return (
        <Button content={content} style={s} onPress={onPress} disabled={disabled} />
  )
}

export function GetButtonText (text) {
  return (
        <Text style={[styles.text, Fonts.default]}>{text}</Text>
  )
}

const styles = StyleSheet.create({
  button: {
    alignItems: "center",
    backgroundColor: Colors.alpha.light,
    borderRadius: 4,
    elevation: 4,
    justifyContent: "center",
    padding: 2
  },
  roundButton: {
    alignItems: "center",
    backgroundColor: Colors.alpha.light,
    borderRadius: 50,
    elevation: 4,
    height: 50,
    justifyContent: "center",
    width: 50
  },
  text: {
    textAlign: "center"
  }
})
