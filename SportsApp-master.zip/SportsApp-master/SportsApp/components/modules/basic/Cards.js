import React from "react"
import { StyleSheet, Text, View, TouchableOpacity } from "react-native"

import Button from "./Buttons"
import Fonts from "../../styles/Fonts"
import Colors from "../../styles/Colors"

const TextContent = ({ text, textStyle }) => {
  let s = [styles.cardText, Fonts.default]
  if (textStyle) s = [...s, ...textStyle]

  return (
        <Text style={s}>{text}</Text>
  )
}

export function TextButtonCard ({ text, textStyle, buttonContent, style, buttonClick }) {
  return (
        <ButtonCard content={<TextContent text={text} textStyle={textStyle}/>} style={style} buttonClick={buttonClick} buttonContent={buttonContent} />
  )
}

export function ButtonCard ({ content, buttonContent, style, buttonClick }) {
  const button = (
        <Button onPress={buttonClick} content={buttonContent} style={[styles.cardButton]} />
  )

  const cardContent = (
        <View style={styles.rowContent}>
            <View style={styles.content}>
                {content}
            </View>

            {button}
        </View>
  )

  return (
        <Card content={cardContent} style={style} />
  )
}

export function TextCard ({ text, style, onPress }) {
  return (
        <Card content={<TextContent text={text}/>} style={style} onPress={onPress} />
  )
}

export default function Card ({ content, style, onPress }) {
  let s = [styles.card]
  if (style) s = [...s, ...style]

  const card = (
        <View style={s} >
            {content}
        </View>
  )

  if (!onPress) return card

  return (
        <TouchableOpacity onPress={onPress} >
            {card}
        </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.alpha.light,
    borderRadius: 12,
    justifyContent: "center",
    marginVertical: 8,
    padding: 8
  },
  cardButton: {
    backgroundColor: "rgba(0,0,0,0)",
    borderColor: "rgba(0,0,0,0.5)",
    borderWidth: 1,
    elevation: 0,
    height: 36,
    width: 42
  },
  cardText: {
    fontSize: 16,
    textAlign: "center"
  },
  content: {
    flex: 1
  },
  rowContent: {
    alignItems: "center",
    flexDirection: "row"
  }
})
