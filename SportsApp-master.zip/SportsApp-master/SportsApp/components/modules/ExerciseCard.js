import React, { useState, useEffect } from "react"
import { View, StyleSheet, TouchableOpacity } from "react-native"
import { Icon } from "react-native-elements"

import { GetButtonText, TextButton } from "./basic/Buttons"
import Card, { TextCard } from "./basic/Cards"

import Colors from "../styles/Colors"

export function PickerCard ({ name, click, picked, style, longPress }) {
  const [checked, setChecked] = useState(picked)

  useEffect(() => {
    setChecked(picked)
  }, [picked])

  const content = (
        <View style={styles.content}>
            <TouchableOpacity onPress={longPress} >
                <Icon name='info-outline' type='material' />
            </TouchableOpacity>

            <TouchableOpacity onPress={pickerClick.bind(this)} style={styles.flex}>
                {GetButtonText(name)}
            </TouchableOpacity>

            {getPickButtonContent(checked)}
        </View>
  )

  return (
        <Card content={content} style={getStyle(checked, style)} />
  )

  function getStyle (picked, style) {
    const styleList = [styles.pickCard, ...style]
    if (picked === true) {
      styleList.push(styles.picked)
    }

    return styleList
  }

  function pickerClick () {
    setChecked(!checked)

    if (click) {
      click(!checked)
    }
  }

  function getPickButtonContent (picked) {
    let text = "+"
    if (picked === true) {
      text = "✓"
    }

    return (
            <TextButton text={text} style={[styles.addButton]} onPress={pickerClick.bind(this)} />
    )
  }
}

export const ProgressStates = {
  clean: 0,
  incomplete: 1,
  inProcess: 2,
  done: 3
}

export function ProgressCard ({ name, progress, style, click }) {
  function getStyle () {
    const styleList = [...style, styles.progressCard]
    if (progress === ProgressStates.incomplete) {
      styleList.push(styles.progressOne)
    } else if (progress === ProgressStates.inProcess) {
      styleList.push(styles.progressTwo)
    } else if (progress === ProgressStates.done) {
      styleList.push(styles.progressThree)
    }

    return styleList
  }

  return (
        <TextCard text={name}
                    onPress={click}
                    style={getStyle()} />
  )
}

const styles = StyleSheet.create({
  addButton: {
    backgroundColor: "rgba(0,0,0,0)",
    elevation: 0,
    height: 24,
    width: 48
  },
  content: {
    flexDirection: "row"
  },
  flex: {
    flex: 1,
    justifyContent: "center"
  },
  pickCard: {
    backgroundColor: Colors.silver,
    padding: 6
  },
  picked: {
    backgroundColor: Colors.yellow
  },
  progressCard: {
    backgroundColor: Colors.silver,
    borderColor: Colors.alpha.transparent,
    borderWidth: 2,
    padding: 14
  },
  progressOne: {
    backgroundColor: Colors.lightYellow
  },
  progressThree: {
    backgroundColor: Colors.alpha.light
  },
  progressTwo: {
    backgroundColor: Colors.lightGreen,
    borderColor: Colors.green
  }
})
