import React, { useState, useEffect } from "react"
import { View, SafeAreaView, Text, Alert, StyleSheet } from "react-native"
import { Button } from "react-native-elements"

import { Theme, FontColor } from "../styles/Colors"

export function OutlineTextButton ({ text, onPress }) {
  return (
        <Button title={text}
                type='outline'
                onPress={onPress}
                buttonStyle={styles.outlineStyle}
                titleStyle={styles.outlineTextStyle}
        />
  )
}

export function TextButton ({ text, onPress, style }) {
  return (
        <Button title={text}
                type='solid'
                onPress={onPress}
                buttonStyle={getButtonStyle()}
                titleStyle={styles.solidTextStyle}
        />
  )

  function getButtonStyle () {
    const s = [styles.solidStyle]
    if (typeof style !== "undefined") {
      s.push(style)
    }

    return s
  }
}

const styles = StyleSheet.create({
  outlineStyle: {
    borderColor: Theme.primary,
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 24,
    paddingVertical: 12
  },
  outlineTextStyle: {
    color: FontColor.onBackground
  },
  solidStyle: {
    backgroundColor: Theme.primary,
    borderColor: Theme.primary,
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 24,
    paddingVertical: 12
  },
  solidTextStyle: {
    color: FontColor.onPrimary
  }
})
