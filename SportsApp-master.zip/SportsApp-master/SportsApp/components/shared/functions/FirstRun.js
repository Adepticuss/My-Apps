import AsyncStorage from "@react-native-async-storage/async-storage"

export function runOnKeyNotSet (key, func) {
  if (typeof key !== "string" || !key || typeof func !== "function") return

  const dbKey = "flag_" + key
  AsyncStorage.getItem(dbKey, (_, r) => {
    if (r === "true") return
    func()
    AsyncStorage.setItem(dbKey, "true")
  })
}
