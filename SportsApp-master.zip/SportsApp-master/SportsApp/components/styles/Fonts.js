import { StyleSheet, Platform } from "react-native"

const fontsIos = {
  default: {
    fontFamily: "Verdana"
  },
  italic: {
    fontFamily: "Verdana-Italic"
  },
  bold: {
    fontFamily: "Verdana-Bold"
  }
}

const fontsAndroid = {
  default: {
    fontFamily: "sans-serif"
  },
  italic: {
    fontFamily: "sans-serif"
  },
  bold: {
    fontFamily: "sans-serif-medium"
  }
}

export default StyleSheet.create(Platform.OS === "ios" ? fontsIos : fontsAndroid)
