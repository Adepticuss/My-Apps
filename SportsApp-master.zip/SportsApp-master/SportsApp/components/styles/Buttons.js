import { StyleSheet } from "react-native"

export const Constants = {
  borderRadius: 4,
  elevation: 2
}

export default StyleSheet.create({
  button: {
    borderRadius: Constants.borderRadius,
    elevation: Constants.elevation
  },
  centrify: {
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center"
  }
})
