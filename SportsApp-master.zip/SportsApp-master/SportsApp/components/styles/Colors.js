export const Alpha = {
  light: "42",
  medium: "90",
  heavy: "dd"
}

export const FontColor = {
  onPrimary: "#FFFFFF",
  onSecondary: "#FFFFFF",
  onBackground: "#595960",
  onSurface: "#313131"
}

export const Theme = {
  primary: "#63C8FA",
  secondary: "#F2994A",
  background: "#F6F6F6",
  surface: "#FFFFFF"
}

export default {
  grey: "#4C4C4C",
  lightGrey: "#E5E5E5",
  green: "#00C655",
  blue: "#54ddff",
  lightBlue: "#ECFBFF",
  deepBlue: "#618CFF",
  brightGreen: "#47FFBF",
  lightGreen: "#B4EE88",
  red: "#FF4D40",
  lightRed: "#FF8E6C",
  orange: "#FFA654",
  pink: "#FF896E",
  silver: "#D9D9D9",
  lightSilver: "#F6F6F6",
  yellow: "#FFC73B",
  lightYellow: "#FFDD7D",
  alpha: {
    transparent: "rgba(0,0,0,0)",
    extraLight: "rgba(0,0,0,0.05)",
    light: "rgba(0,0,0,0.25)",
    medium: "rgba(0,0,0,0.5)",
    heavy: "rgba(0,0,0,0.75)"
  }
}
