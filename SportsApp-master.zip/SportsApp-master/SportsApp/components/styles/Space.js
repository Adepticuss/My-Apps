import { StyleSheet } from "react-native"

export const Margin = 24

export default StyleSheet.create({
  bottom: {
    bottom: Margin,
    position: "absolute"
  },
  left: {
    left: Margin,
    position: "absolute"
  },
  margin: {
    marginLeft: Margin,
    marginRight: Margin
  },
  right: {
    position: "absolute",
    right: Margin
  }
})
