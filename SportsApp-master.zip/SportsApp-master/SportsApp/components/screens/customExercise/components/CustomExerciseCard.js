import React, { useState, useEffect } from "react"
import { View } from "react-native"

import Storage from "../../../controllers/Storage"
import { TextCard } from "../../../modules/basic/Cards"

import Style from "../Style"

export default function CustomExerciseCard ({ itemKey, onPress }) {
  const [exercise, setExercise] = useState({})

  useEffect(() => {
    if (!itemKey) return

    Storage.item.get(itemKey, x => {
      if (!x) return
      const parsed = JSON.parse(x)
      if (!parsed) return

      setExercise(parsed)
    })
  }, [itemKey])

  if (!exercise?.name) return <View />

  return (
        <View>
            <TextCard text={exercise.name}
                        style={[Style.pickerCard]}
                        onPress={cardPress.bind(this)} />
        </View>
  )

  function cardPress () {
    if (typeof onPress !== "function") return
    onPress(exercise)
  }
}
