import React, { useState, useEffect } from "react"
import { View, Text, TouchableOpacity, FlatList } from "react-native"
import UUID from "react-native-uuid"
import { Icon } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"

import { GetButtonText } from "../../modules/basic/Buttons"
import { ButtonInput } from "../../modules/basic/Inputs"
import { InputMode } from "../../constants/Input"
import Storage from "../../controllers/Storage"
import CustomExerciseCard from "./components/CustomExerciseCard"

import Style, { IconColor } from "./Style"

export default function CustomExercise ({ navigation }) {
  const [name, setName] = useState()
  const [type, setType] = useState(InputMode.count | InputMode.weight)
  const [customKeys, setCustomeKeys] = useState([])

  useEffect(() => {
    Storage.exercise.getAll(keys => {
      if (keys?.length >= 0) {
        setCustomeKeys(keys)
      }
    })
  }, [])

  return (
        <View style={Style.flex}>

            <View style={Style.description}>
                <Text style={[Style.title]}>Custom exercise</Text>
                <Text style={[Style.subtitle]}>Name your own exercise and select input type below</Text>
            </View>

            <ButtonInput value={name}
                            onChangeText={(text) => setName(text)}
                            placeholder="exercise name"
                            style={[Style.input]}
                            buttonContent={GetButtonText("+")}
                            onPress={() => { finilizeExercise() }} />

            <View style={Style.typeBlock}>
                <TouchableOpacity onPress={() => { typeClicked(InputMode.count) }} style={getTypeButtonStyle(InputMode.count)}>
                    <Icon name='repeat' type='material-community' color={IconColor} style={Style.typeIcon} />
                    <Text style={Style.typeText}>Reps</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => { typeClicked(InputMode.weight) }} style={getTypeButtonStyle(InputMode.weight)}>
                    <Icon name='weight' type='material-community' color={IconColor} style={Style.typeIcon} />
                    <Text style={Style.typeText}>Weight</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => { typeClicked(InputMode.count | InputMode.weight) }} style={getTypeButtonStyle(InputMode.count | InputMode.weight)}>
                    <View style={Style.iconsRow}>
                        <Icon name='repeat' type='material-community' color={IconColor} style={Style.typeIcon} />
                        <Icon name='weight' type='material-community' color={IconColor} style={Style.typeIcon} />
                    </View>

                    <Text style={Style.typeText}>Reps + Weight</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => { typeClicked(InputMode.timer) }} style={getTypeButtonStyle(InputMode.timer)}>
                    <Icon name='av-timer' type='material-community' color={IconColor} style={Style.typeIcon} />
                    <Text style={Style.typeText}>Timer</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => { typeClicked(InputMode.stopwatch) }} style={getTypeButtonStyle(InputMode.stopwatch)}>
                    <Icon name='stopwatch' type='entypo' color={IconColor} style={Style.typeIcon} />
                    <Text style={Style.typeText}>Stopwatch</Text>
                </TouchableOpacity>
            </View>

            <FlatList data={customKeys}
                        renderItem={({ item }) => (<CustomExerciseCard itemKey={item} onPress={cardClick.bind(this)} />)}
                        keyExtractor={(_, index) => `exercises-${index}`}
                        style={Style.exerciseList} />
        </View>
  )

  function getTypeButtonStyle (buttonType) {
    const style = [Style.typeButton]
    if (type === buttonType) {
      style.push(Style.activeTypeButton)
    }

    return style
  }

  function typeClicked (mode) {
    setType(mode)
    Analytics.logEvent("CustomTypeClick", { mode: mode + "" })
  }

  function cardClick (exercise) {
    addExercise(exercise)
  }

  function finilizeExercise () {
    const cleanName = name?.trim()
    if (!cleanName) {
      return
    }

    const id = UUID.v4()?.substring(0, 8)
    const exercise = {
      id: id,
      name: cleanName,
      type: type,
      custom: true
    }

    Analytics.logEvent("CustomAdd", { name: cleanName, type: type + "" })
    addExercise(exercise)
  }

  function addExercise (exercise) {
    if (!exercise?.id ||
            !exercise?.name ||
            !exercise?.type) return

    navigation.navigate("EditOverview", { newExercise: [exercise] })
  }
}
