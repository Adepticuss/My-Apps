import { StyleSheet } from "react-native"
import Colors, { Alpha } from "../../styles/Colors"

export const IconColor = Colors.alpha.medium

export default StyleSheet.create({
  activeTypeButton: {
    backgroundColor: Colors.blue
  },
  description: {
    alignItems: "center",
    margin: 8
  },
  exerciseList: {
    flex: 1,
    marginHorizontal: 16
  },
  flex: {
    flex: 1
  },
  iconsRow: {
    flexDirection: "row",
    justifyContent: "center"
  },
  input: {
    marginHorizontal: 16,
    marginTop: 8
  },
  pickerCard: {
    backgroundColor: Colors.blue + Alpha.light,
    padding: 8,
    paddingVertical: 12
  },
  subtitle: {
    color: Colors.grey,
    fontSize: 12
  },
  title: {
    color: Colors.grey,
    fontSize: 24,
    marginBottom: 8
  },
  typeBlock: {
    flexDirection: "row",
    marginHorizontal: 8
  },
  typeButton: {
    alignItems: "center",
    backgroundColor: Colors.alpha.light,
    borderRadius: 4,
    flex: 1,
    justifyContent: "center",
    margin: 4,
    padding: 4
  },
  typeText: {
    fontSize: 11,
    textAlign: "center"
  }
})
