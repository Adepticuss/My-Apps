import React, { useState, useEffect } from "react"
import { View, Text, Image, TouchableOpacity, FlatList } from "react-native"

import Style from "../Style"
import { WeightType } from "../../../constants/Settings"
import { formatMillisecond, formatPrimaryName, formatSecondaryName } from "../../../controllers/History"

const _fieldIcon = {
  weight: 1,
  reps: 2,
  stopwatch: 4,
  timer: 8
}

function DataField ({ value, icon, weightUnit }) {
  if (typeof value !== "string" &&
        typeof value !== "number") {
    return <View/>
  }

  return (
        <View style={Style.dataField}>
            <Image resizeMode='contain' style={Style.dataFieldIcon} source={getIcon(icon)} />
            <Text style={Style.dataFieldText}>{getValue(value, icon)}</Text>
        </View>
  )

  function getValue (value, icon) {
    if (icon === _fieldIcon.stopwatch ||
            icon === _fieldIcon.timer) {
      return formatMillisecond(value)
    }

    return value
  }

  function getIcon (icon) {
    if (icon === _fieldIcon.weight) {
      if (weightUnit === WeightType.kg) {
        return require("../../../../assets/icons/exercise_types/weight_kg.png")
      } else if (weightUnit === WeightType.lb) {
        return require("../../../../assets/icons/exercise_types/weight_lb.png")
      } else {
        return require("../../../../assets/icons/exercise_types/weight.png")
      }
    } else if (icon === _fieldIcon.reps) {
      return require("../../../../assets/icons/exercise_types/reps.png")
    } else if (icon === _fieldIcon.stopwatch) {
      return require("../../../../assets/icons/exercise_types/stopwatch.png")
    } else if (icon === _fieldIcon.timer) {
      return require("../../../../assets/icons/exercise_types/timer.png")
    }
  }
}

export function DataItem ({ item, weightUnit }) {
  if (!item) {
    return <View/>
  }

  const isStopwatchData = item.time > 0 && (typeof item.elapsed === "undefined" || item.elapsed === null)
  const isTimerData = item.time > 0 && !isStopwatchData

  return (
        <View>
            <View style={Style.dataItem}>
                <DataField value={item.weight} icon={_fieldIcon.weight} weightUnit={weightUnit} />
                <DataField value={item.reps} icon={_fieldIcon.reps} />
                <DataField value={item.count} icon={_fieldIcon.reps} />
                {isStopwatchData &&
                <DataField value={item.time} icon={_fieldIcon.stopwatch} />
                }
                {isTimerData &&
                <DataField value={item.elapsed === 0 ? item.time : item.elapsed} icon={_fieldIcon.timer} />
                }
            </View>
        </View>

  )
}

export function DataRow ({ data }) {
  const [jsonData, setJsonData] = useState()

  useEffect(() => {
    console.log(data)
    setJsonData(JSON.parse(data))
  }, [data])

  return (
        <View style={Style.dataRow}>
            {jsonData &&
            <FlatList data={jsonData.reps}
                        renderItem={({ item }) => <DataItem item={item} weightUnit={jsonData.weightUnit} />}
                        keyExtractor={(_, index) => `data-item-${data?.timestamp}-${index}`}
                        style={Style.dataBlockList} />
            }
        </View>
  )
}

function DataBlock ({ title, data, mode }) {
  const [displayTitle, setDisplayTitle] = useState(title)

  useEffect(() => {
    formatSecondaryName(title, mode, setDisplayTitle)
  }, [title])

  return (
        <View style={Style.dataBlock}>
            <Text style={Style.dataBlockTitle}>{displayTitle}</Text>
            <FlatList data={data}
                        renderItem={({ item }) => <DataRow data={item} />}
                        keyExtractor={(_, index) => `data-row-${title}-${index}`}
                        style={Style.dataBlockList} />
        </View>
  )
}

export default function Card ({ name, data, mode, onChevron }) {
  const [displayName, setDisplayName] = useState(name)

  useEffect(() => {
    formatPrimaryName(name, mode, setDisplayName)
  }, [name])

  return (
        <View style={[Style.historyCard, Style.historyCardOpen]}>
            <View style={Style.historyCardTitleBlock}>
                <View style={Style.historyCardTextBlock}>
                    <Text style={[Style.historyCardTitleText, Style.historyCardOpenText]}>{displayName}</Text>
                </View>

                <View style={Style.historyCardTimeBlock}>
                    <Image resizeMode='contain' style={Style.historyCardTimeBlockIcon} source={require("../../../../assets/icons/history/clock.png")}/>
                    <Text style={Style.historyCardTimeBlockText}>{formatMillisecond(615000)}</Text>
                </View>

                <TouchableOpacity style={Style.historyCardChevron} onPress={onChevron}>
                    <Image resizeMode='contain' style={Style.historyCardChevronIcon} source={require("../../../../assets/icons/history/chevron_up.png")}/>
                </TouchableOpacity>
            </View>

            <FlatList data={data}
                        renderItem={({ item }) => <DataBlock title={item.title} data={item.data} mode={mode} />}
                        keyExtractor={(_, index) => `data-block-${index}`}
                        style={Style.dataBlockList} />

        </View>
  )
}
