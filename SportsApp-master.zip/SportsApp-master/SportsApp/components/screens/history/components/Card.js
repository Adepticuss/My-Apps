import React, { useState, useEffect } from "react"
import { View, Text } from "react-native"

import Style from "../Style"
import Storage from "../../../controllers/Storage"

import CardClosed from "./CardClosed"
import CardOpen from "./CardOpen"

export default function Card ({ item, mode, expanded }) {
  const [name, setName] = useState()
  const [data, setData] = useState()
  const [closed, setClosed] = useState(true)
  const [toLoad, setToLoad] = useState({})
  const [loaded, setLoaded] = useState([])

  useEffect(() => {
    if (typeof item === "undefined") return

    setName(item.key)
    setData(item.item)

    if (expanded === true) load()
  }, [item])

  useEffect(() => {
    setToLoad(data)
  }, [data])

  useEffect(() => {
    if (expanded === true) {
      setClosed(false)
    }
  }, [expanded])

  useEffect(() => {
    if (!closed) load()
  }, [closed])

  if (closed) {
    return (
            <CardClosed name={name} data={data} mode={mode} onChevron={swapClosedState.bind(this)} />
    )
  } else {
    return (
            <CardOpen name={name} data={loaded} mode={mode} onChevron={swapClosedState.bind(this)} />
    )
  }

  function swapClosedState () {
    if (expanded === true) return
    setClosed(!closed)
  }

  function load () {
    if (typeof toLoad === "undefined") return
    const keys = Object.keys(toLoad).sort((a, b) => a < b)
    keys.forEach(key => {
      const item = toLoad[key]

      const totalCount = item?.length
      if (!(totalCount > 0)) {
        delete toLoad[key]
        return
      }

      let toLoadCount = totalCount
      const loadedItems = []

      item.forEach(subkey => {
        Storage.item.get(subkey, (history, e) => {
          if (!history) {
            toLoadCount -= 1
            updateLoaded(toLoadCount, loadedItems, key)
            return
          }

          loadedItems.push(history)

          toLoadCount -= 1
          updateLoaded(toLoadCount, loadedItems, key)
        })
      })
    })
  }

  function updateLoaded (loadCount, loadedItems, key) {
    if (loadCount === 0) {
      const data = {
        title: key,
        data: loadedItems
      }

      loaded.push(data)
      setLoaded([...loaded])
      delete toLoad[key]
    }
  }
}
