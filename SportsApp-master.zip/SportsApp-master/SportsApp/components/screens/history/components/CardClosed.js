import React, { useState, useEffect } from "react"
import { View, Text, Image, TouchableOpacity } from "react-native"

import Style from "../Style"
import { HistoryMode, formatPrimaryName } from "../../../controllers/History"

export default function Card ({ name, data, mode, onChevron }) {
  const [last, setLast] = useState()
  const [displayName, setDisplayName] = useState(name)

  useEffect(() => {
    formatPrimaryName(name, mode, setDisplayName)
  }, [name])

  useEffect(() => {
    if (typeof data === "undefined") return
    const keys = Object.keys(data).sort((a, b) => a < b)
    const lastKey = keys[0]
    const lastItem = data[lastKey]
    setLast({ key: lastKey, item: lastItem })
  }, [data])

  return (
        <View style={[Style.historyCard, Style.historyCardClosed]}>
            <View style={Style.historyCardTitleBlock}>
                <View style={Style.historyCardTextBlock}>
                    <Text style={[Style.historyCardTitleText, Style.historyCardClosedText]}>{displayName}</Text>
                    {mode === HistoryMode.exercise && last &&
                    <Text style={[Style.historyCardSubtitleText, Style.historyCardClosedText]}>Last workout on {last.key}, {last.item?.length} record{last.item?.length > 1 ? "s" : ""}</Text>
                    }
                </View>

                <Image resizeMode='contain' style={Style.historyCardIcon} source={require("../../../../assets/icons/history/note.png")}/>
                <TouchableOpacity style={Style.historyCardChevron} onPress={onChevron}>
                    <Image resizeMode='contain' style={Style.historyCardChevronIcon} source={require("../../../../assets/icons/history/chevron.png")}/>
                </TouchableOpacity>
            </View>
        </View>
  )
}
