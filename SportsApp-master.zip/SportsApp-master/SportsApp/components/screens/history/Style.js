import { StyleSheet } from "react-native"
import Colors, { Theme, FontColor } from "../../styles/Colors"

export default StyleSheet.create({
  cardList: {
    flex: 1,
    marginBottom: 8,
    marginTop: 8
  },
  dataBlock: {
    marginBottom: 4
  },
  dataBlockTitle: {
    color: FontColor.onPrimary,
    fontSize: 16,
    textAlign: "center"
  },
  dataField: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flexDirection: "row",
    flex: 1,
    height: 50,
    justifyContent: "center",
    marginRight: 8,
    padding: 8
  },
  dataFieldIcon: {
    height: 24,
    width: 24
  },
  dataFieldText: {
    color: FontColor.onSurface,
    flex: 1,
    fontSize: 16,
    fontWeight: "400",
    textAlign: "center"
  },
  dataItem: {
    flexDirection: "row",
    marginBottom: 4,
    marginHorizontal: 16,
    marginRight: 8
  },
  dataRow: {
    marginVertical: 8
  },
  flex: {
    flex: 1
  },
  historyCard: {
    borderRadius: 16,
    marginBottom: 8,
    marginHorizontal: 12
  },
  historyCardChevron: {
    marginLeft: 8,
    padding: 4
  },
  historyCardChevronIcon: {
    height: 16,
    width: 16
  },
  historyCardClosed: {
    backgroundColor: Theme.surface,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  historyCardClosedText: {
    color: FontColor.onSurface
  },
  historyCardIcon: {
    height: 20,
    opacity: 0,
    width: 20
  },
  historyCardOpen: {
    backgroundColor: Theme.primary
  },
  historyCardOpenText: {
    color: FontColor.onPrimary
  },
  historyCardSubtitleText: {
    fontSize: 12,
    fontWeight: "200"
  },
  historyCardTextBlock: {
    flex: 1
  },
  historyCardTimeBlock: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 12,
    flexDirection: "row",
    opacity: 0,
    padding: 6
  },
  historyCardTimeBlockIcon: {
    height: 18,
    marginRight: 4,
    width: 18
  },
  historyCardTimeBlockText: {
    color: FontColor.onSurface,
    fontSize: 14
  },
  historyCardTitleBlock: {
    alignItems: "center",
    flexDirection: "row",
    height: 58,
    padding: 8,
    paddingHorizontal: 16,
    width: "100%"
  },
  historyCardTitleText: {
    fontSize: 16,
    fontWeight: "400"
  },
  screen: {
    flex: 1,
    marginBottom: 16
  }
})
