import React, { useEffect, useState, useRef } from "react"
import { View, FlatList, ScrollView, Text, Image, Platform, Dimensions, StyleSheet } from "react-native"

import Storage from "../../controllers/Storage"
import Style from "./Style"
import { groupKeys, HistoryMode } from "../../controllers/History"

import ButtonGroup from "../../modules/ButtonGroup"
import HistoryCard from "./components/Card"

export default function History ({ navigation }) {
  const [history, setHistory] = useState([])
  const [historyType, setHistoryType] = useState(HistoryMode.exercise)

  useEffect(() => {
    updateHistory()
  }, [])

  useEffect(() => {
    updateHistory()
  }, [historyType])

  return (
        <View style={Style.flex}>
            <View>

            </View>
            <ButtonGroup
                options={["Exercise", "Date"]}
                selected={historyTypeToIndex(historyType)}
                onChange={x => setHistoryType(indexToHistoryType(x))}
            />

            <FlatList data={history}
                        renderItem={({ item }) => <HistoryCard item={item} mode={historyType} />}
                        keyExtractor={item => item.key}
                        style={Style.cardList} />
        </View>
  )

  function historyTypeToIndex (selected) {
    if (selected === HistoryMode.exercise) {
      return 0
    } else if (selected === HistoryMode.date) {
      return 1
    }
  }

  function indexToHistoryType (index) {
    if (index === 0) {
      return HistoryMode.exercise
    } else if (index === 1) {
      return HistoryMode.date
    }
  }

  function updateHistory () {
    setHistory([])

    Storage.history.getAll((keys) => {
      const grouped = groupKeys(keys, historyType)
      setHistory(grouped)
    })
  }
}
