import React, { useEffect, useState } from "react"
import { View, SafeAreaView, Text, Platform } from "react-native"
import { Icon, Button, Overlay } from "react-native-elements"
import Constants from "expo-constants"
import * as Notifications from "expo-notifications"
import * as Permissions from "expo-permissions"
import * as Analytics from "expo-firebase-analytics"

import Tabs, { _tabs, TabNames } from "./components/Tabs"
import Style from "./Style"

import HomeScreen from "../home/Home"
import { BodyStatsScreen } from "../bodyStats/BodyStats"
import HistoryScreen from "../history/History"
import { SettingsScreen } from "../settings/Settings"

export default function TabsScreen ({ navigation }) {
  const [screenSelected, setScreenSelected] = useState(_tabs.home)
  const [expoPushToken, setExpoPushToken] = useState()
  const [showOverlay, setShowOverlay] = useState(false)

  useEffect(() => {
    setupNotifications()
  }, [])

  useEffect(() => {
    console.log(JSON.stringify(expoPushToken))
  }, [expoPushToken])

  useEffect(() => {
    navigation.setOptions(getOptions(screenSelected))
    Analytics.logEvent(TabNames[screenSelected] + "Click")
    Analytics.setCurrentScreen(TabNames[screenSelected], "Start")
  }, [screenSelected])

  return (
        <SafeAreaView style={Style.container}>

            <View style={Style.screen}>
                {getScreen(screenSelected)}
            </View>

            <Tabs selected={screenSelected}
                    onChange={x => setScreenSelected(x)}
                    onAddPress={addPress.bind(this)} />

            <Overlay isVisible={showOverlay}
                      onBackdropPress={() => { setShowOverlay(false) }}
                      overlayStyle={Style.helpOverlay} >
                <Text>Set the bodyweight you want to achieve in the &quot;Goal&quot; field. Then indicate your current weight.</Text>
            </Overlay>

        </SafeAreaView>
  )

  function addPress () {
    Analytics.logEvent("PlusClick")
    navigation.navigate("CreateRoutine")
  }

  function getScreen (tab) {
    if (tab === _tabs.home) {
      return (<HomeScreen navigation={navigation} expoPushToken={expoPushToken} />)
    } else if (tab === _tabs.goal) {
      return (<BodyStatsScreen navigation={navigation} />)
    } else if (tab === _tabs.history) {
      return (<HistoryScreen />)
    } else if (tab === _tabs.settings) {
      return (<SettingsScreen pushToken={expoPushToken} />)
    }
  }

  function getOptions (tab) {
    const title = getTabTitle(tab)
    const options = {
      headerTitle: _ => title,
      headerTitleContainerStyle: Style.headerContainer
    }

    if (tab === _tabs.home) {
      options.headerStyle = [Style.headerStyle, Style.headerStyleHome]
    } else {
      options.headerStyle = Style.headerStyle
    }

    return options
  }

  function getTabTitle (tab) {
    if (tab === _tabs.home) {
      return (
                <View style={Style.header}>
                    <Text style={[Style.headerBigText, Style.flex]}>Home</Text>
                </View>
      )
    } else if (tab === _tabs.goal) {
      return (
                <View style={Style.simpleHeader}>
                    <Text style={[Style.headerText, Style.flex]}>Goals</Text>
                    <View style={Style.flex} />
                    <Button icon={<Icon name='info-outline' type='material' color={"black"} />}
                            type='clear'
                            onPress={() => { setShowOverlay(true) }}
                    />
                </View>
      )
    } else if (tab === _tabs.history) {
      return (
                <View style={Style.simpleHeader}>
                    <Text style={[Style.headerText, Style.flex]}>History</Text>
                    <View style={Style.flex} />
                </View>
      )
    } else if (tab === _tabs.settings) {
      return (
                <View style={Style.simpleHeader}>
                    <Text style={[Style.headerText, Style.flex]}>Settings</Text>
                    <View style={Style.flex} />
                </View>
      )
    }
  }

  function setupNotifications () {
    registerForPushNotificationsAsync().then(token => setExpoPushToken(token))

    if (Platform.OS === "android") {
      Notifications.setNotificationChannelAsync("default", {
        name: "default",
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: "#FF231F7C"
      })
    }
  }

  async function registerForPushNotificationsAsync () {
    let token

    if (Constants.isDevice) {
      const { status: existingStatus } = await Permissions.getAsync(Permissions.NOTIFICATIONS)
      let finalStatus = existingStatus
      if (existingStatus !== "granted") {
        const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS)
        finalStatus = status
      }

      if (finalStatus !== "granted") {
        return
      }

      token = await Notifications.getExpoPushTokenAsync()
    }

    return token
  }
}
