import { StyleSheet } from "react-native"
import { FontColor, Theme } from "../../styles/Colors"

const _borderRadius = 28
const _hexButtonSize = 64

export default StyleSheet.create({
  addButton: {
    height: _hexButtonSize,
    marginTop: -24,
    width: _hexButtonSize
  },
  addButtonHex: {
    flex: 1,
    width: "100%"
  },
  addButtonPlus: {
    flex: 1,
    margin: "20%",
    width: "60%"
  },
  blueText: {
    color: Theme.primary
  },
  bottomSheet: {
    backgroundColor: Theme.surface,
    borderWidth: 2,
    height: "100%",
    paddingBottom: 32
  },
  container: {
    backgroundColor: Theme.surface,
    flex: 1
  },
  contentContainerStyle: {
    height: "100%"
  },
  flex: {
    flex: 1
  },
  header: {
    flex: 1
  },
  headerBigText: {
    fontSize: 36,
    fontWeight: "bold"
  },
  headerContainer: {
    flex: 1
  },
  headerIcon: {
    padding: 4
  },
  headerStyle: {
    backgroundColor: "#F6F6F6",
    borderWidth: 0,
    elevation: 0, // remove shadow on Android
    shadowOpacity: 0 // remove shadow on iOS
  },
  headerStyleHome: {
    height: 130
  },
  headerText: {
    fontSize: 24,
    fontWeight: "400",
    textAlignVertical: "center"
  },
  helpOverlay: {
    height: "auto",
    width: "85%"
  },
  panelHandle: {
    backgroundColor: "black",
    borderRadius: 4,
    height: 3,
    width: 40
  },
  panelHeader: {
    alignItems: "center",
    backgroundColor: "white",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingVertical: 20
  },
  row: {
    flexDirection: "row"
  },
  screen: {
    backgroundColor: Theme.background,
    borderBottomLeftRadius: _borderRadius,
    borderBottomRightRadius: _borderRadius,
    flex: 1
  },
  simpleHeader: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row",
    justifyContent: "flex-start",
    marginLeft: 8
  },
  tabIcon: {
    flex: 1,
    height: 24,
    margin: 6,
    tintColor: FontColor.onSurface,
    width: 24
  },
  tabIconImage: {
    flex: 1,
    padding: 16
  },
  tabIconSelected: {
    tintColor: Theme.primary
  },
  tabs: {
    backgroundColor: Theme.surface,
    paddingBottom: 8
  },
  tabsButton: {
    alignItems: "center",
    flex: 1
  },
  tabsButtons: {
    borderWidth: 0,
    flexDirection: "row",
    height: 50,
    paddingHorizontal: 16,
    paddingTop: 10
  },
  tabsSelectedButton: {
    backgroundColor: Theme.surface,
    borderColor: Theme.primary,
    borderRadius: 100,
    borderWidth: 1
  }
})
