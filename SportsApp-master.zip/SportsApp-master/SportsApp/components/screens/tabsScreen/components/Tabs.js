import React, { useEffect, useState } from "react"
import { ImageBackground, TouchableOpacity, View, Text, Image } from "react-native"
import Tooltip from "react-native-walkthrough-tooltip"
import { runOnKeyNotSet } from "../../../shared/functions/FirstRun"

import Style from "../Style"

export const _tabs = {
  home: 1,
  goal: 2,
  history: 3,
  settings: 4
}

export const TabNames = {
  1: "Home",
  2: "Goal",
  3: "History",
  4: "Settings"
}

const Icon = ({ source, isSelected }) => {
  const style = [Style.tabIcon]
  if (isSelected) style.push(Style.tabIconSelected)

  return (
        <Image resizeMode='contain' style={style} source={source}/>
  )
}

export const HomeButton = ({ isSelected }) => <Icon source={require("../../../../assets/icons/menu_bar/home.png")} isSelected={isSelected}/>
export const GoalButton = ({ isSelected }) => <Icon source={require("../../../../assets/icons/menu_bar/target.png")} isSelected={isSelected}/>
export const HistoryButton = ({ isSelected }) => <Icon source={require("../../../../assets/icons/menu_bar/history.png")} isSelected={isSelected}/>
export const SettingsButton = ({ isSelected }) => <Icon source={require("../../../../assets/icons/menu_bar/settings.png")} isSelected={isSelected}/>

const Button = ({ type, selected, onClick }) => {
  const isSelected = type === selected

  let button
  if (type === _tabs.home) {
    button = <HomeButton isSelected={isSelected} />
  } else if (type === _tabs.goal) {
    button = <GoalButton isSelected={isSelected} />
  } else if (type === _tabs.history) {
    button = <HistoryButton isSelected={isSelected} />
  } else if (type === _tabs.settings) {
    button = <SettingsButton isSelected={isSelected} />
  }

  return (
        <TouchableOpacity style={Style.tabsButton}
                          onPress={() => { onClick(type) }}>
            {button}
        </TouchableOpacity>
  )
}

const AddButton = ({ onPress }) => {
  return (
        <TouchableOpacity style={Style.addButton} activeOpacity={0.7} onPress={onPress}>
            <ImageBackground resizeMode='contain' style={Style.addButtonHex} source={require("../../../../assets/icons/menu_bar/hex_button.png")}>
                <Image resizeMode='contain' style={Style.addButtonPlus} source={require("../../../../assets/icons/menu_bar/plus.png")} />
            </ImageBackground>
        </TouchableOpacity>
  )
}

const AddButtonTooltip = () => {
  return (
    <View>
      <Text>Click &#39;+&#39; to create your first workout</Text>
    </View>
  )
}

export default function Tabs ({ selected, onChange, onAddPress }) {
  const [showAddButtonTooltip, setShowAddButtonTooltip] = useState()

  useEffect(() => {
    runOnKeyNotSet("firstHomeScreenLaunch", () => { setShowAddButtonTooltip(true) })
  }, [])

  return (
        <View style={Style.tabs}>
            <View style={Style.tabsButtons}>
                <Button type={_tabs.home} selected={selected} onClick={selectButton} />
                <Button type={_tabs.goal} selected={selected} onClick={selectButton} />
                <Tooltip isVisible={showAddButtonTooltip}
                         content={<AddButtonTooltip />}
                         placement="top"
                         arrowSize={{ width: 16, height: 24 }}
                         childContentSpacing={28}
                         onClose={() => setShowAddButtonTooltip(false)}>
                  <AddButton onPress={onAddPress} />
                </Tooltip>
                <Button type={_tabs.history} selected={selected} onClick={selectButton} />
                <Button type={_tabs.settings} selected={selected} onClick={selectButton} />
            </View>
        </View>
  )

  function selectButton (type) {
    if (typeof onChange !== "function") return
    onChange(type)
  }
}
