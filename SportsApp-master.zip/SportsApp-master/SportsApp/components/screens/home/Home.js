import React, { useEffect, useState } from "react"
import { View, FlatList, Text, Image, TouchableOpacity } from "react-native"

import { Default } from "../../constants/Settings"
import Storage from "../../controllers/Storage"
import { parseSettings } from "../../models/Settings"
import { createStreakToken } from "../../models/Token"
import { createNewStreak, createWeekRecord, parseStreak } from "../../models/Streak"

import Style from "./Style"
import CardItem from "./components/Card"
import StreakBar from "./components/StreakBar"

const _numColumns = 2
const _endpoint = "https://oko-simple-workout.herokuapp.com"

const RoutineCard = ({ routineKey, index, empty, navigation, onDelete }) => {
  const [routine, setRoutine] = useState({})

  useEffect(() => {
    if (typeof routineKey !== "string") return
    console.log("loading:" + routineKey)
    Storage.item.get(routineKey, (val) => {
      if (!val) return

      const routine = JSON.parse(val)
      if (!routine) return

      setRoutine(routine)
    })
  }, [routineKey])

  return (
    <TouchableOpacity onPress={() => { navigation.navigate("Routine", { routine: routine }) }} disabled={!routine?.name}>

      <CardItem item={{ text: routine?.name }} empty={empty} index={index} onDelete={() => { onDelete(routine?.id) }} />

    </TouchableOpacity>
  )
}

export default function Home ({ navigation, expoPushToken }) {
  const [routines, setRoutines] = useState([])
  const [currentStreak, setCurrentStreak] = useState()

  useEffect(() => {
    refreshRoutines()
    refreshStreak()
  }, [])

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      refreshRoutines()
      refreshStreak()
    })

    return unsubscribe
  }, [navigation])

  let emptyListPrompt
  if (routines.length < 1) {
    emptyListPrompt = (
      <View style={Style.emptyListBlock}>
        <Text>You don&#39;t have any trainings yet.</Text>
        <Text>Press &#39;+&#39; to create one.</Text>
      </View>
    )
  }

  return (
        <View style={Style.flex}>

            <View style={Style.streakTitleBlock}>
                <Image resizeMode='contain' style={Style.trainingsDot} source={require("../../../assets/icons/home/hex_dot.png")}/>
                <Text style={Style.trainingsText}>Your weekly streak progress</Text>
            </View>
            <StreakBar currentStreak={currentStreak} updateWeek={updateWeek.bind(this)} endStreak={endStreak.bind(this)} />

            <View style={Style.trainingsBlock}>
                <Image resizeMode='contain' style={Style.trainingsDot} source={require("../../../assets/icons/home/hex_dot.png")}/>
                <Text style={Style.trainingsText}>Your trainings</Text>
            </View>

            {emptyListPrompt}

            <FlatList
                data={formatData(routines)}
                style={Style.flex}
                contentContainerStyle={Style.list}
                renderItem={({ item, index }) => (<RoutineCard
                                                    routineKey={item}
                                                    index={index}
                                                    empty={item.empty}
                                                    navigation={navigation}
                                                    onDelete={(id) => { deleteRoutine(index, id) }} />)}
                keyExtractor={(_, index) => `item-${index}`}
                numColumns={_numColumns}
            />

        </View>
  )

  function deleteRoutine (index, id) {
    routines.splice(index, 1)
    setRoutines([...routines])

    Storage.routine.delete(id)
  }

  function refreshRoutines () {
    setRoutines([])
    Storage.routine.getAll((keys) => {
      setRoutines(keys)
    })
  }

  function refreshStreak () {
    setTimeout(() => {
      Storage.streak.current.get((val) => {
        const parsed = parseStreak(val)
        if (!parsed) {
          initializeStreak()
          return
        }

        setCurrentStreak(parsed)
      })
    }, 500)
  }

  function initializeStreak () {
    Storage.settings.get((val) => {
      let target = Default.streakTarget
      let startDay = Default.streakStartDay

      const json = parseSettings(val)
      if (json?.streak) {
        target = json.streak.target
        startDay = json.streak.startDay
      }

      const streak = createNewStreak(target, startDay)
      Storage.streak.current.set(streak)
      setCurrentStreak(streak)
    })
  }

  function updateWeek (name, complete, goal) {
    if (!currentStreak) return
    if (!currentStreak.weeks) currentStreak.weeks = {}

    const updatedStreak = JSON.parse(JSON.stringify(currentStreak))
    updatedStreak.weeks[name] = createWeekRecord(complete, goal)

    Storage.streak.current.set(updatedStreak)
    setCurrentStreak(updatedStreak)

    const streakToken = createStreakToken(expoPushToken, complete, goal)
    if (streakToken) {
      console.log("sending week token")
      fetch(_endpoint + "/streak", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(streakToken)
      })
    }
  }

  function endStreak () {
    // save old streak with an end date
    const updatedStreak = JSON.parse(JSON.stringify(currentStreak))
    updatedStreak.endDate = +new Date()
    Storage.streak.set(updatedStreak.id, updatedStreak)

    // start new streak
    initializeStreak()
  }

  function formatData (data) {
    const fullRows = Math.floor(data.length / _numColumns)
    let lastRowElements = data.length - (fullRows * _numColumns)
    while (lastRowElements !== 0 &&
               lastRowElements !== _numColumns) {
      data.push({ empty: true })
      lastRowElements += 1
    }

    return data
  }
}
