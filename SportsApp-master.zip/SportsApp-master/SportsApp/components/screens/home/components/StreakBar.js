import React, { useEffect, useState } from "react"
import { View, Text, Image, ImageBackground } from "react-native"

import Storage from "../../../controllers/Storage"
import { fastSplit, getDateText } from "../../../controllers/History"

import Style from "../Style"

export default function StreakBar ({ currentStreak, updateWeek, endStreak }) {
  const [currentCount, setCurrentCount] = useState(0)
  const [currentTarget, setCurrentTarget] = useState(1)

  const [completeCount, setCompleteCount] = useState(0)
  const [today] = useState(new Date())
  const [weekStart, setWeekStart] = useState()
  const [weekEnd, setWeekEnd] = useState()

  useEffect(() => {
    console.log(JSON.stringify(currentStreak))
    processStreak(currentStreak)
  }, [currentStreak])

  useEffect(() => {
    if (typeof updateWeek !== "function") return
    if (!weekStart || !weekEnd) return
    const weekName = getDateText(weekStart) + "|" + getDateText(weekEnd)
    updateWeek(weekName, completeCount, currentTarget)
  }, [completeCount, currentTarget])

  const progress = (completeCount ?? 0) / (currentTarget ?? 1)

  return (
        <View style={Style.streakBlock}>
            <View style={Style.streakCurrentBlock}>
                <View style={Style.streakCurrentProgressBack}>
                    <View style={Style.streakCurrentProgressFront}>
                        <View style={[Style.streakCurrentProgressFrontActive, { flex: progress }]}>

                        </View>
                    </View>
                </View>
                <ImageBackground resizeMode='contain' style={Style.streakCurrentHex} source={require("../../../../assets/icons/home/polygon.png")}>
                    <Text style={Style.streakCurrentText}>{completeCount}/{currentTarget}</Text>
                </ImageBackground>
            </View>
            <View style={Style.streakTotalBlock}>
                <Image resizeMode='contain' style={Style.streakTotalIcon} source={require("../../../../assets/icons/home/badge.png")}/>
                <Text style={Style.streakTotalText}>{currentCount}</Text>
            </View>
        </View>
  )

  function processStreak (streak) {
    if (!streak) return

    const weeks = streak.weeks
    if (weeks) {
      let count = 0
      const keys = Object.keys(weeks)
      for (const key in weeks) {
        if (weeks[key].complete >= weeks[key].target) {
          count++
        } else if (key !== keys[keys.length - 1]) {
          if (typeof endStreak === "function") endStreak()
          return
        }
      }

      setCurrentCount(count)
    }

    const s = streak.settings
    if (!s) return

    setCurrentTarget(s.target)

    const week = getWeekStartEnd(s.startDay)
    if (!week) return

    setWeekStart(week.start)
    setWeekEnd(week.end)

    updateCompleteCount(week.start, week.end)
  }

  function updateCompleteCount (weekStart, weekEnd) {
    Storage.history.getAll(keys => {
      const dates = {}
      keys?.forEach((key) => {
        const split = fastSplit(key)
        const date = split.date
        const workout = split.workout

        const d = new Date(date)
        if (d >= weekStart && d <= weekEnd) {
          if (!dates[date]) dates[date] = {}
          dates[date][workout] = true
        }
      })

      let count = 0
      for (const date in dates) {
        const workouts = dates[date]
        count += Object.keys(workouts)?.length ?? 0
      }

      setCompleteCount(count)
    })
  }

  function getWeekStartEnd (startDay) {
    if (!today) return
    if (typeof startDay === "undefined") return
    const weekday = today.getDay()
    let pre = weekday - startDay
    const post = (6 - pre) % 7
    if (pre < 0) pre = 6 - post

    return {
      start: getOffsetDate(pre * -1),
      end: getOffsetDate(post)
    }
  }

  function getOffsetDate (offset) {
    const date = new Date(today.getFullYear(), today.getMonth(), today.getDate() + offset)
    const text = getDateText(date)
    return new Date(text)
  }
}
