import React, { useEffect, useState, useRef } from "react"
import { View, FlatList, ScrollView, Text, Image, TouchableOpacity, Dimensions, StyleSheet } from "react-native"
import { Icon } from "react-native-elements"

import { confirmationDialog } from "../../../controllers/Dialog"
import Style, { ActiveColor } from "../Style"

export default function Card ({ item, empty, index, onDelete }) {
  if (empty === true) {
    return (
            <View style={[Style.card, Style.cardInvisible]} />
    )
  }

  return (
        <View style={Style.card}>
            <View style={Style.row}>
                <View style={Style.cardControlBlock}/>
                <Image resizeMode='contain' style={Style.cardIcon} source={getIcon(index)}/>
                <View style={Style.cardControlBlock}>
                    <TouchableOpacity style={Style.cardOptionsButton} onPress={deleteRoutineClick.bind(this)}>
                        <Image resizeMode='contain' style={Style.deleteIcon} source={require("../../../../assets/icons/action/delete.png")}/>
                    </TouchableOpacity>
                </View>
            </View>

            <Text style={Style.cardTitle}>{item?.text}</Text>
        </View>
  )

  function deleteRoutineClick () {
    if (typeof onDelete !== "function") return

    const name = item?.text ?? "this"

    confirmationDialog("Delete workout?",
      "Do you want to delete '" + name + "' workout?",
      () => {
        onDelete()
      },
      () => {
      })
  }

  function getIcon (index) {
    if (index % 2 === 0) {
      return require("../../../../assets/icons/home/workout_upd_1.png")
    } else {
      return require("../../../../assets/icons/home/workout_upd_2.png")
    }
  }
}
