import { StyleSheet } from "react-native"
import { Theme, FontColor } from "../../styles/Colors"

export const ActiveColor = Theme.primary

export default StyleSheet.create({
  card: {
    backgroundColor: Theme.surface,
    borderRadius: 16,
    height: 160,
    margin: 8,
    padding: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07,
    width: 160
  },
  cardControlBlock: {
    flex: 1
  },
  cardIcon: {
    height: 80,
    marginBottom: 4,
    marginTop: 8,
    width: 80
  },
  cardInvisible: {
    opacity: 0
  },
  cardOptionsButton: {
    paddingVertical: 8
  },
  cardTitle: {
    color: FontColor.onSurface,
    fontSize: 16,
    textAlign: "center"
  },
  deleteIcon: {
    height: 18,
    tintColor: Theme.secondary,
    width: 18
  },
  emptyListBlock: {
    alignItems: "center",
    flex: 1,
    justifyContent: "flex-end",
    paddingHorizontal: 16
  },
  flex: {
    flex: 1
  },
  list: {
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 32
  },
  row: {
    flexDirection: "row"
  },
  streakBlock: {
    flexDirection: "row",
    marginHorizontal: 16
  },
  streakCurrentBlock: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row"
  },
  streakCurrentHex: {
    alignItems: "center",
    height: 87,
    justifyContent: "center",
    marginLeft: -24,
    width: 87
  },
  streakCurrentProgressBack: {
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flex: 1,
    flexDirection: "row",
    height: 44,
    padding: 14,
    paddingRight: 24,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  streakCurrentProgressFront: {
    backgroundColor: "#ECFBFF",
    borderRadius: 50,
    flex: 1,
    flexDirection: "row"
  },
  streakCurrentProgressFrontActive: {
    backgroundColor: Theme.primary,
    borderRadius: 50
  },
  streakCurrentText: {
    color: FontColor.onPrimary,
    fontSize: 20,
    fontWeight: "500"
  },
  streakTitleBlock: {
    alignItems: "center",
    flexDirection: "row",
    marginHorizontal: 16
  },
  streakTotalBlock: {
    alignItems: "center",
    justifyContent: "center",
    width: 32
  },
  streakTotalIcon: {
    height: 24,
    width: 24
  },
  streakTotalText: {
    color: FontColor.onBackground,
    fontSize: 16,
    fontWeight: "500",
    marginTop: 4
  },
  trainingsBlock: {
    alignItems: "center",
    flexDirection: "row",
    marginHorizontal: 16,
    marginVertical: 8
  },
  trainingsDot: {
    height: 12,
    width: 12
  },
  trainingsText: {
    color: FontColor.onBackground,
    fontSize: 16,
    marginLeft: 4
  }
})
