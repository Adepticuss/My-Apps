import React, { useState, useEffect } from "react"
import { SafeAreaView, FlatList, StyleSheet, Text, TouchableOpacity, Alert } from "react-native"
import { ButtonGroup } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"

import Space from "../styles/Space"
import Colors from "../styles/Colors"
import Storage from "../controllers/Storage"
import { getExercise } from "../controllers/ExerciseData"
import HistoryCard, { Mode } from "../modules/HistoryCard"

const Card = ({ item, mode }) => (
    <HistoryCard name={item.key} type={mode} data={item.item} style={[Space.margin]} />
)

const Buttons = ["exercise", "date"]

export default function History ({ navigation }) {
  const [history, setHistory] = useState([])
  const [index, setIndex] = useState(0)
  const [mode, setMode] = useState(Mode.exercise)

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => {
        return (
                    <TouchableOpacity onPress={clearHistory.bind(this)} style={styles.headerButton}>
                        <Text>Clear</Text>
                    </TouchableOpacity>
        )
      }
    })

    updateHistory()
  }, [])

  useEffect(() => {
    if (index === 0) setMode(Mode.exercise)
    if (index === 1) setMode(Mode.date)
    if (index === 2) setMode(Mode.routine)
  }, [index])

  useEffect(() => {
    Analytics.logEvent("HistoryModeChange", { mode: mode + "" })
    updateHistory()
  }, [mode])

  return (
        <SafeAreaView style={styles.container}>

            <ButtonGroup onPress={(index) => { setIndex(index) }}
                            selectedIndex={index}
                            buttons={Buttons}
                            selectedButtonStyle={styles.selectedButton}
                            selectedTextStyle={styles.selectedText} />

            <FlatList data={history}
                        renderItem={({ item }) => <Card item={item} mode={mode} />}
                        keyExtractor={item => item.key}
                        style={styles.list} />

        </SafeAreaView>
  )

  function updateHistory () {
    setHistory([])

    Storage.history.getAll((keys) => {
      groupKeys(keys)
    })
  }

  function clearHistory () {
    confirmationDialog("Clear history",
      "Do you want to delete all history",
      () => {
        Storage.history.clear(() => updateHistory())
        Analytics.logEvent("ClearHistory", { size: history.length })
      })
  }

  function confirmationDialog (title, text, yesFunc, noFunc) {
    Alert.alert(
      title,
      text,
      [
        {
          text: "No",
          style: "cancel",
          onPress: noFunc
        },
        {
          text: "Yes",
          onPress: yesFunc
        }
      ]
    )
  }

  function groupKeys (keys) {
    const grouped = {}
    keys?.forEach((key) => {
      const split = fastSplit(key)

      const date = split.date
      const workout = split.workout
      const exerciseId = split.exercise

      let gKey1, gKey2
      if (mode === Mode.exercise) {
        gKey1 = getExercise(exerciseId)?.name ?? exerciseId
        gKey2 = date
      } else if (mode === Mode.date) {
        gKey1 = date
        gKey2 = exerciseId
      } else if (mode === Mode.routine) {
        // TODO routine mode (get from storage)
        gKey1 = workout
        gKey2 = exerciseId
      } else {
        // default to exercise for now
        gKey1 = exerciseId
        gKey2 = date
      }

      if (!gKey1 || !gKey2) return

      if (!grouped[gKey1]) {
        grouped[gKey1] = {}
      }

      if (!grouped[gKey1][gKey2]) {
        grouped[gKey1][gKey2] = []
      }

      grouped[gKey1][gKey2].unshift(key)
    })

    const newHistory = []
    for (const key in grouped) {
      const item = grouped[key]
      const data = {
        key: key,
        item: item
      }

      newHistory.push(data)
      // setHistory([data, ...history]);
    }

    newHistory.sort((a, b) => a.key < b.key)
    setHistory(newHistory)
  }
}

export function fastSplit (key) {
  const obj = {}

  // Get type
  const idxColon1 = key.indexOf(":")
  if (idxColon1 === -1) {
    return obj
  }

  obj.type = key.substring(0, idxColon1)

  // Get date
  const idxColon2 = key.indexOf(":", idxColon1 + 1)
  if (idxColon2 === -1) {
    return obj
  }

  obj.date = key.substring(idxColon1 + 1, idxColon2)

  // Get workout & exercise
  const idxColon3 = key.indexOf(":", idxColon2 + 1)
  if (idxColon3 === -1) {
    return obj
  }

  obj.workout = key.substring(idxColon2 + 1, idxColon3)
  obj.exercise = key.substring(idxColon3 + 1)

  return obj
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 8
  },
  headerButton: {
    padding: 12
  },
  list: {
    flex: 1
  },
  selectedButton: {
    backgroundColor: Colors.blue
  },
  selectedText: {
    color: "black"
  }
})
