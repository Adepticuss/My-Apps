import React, { useState } from "react"
import { View, SafeAreaView, Text, Platform } from "react-native"
import UUID from "react-native-uuid"
import KeyboardSpacer from "react-native-keyboard-spacer"
import * as Analytics from "expo-firebase-analytics"

import { TextButton } from "../../modules/basic/Buttons"
import Input from "../../modules/basic/Inputs"

// STYLEs
import Style from "./Style"
import Colors from "../../styles/Colors"
import Fonts from "../../styles/Fonts"
import Buttons from "../../styles/Buttons"

export default function CreateRoutine ({ navigation }) {
  const [inputName, setInputName] = useState("")
  const [inputError, setInputError] = useState(false)

  let spacer
  if (Platform.OS === "ios") {
    spacer = (<KeyboardSpacer />)
  }

  let warning
  if (inputError) {
    warning = (
              <Text style={[Style.subtitle, Fonts.default]}>
                  Please enter workout name
              </Text>
    )
  }

  return (
          <SafeAreaView style={[Style.view, Buttons.centrify]}>

              <View style={Style.description}>
                  <Text style={[Style.title, Fonts.bold]}>Stage 1</Text>
                  <Text style={[Style.subtitle, Fonts.default]}>Name your workout, ex. &#34;Monday workout&#34; or &#34;Legs day&#34;</Text>
              </View>

              {warning}
              <Input value={inputName}
                      onChangeText={(text) => setInputName(text)}
                      style={getInputStyle()}
                      placeholder="workout name"
                      />

              <TextButton text='Create'
                          onPress={createClick.bind(this)}
                          style={[Style.button]} />

              {spacer}

          </SafeAreaView>
  )

  function getInputStyle () {
    const style = [Fonts.bold]
    if (inputError === true) {
      style.push(Style.inputError)
    }

    return style
  }

  function createClick () {
    const newName = inputName?.trim()
    if (!newName) {
      Analytics.logEvent("RotineCreate", { nameComplete: "false" })
      setInputError(true)
      return
    }

    Analytics.logEvent("RotineCreate", { nameComplete: "true" })
    setInputError(false)

    const id = UUID.v4()?.substring(0, 8)
    const color = getColor(parseInt("0x" + id))

    const routine = {
      id: id,
      timestamp: +new Date(),
      name: newName,
      exercises: [],
      color: color,
      isNew: true
    }

    navigation.navigate("EditOverview", { routine: routine })

    return false
  }

  function getColor (number) {
    const colors = [
      Colors.lightGreen,
      Colors.lightYellow,
      Colors.silver
    ]

    return colors[number % colors.length]
  }
}
