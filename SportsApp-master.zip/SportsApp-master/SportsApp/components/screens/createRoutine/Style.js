import { StyleSheet } from "react-native"
import Colors from "../../styles/Colors"

export default StyleSheet.create({
  button: {
    backgroundColor: Colors.blue,
    marginBottom: 12,
    marginTop: 12,
    padding: 12
  },
  description: {
    alignItems: "center",
    marginBottom: 48,
    padding: 6
  },
  inputError: {
    borderColor: Colors.red
  },
  subtitle: {
    color: Colors.grey,
    fontSize: 12
  },
  title: {
    color: Colors.grey,
    fontSize: 24,
    marginBottom: 8
  },
  view: {
    flex: 1
  }
})
