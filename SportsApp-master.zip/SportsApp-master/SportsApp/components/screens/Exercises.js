import React, { useState, useEffect, useRef } from "react"
import { View, SafeAreaView, Text, FlatList, StyleSheet, TouchableOpacity } from "react-native"
import { Icon, ListItem, Avatar, Tooltip } from "react-native-elements"
import UUID from "react-native-uuid"
import * as Analytics from "expo-firebase-analytics"

import { getExercises, getGroupedExercises } from "../controllers/ExerciseData"
import MuscleImages, { DefaultImage } from "../controllers/MuscleImages"

import TypeSelector from "../modules/TypeSelector"
import { PickerCard } from "../modules/ExerciseCard"
import Button from "../modules/basic/Buttons"
import { SearchInput } from "../modules/basic/Inputs"
import Card, { TextCard } from "../modules/basic/Cards"

import Fonts from "../styles/Fonts"
import Space from "../styles/Space"
import Colors, { Alpha } from "../styles/Colors"

const ExerciseCard = ({ exercise, navigation, addMode, pickExercise, picked }) => {
  if (!addMode) {
    return (
            <TextCard text={exercise.name}
                        onPress={() => { navigation.navigate("ExerciseDetails", { exercise: exercise }) }}
                        style={[styles.exerciseCard]} />
    )
  }

  return (
        <PickerCard name={exercise.name} picked={!!picked}
                        style={[styles.pickerCard]}
                        click={pickExercise}
                        longPress={() => { navigation.navigate("ExerciseDetails", { exercise: exercise }) }} />
  )
}

const GroupCard = ({ name, items, selected, navigation, addMode, pickExercise, onPress }) => {
  const [expand, setExpand] = useState(false)

  useEffect(() => {
    if (expand === true) {
      if (onPress) onPress()
    }
  }, [expand])

  if (!(items?.length > 0)) return <View />

  const icon = MuscleImages[name] ?? DefaultImage

  if (!expand) {
    return (
            <ListItem bottomDivider chevron
                        containerStyle={styles.groupCard}
                        onPress={() => { setExpand(!expand) }} >
                <Avatar rounded source={icon} />
                <ListItem.Content>
                    <ListItem.Title>{name}</ListItem.Title>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
    )
  }

  const content = (
        <View style={styles.groupCardOpen}>
            <ListItem containerStyle={styles.groupCard}
                        onPress={() => { setExpand(!expand) }} >
                <Avatar rounded source={icon} />
                <ListItem.Content>
                    <ListItem.Title>{name}</ListItem.Title>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            <FlatList data={items}
                        renderItem={({ item }) => <ExerciseCard exercise={item} navigation={navigation} addMode={addMode} picked={selected[item.id]} pickExercise={(picked) => { pickExercise(item, picked) }} />}
                        keyExtractor={(_, index) => `exercise=${index}`} />
            <TouchableOpacity style={styles.collapseButton} onPress={() => { setExpand(!expand) }}>
                <Icon name='chevron-up' type='octicon' color={Colors.alpha.light} />
            </TouchableOpacity>
        </View>
  )

  return (
        <Card content={content}
                style={[styles.groupCard]}/>
  )
}

export default function Exercises ({ navigation, route, addMode }) {
  const [customEnabled, setCustomEnabled] = useState(false)
  const [exercises, setExercises] = useState(getExercises())
  const [grouped] = useState(getGroupedExercises())
  const [exName, setExName] = useState("")
  const [showModal, setShowModal] = useState(false)
  const [selected, setSelected] = useState({})
  const [selectedKeys, setSelectedKeys] = useState([])
  const [showHelp, setShowHelp] = useState(false)
  const listRef = useRef(null)
  const groupList = useRef(null)

  useEffect(() => {
    setExercises(getExercises(exName))
  }, [exName])

  useEffect(() => {
    if (showHelp === true) {
      listRef?.current.toggleTooltip()
    }
  }, [showHelp])

  useEffect(() => {
    const param1 = route?.params?.addMode ?? false
    const param2 = addMode ?? false
    setCustomEnabled(param1 | param2)
  }, [route?.params?.addMode, addMode])

  const input = (
        <SearchInput value={exName}
                        onChangeText={(val) => { setExName(val) }}
                        placeholder='exercise'
                        style={[Space.margin]} />
  )

  let button
  if (customEnabled) {
    button = (
            <Button onPress={saveExercisesClick.bind(this)}
                        content={<Text style={[Fonts.default]}>{getSaveButtonText(selectedKeys)}</Text>}
                        style={getSaveButtonStyle(selectedKeys)} />
    )
  }

  let list
  if (exName) {
    list = (
            <FlatList data={exercises}
                        renderItem={({ item }) => <ExerciseCard exercise={item} navigation={navigation} addMode={customEnabled} picked={selected[item.id]} pickExercise={(picked) => { pickExercise(item, picked) }} />}
                        keyExtractor={(_, index) => `exercises-${index}`}
                        style={[styles.list, Space.margin]}
                        keyboardShouldPersistTaps='handled' />
    )
  } else {
    list = (
            <FlatList data={Object.keys(grouped)}
                        ref={groupList}
                        renderItem={({ item, index }) => <GroupCard name={item} items={grouped[item]} selected={selected} navigation={navigation} onPress={() => { groupList?.current?.scrollToIndex({ index: index, viewOffset: -8 }) }} addMode={customEnabled} pickExercise={(item, picked) => { pickExercise(item, picked) }} />}
                        keyExtractor={(_, index) => `exercises-${index}`}
                        style={[styles.list, Space.margin]} />
    )
  }

  const help = (
        <Text style={styles.helpText}>Select exercise under muscle group</Text>
  )

  return (
        <SafeAreaView style={styles.container}>
            {input}

            {list}

            <Tooltip ref={listRef} popover={help} height={70} width={200} toggleOnPress={false} containerStyle={styles.help} pointerColor={Colors.blue}>
                {button}
            </Tooltip>

            <TypeSelector visible={showModal} closed={() => { setShowModal(false) }} typeClicked={finilizeExercise} />
        </SafeAreaView>
  )

  function getSaveButtonStyle (selected) {
    const style = [styles.exerciseSelectorButton, Space.margin]

    if (selected?.length > 0) {
      style.push(styles.active)
    }

    return style
  }

  function getSaveButtonText (selected) {
    if (selected?.length > 0) {
      return "✓ Save " + selected?.length + " exercise(s)"
    }

    return "Pick exercise"
  }

  function saveExercisesClick () {
    if (selectedKeys?.length > 0) {
      const newExercise = Object.values(selected)
      Analytics.logEvent("SaveExercises", { length: newExercise?.length + "" })
      navigation.navigate("EditOverview", { newExercise: newExercise })
    } else {
      Analytics.logEvent("SaveExercisesEmpty")
      setShowHelp(false)
      setTimeout(() => { setShowHelp(true) }, 200)
    }
  }

  function pickExercise (exr, picked) {
    if (picked === true) {
      // Add new exercise to selected list
      selected[exr.id] = exr
      setSelected(selected)

      Analytics.logEvent("PickExercise", {
        searchUsed: exName.length > 0 ? "yes" : "no"
      })
    } else {
      // Remove exercise from selected
      delete selected[exr.id]
      setSelected(selected)

      Analytics.logEvent("UnpickExercise", {
        searchUsed: exName.length > 0 ? "yes" : "no"
      })
    }

    setSelectedKeys([...Object.keys(selected)])
  }

  function finilizeExercise (type) {
    setShowModal(false)

    const cleanName = exName?.trim()
    if (!cleanName) {
      return
    }

    const id = UUID.v4()?.substring(0, 8)
    const exercise = {
      id: id,
      name: cleanName,
      type: type,
      custom: true
    }

    navigation.navigate("EditOverview", { newExercise: [exercise] })
  }
}

const styles = StyleSheet.create({
  active: {
    backgroundColor: Colors.lightGreen
  },
  collapseButton: {
    width: "100%"
  },
  container: {
    flex: 1
  },
  exerciseCard: {
    backgroundColor: Colors.silver,
    padding: 10
  },
  exerciseSelectorButton: {
    backgroundColor: Colors.silver,
    marginBottom: 16,
    marginTop: 8,
    padding: 12
  },
  groupCard: {
    alignItems: "center",
    backgroundColor: "white",
    margin: 0
  },
  groupCardOpen: {
    width: "100%"
  },
  help: {
    backgroundColor: "white",
    borderColor: Colors.blue,
    borderWidth: 1
  },
  helpText: {
    fontSize: 16
  },
  list: {
    flex: 1
  },
  pickerCard: {
    backgroundColor: Colors.blue + Alpha.light,
    padding: 8
  }
})
