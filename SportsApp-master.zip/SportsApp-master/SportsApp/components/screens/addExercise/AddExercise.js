import React, { useState, useRef, useEffect } from "react"
import { View, SafeAreaView, Text, AsyncStorage } from "react-native"
import { ButtonGroup, Tooltip } from "react-native-elements"
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet"
import * as Analytics from "expo-firebase-analytics"
import Exercises from "../Exercises"
import Custom from "../customExercise/CustomExercise"
import Colors from "../../styles/Colors"
import Style from "./Style"

const _modes = {
  list: 0,
  custom: 1
}

const buttons = ["find exercise", "custom"]

export default function AddExercise ({ navigation }) {
  const [mode, setMode] = useState(_modes.list)
  const selectorRef = useRef(null)

  useEffect(() => {
    AsyncStorage.getItem("firstAddScreenComplete", (_, r) => {
      if (r === "true") return
      setTimeout(() => { selectorRef.current.toggleTooltip() }, 500)
      AsyncStorage.setItem("firstAddScreenComplete", "true")
    })
  }, [])

  let page
  if (mode === _modes.list) {
    page = (
      <Exercises navigation={navigation} addMode={true} />
    )
  } else if (mode === _modes.custom) {
    page = (<Custom navigation={navigation} />)
  }

  const selectorHelp = (
    <Text style={Style.helpText}>Switch to create custom exercise</Text>
  )

  return (
    <BottomSheetModalProvider>
      <SafeAreaView style={Style.container}>
          <Tooltip ref={selectorRef} popover={selectorHelp} height={80} toggleOnPress={false} containerStyle={Style.help} pointerColor={Colors.blue}>
              <ButtonGroup onPress={(index) => { modeChange(index) }}
                              selectedIndex={mode}
                              buttons={buttons}
                              selectedButtonStyle={Style.selectedButton}
                              selectedTextStyle={Style.selectedText} />
          </Tooltip>

          <View style={Style.page}>
              {page}
          </View>

      </SafeAreaView>
    </BottomSheetModalProvider>
  )

  function modeChange (index) {
    if (mode === index) return
    setMode(index)
    Analytics.logEvent("AddExerciseMode", { name: buttons[index] })
  }
}
