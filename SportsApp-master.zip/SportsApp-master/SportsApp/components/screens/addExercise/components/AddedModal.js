import React, { useState, useEffect } from "react"
import { View, Text, FlatList, StyleSheet, Image, TouchableOpacity } from "react-native"
import Animated from "react-native-reanimated"
import BottomSheet from "@gorhom/bottom-sheet"
import Tooltip from "react-native-walkthrough-tooltip"

import { runOnKeyNotSet } from "../../../shared/functions/FirstRun"
import { getExerciseImage } from "../../../controllers/ExerciseImages"
import { TextButton } from "../../../modules/Buttons"
import { Theme, FontColor } from "../../../styles/Colors"

const ExerciseCard = ({ exercise, onDelete }) => {
  const [exerciseName, setExerciseName] = useState()
  const [exerciseId, setExerciseId] = useState()

  useEffect(() => {
    if (typeof exercise !== "object") return

    setExerciseName(exercise.name)
    setExerciseId(exercise.id)
  }, [exercise])

  return (
        <View style={styles.exerciseCard}>
            <View style={styles.row}>
                <View style={styles.exerciseDeleteIcon} />
                <Image resizeMode='contain' style={styles.exerciseImage} source={getExerciseImage(exerciseId, exercise.custom)} />
                <TouchableOpacity onPress={deleteClick.bind(this)}>
                    <Image resizeMode='contain' style={styles.exerciseDeleteIcon} source={require("../../../../assets/icons/action/delete.png")} />
                </TouchableOpacity>
            </View>

            <Text style={styles.exerciseTitle}>{exerciseName}</Text>
        </View>

  )

  function deleteClick () {
    if (typeof onDelete !== "function") return
    onDelete()
  }
}

const SaveWorkoutButton = ({ onSave }) => {
  const [showTooltip, setShowTooltip] = useState()

  useEffect(() => {
    runOnKeyNotSet("firstSaveWorkoutButton", () => { setShowTooltip(true) })
  }, [])

  const tooltip = (
    <Text>Press to save your workout, or add more exercises first</Text>
  )

  return (
    <Tooltip isVisible={showTooltip}
              content={tooltip}
              arrowSize={{ width: 16, height: 24 }}
              onClose={() => setShowTooltip(false)}>
      <TextButton text='Save workout' onPress={onSave} />
    </Tooltip>
  )
}

export default function ExerciseModal ({ exercises, onDelete, onSave }) {
  const [exerciseList, setExerciseList] = useState([])
  const bottomSheetRef = React.createRef()
  const fall = new Animated.Value(1)

  useEffect(() => {
    if (typeof exercises === "undefined") return
    setExerciseList(Object.values(exercises))
  }, [exercises])

  const renderContent = () => {
    return (
            <View style={styles.panel}>
                {getSmallContent(exercises)}

                <Animated.View style={[styles.panelLarge]}>
                    <FlatList
                        data={exerciseList}
                        renderItem={({ item }) => <ExerciseCard exercise={item} onDelete={() => { deleteExercise(item.id) }} />}
                        horizontal={true}
                    />
                </Animated.View>

            </View>
    )
  }

  const renderHeader = () => (
        <View style={styles.panelHeader}>
            <View style={styles.panelHandle} />
        </View>
  )

  return (
        <BottomSheet
                ref={bottomSheetRef}
                snapPoints={[140, 320]}
                index={0}
                animatedPosition={fall}
                overDragResistanceFactor={2.5}
                handleComponent={renderHeader}
                children={renderContent}
            >
        </BottomSheet>
  )

  function getSmallContent (exercises) {
    const keys = Object.keys(exercises)
    if (keys?.length > 0) {
      return (
                <View style={styles.panelSmall}>
                    <Text style={styles.countText}>Added {keys?.length} exercises</Text>
                    <SaveWorkoutButton onSave={onSave} />
                </View>
      )
    } else {
      return (
                <View style={styles.panelSmall}>
                    <Text style={styles.countText}>Please select exercises</Text>
                </View>
      )
    }
  }

  function deleteExercise (id) {
    if (typeof onDelete !== "function") return
    delete exercises[id]
    onDelete(JSON.parse(JSON.stringify(exercises)))
  }
}

const styles = StyleSheet.create({
  countText: {
    fontSize: 18,
    fontWeight: "200"
  },
  exerciseCard: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    height: 139,
    justifyContent: "center",
    margin: 4,
    padding: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07,
    width: 137
  },
  exerciseDeleteIcon: {
    height: 18,
    width: 18
  },
  exerciseImage: {
    height: 67,
    width: 67
  },
  exerciseTitle: {
    alignSelf: "flex-end",
    color: FontColor.onBackground,
    fontWeight: "400",
    marginTop: 8,
    textAlign: "center",
    width: "100%"
  },
  panel: {
    backgroundColor: "white",
    height: 277
  },
  panelHandle: {
    backgroundColor: "black",
    borderRadius: 4,
    height: 3,
    width: 40
  },
  panelHeader: {
    alignItems: "center",
    backgroundColor: "white",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingVertical: 20,
    shadowOffset: { height: -4, width: 0 },
    shadowOpacity: 0.07
  },
  panelLarge: {
    height: 158,
    justifyContent: "center",
    paddingHorizontal: 6
  },
  panelSmall: {
    alignItems: "center",
    flexDirection: "row",
    height: 80,
    justifyContent: "space-around",
    padding: 8
  },
  row: {
    flexDirection: "row"
  }
})
