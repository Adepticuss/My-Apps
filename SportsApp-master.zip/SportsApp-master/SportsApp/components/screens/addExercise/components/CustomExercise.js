import React, { useState, useRef } from "react"
import { View, Text, StyleSheet } from "react-native"
import { Tooltip } from "react-native-elements"
import UUID from "react-native-uuid"

import { InputMode } from "../../../constants/Input"
import { TypeButtons } from "../../../modules/TypeSelector"
import { TextInput } from "../../../modules/Input"
import { TextButton } from "../../../modules/Buttons"
import { Theme, FontColor } from "../../../styles/Colors"

import Style from "../Style"

export default function CustomExercise ({ onCustomAdd }) {
  const [exerciseType, setExerciseType] = useState(InputMode.count)
  const [exerciseName, setExerciseName] = useState()
  const tooltipRef = useRef(null)

  return (
        <View style={Style.flex}>
            <Text style={styles.label}>Custom exercise</Text>
            <Tooltip
                    ref={tooltipRef}
                    popover={<Text>Please enter exercise name</Text>}
                    containerStyle={Style.help}
                    width={200}
                    pointerColor={Theme.secondary}>
                <View style={styles.inputBlock}>
                    <TextInput placeholder='Name of the exercise' value={exerciseName} onChangeText={setExerciseName} />
                </View>
            </Tooltip>

            <TypeButtons type={exerciseType} onChange={setExerciseType} />

            <View style={styles.createButtonBlock}>
                <TextButton text='Create custom' onPress={createClick.bind(this)} />
            </View>
        </View>
  )

  function createClick () {
    if (typeof onCustomAdd !== "function") return

    const cleanName = exerciseName?.trim()
    if (cleanName?.length > 0) {
      createExercise(cleanName, exerciseType)
    } else {
      tooltipRef?.current?.toggleTooltip()
    }
  }

  function createExercise (name, type) {
    const id = UUID.v4()?.substring(0, 8)
    const exercise = {
      id: id,
      name: name,
      type: type,
      custom: true
    }

    onCustomAdd(exercise)
    setExerciseName("")
  }
}

const styles = StyleSheet.create({
  createButtonBlock: {
    alignItems: "center",
    marginTop: 32,
    width: "100%"
  },
  inputBlock: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flexDirection: "row",
    marginBottom: 6,
    marginHorizontal: 12,
    paddingVertical: 10,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  label: {
    color: FontColor.onBackground,
    fontSize: 24,
    marginVertical: 8,
    textAlign: "center"
  }
})
