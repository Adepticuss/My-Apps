import React, { useState, useEffect } from "react"
import { TouchableOpacity, View, Text, FlatList, StyleSheet } from "react-native"
import { Image } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"
import Tooltip from "react-native-walkthrough-tooltip"

import { runOnKeyNotSet } from "../../../shared/functions/FirstRun"
import { Muscles, getGroupedExercises } from "../../../controllers/ExerciseData"
import { NewMuscles } from "../../../controllers/MuscleImages"
import ExerciseModal from "./ExerciseModal"

import { Theme } from "../../../styles/Colors"
import Style from "../Style"

const MuscleCard = ({ muscle, onMuscleSelected }) => {
  const [muscleName, setMuscleName] = useState()
  const [showTooltip, setShowTooltip] = useState()

  useEffect(() => {
    if (typeof muscle !== "string") return
    setMuscleName(muscle[0].toUpperCase() + muscle.substring(1))

    if (muscle === "chest") {
      runOnKeyNotSet("firstMuscleCard", () => { setShowTooltip(true) })
    }
  }, [muscle])

  const card = (
    <View style={styles.muscleCard}>
        <Image resizeMode='contain' style={styles.cardIcon} source={NewMuscles[muscle]} transitionDuration={120} placeholderStyle={styles.placeholder} transition={true}/>
        <Text style={styles.muscleTitle}>{muscleName}</Text>
    </View>
  )

  const tooltip = (
    <Text>Choose muscle group to select exercise(s)</Text>
  )

  return (
    <Tooltip isVisible={showTooltip}
              content={tooltip}
              placement="bottom"
              displayInsets={{ left: 0 }}
              arrowSize={{ width: 16, height: 24 }}
              onClose={() => setShowTooltip(false)}>
      <TouchableOpacity onPress={showMuscleCategory.bind(this)}>
        {card}
      </TouchableOpacity>
    </Tooltip>
  )

  function showMuscleCategory () {
    if (typeof onMuscleSelected !== "function") return
    onMuscleSelected(muscle)
  }
}

export default function MuscleList ({ selected, onSelectedUpdate }) {
  const [muscles] = useState(Object.keys(Muscles))
  const [grouped] = useState(getGroupedExercises())
  const [showMuscleExercises, setShowMuscleExercises] = useState(false)
  const [selectedMuscle, setSelectedMuscle] = useState()
  const [selectedExercises, setSelectedExericses] = useState()

  useEffect(() => {
    if (typeof selected === "undefined") return
    setSelectedExericses(selected)
  }, [selected])

  return (
        <View style={Style.muscleList}>
            <FlatList
                data={muscles}
                renderItem={({ item }) => <MuscleCard muscle={item} onMuscleSelected={onMuscleSelected.bind(this)} />}
                keyExtractor={(_, i) => `muscle-${i}`}
                numColumns={3}
                style={Style.flex}
                contentContainerStyle={styles.list}
            />

            <View>
                <ExerciseModal
                    show={showMuscleExercises}
                    muscle={selectedMuscle}
                    selected={selectedExercises}
                    exercises={grouped[selectedMuscle]}
                    onClose={onModalClose.bind(this)}
                />
            </View>

        </View>
  )

  function onModalClose (selectedExercises) {
    Analytics.logEvent("ExerciseSwipeDown")
    setSelectedExericses(selectedExercises)
    onSelectedUpdate(selectedExercises)
    setShowMuscleExercises(false)
  }

  function onMuscleSelected (muscle) {
    Analytics.logEvent("MuscleClick", { muscle: muscle })
    setSelectedMuscle(muscle)
    setShowMuscleExercises(true)
  }
}

const styles = StyleSheet.create({
  cardIcon: {
    borderRadius: 16,
    height: 72,
    width: 72
  },
  list: {
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 32
  },
  muscleCard: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    height: 128,
    justifyContent: "center",
    margin: 2,
    padding: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07,
    width: 111
  },
  muscleTitle: {
    alignSelf: "flex-end",
    fontWeight: "200",
    marginTop: 8,
    textAlign: "center",
    width: "100%"
  },
  placeholder: {
    backgroundColor: Theme.surface
  }
})
