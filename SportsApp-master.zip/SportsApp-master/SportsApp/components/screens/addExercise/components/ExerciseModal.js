import React, { useState, useEffect } from "react"
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native"
import { BottomSheetFlatList } from "@gorhom/bottom-sheet"
import Tooltip from "react-native-walkthrough-tooltip"
import * as Analytics from "expo-firebase-analytics"

import { runOnKeyNotSet } from "../../../shared/functions/FirstRun"
import { getExerciseImage } from "../../../controllers/ExerciseImages"
import { CustomBottomSheetModal } from "../../../modules/BottomSheet"
import { FontColor, Theme } from "../../../styles/Colors"

const ExerciseCard = ({ exercise, isSelected, onPress }) => {
  const [exerciseName, setExerciseName] = useState()
  const [exerciseId, setExerciseId] = useState()

  useEffect(() => {
    if (typeof exercise !== "object") return

    setExerciseName(exercise.name)
    setExerciseId(exercise.id)
  }, [exercise])

  const cardStyle = [styles.exerciseCard]
  const titleStyle = [styles.exerciseTitle]
  if (isSelected === true) {
    cardStyle.push(styles.exerciseCardActive)
    titleStyle.push(styles.exerciseTitleActive)
  }

  return (
        <TouchableOpacity onPress={onPress}>
            <View style={cardStyle}>
                <Image resizeMode='contain' style={styles.exerciseImage} source={getExerciseImage(exerciseId)} />
                <Text style={titleStyle}>{exerciseName}</Text>
            </View>
        </TouchableOpacity>

  )
}

export default function ExerciseModal ({ show, muscle, exercises, selected, onClose }) {
  const [selectedExercises, setSelectedExericses] = useState({})
  const [selectedIds, setSelectedIds] = useState([])
  const [muscleName, setMuscleName] = useState()
  const [showTooltip, setShowTooltip] = useState()

  useEffect(() => {
    if (typeof selected === "undefined") return
    setSelectedExericses(selected)
    console.log()
  }, [selected])

  useEffect(() => {
    if (typeof muscle !== "string") return
    setMuscleName(muscle[0].toUpperCase() + muscle.substring(1))
    runOnKeyNotSet("firstExerciseModal", () => { setTimeout(() => { setShowTooltip(true) }, 678) })
  }, [muscle])

  useEffect(() => {
  }, [selectedIds])

  const tooltip = (
    <Text>Select your exercises and pull down when done</Text>
  )

  const renderContent = () => {
    return (
        <View style={styles.panel}>
          <Tooltip isVisible={showTooltip}
                   content={tooltip}
                   showChildInTooltip={false}
                   placement="top"
                   displayInsets={{ left: 0 }}
                   arrowSize={{ width: 0, height: 0 }}
                   onClose={() => setShowTooltip(false)}>
            <Text style={styles.muscleTitle}>{muscleName}</Text>
          </Tooltip>
            <BottomSheetFlatList
                data={exercises ?? []}
                renderItem={({ item }) => <ExerciseCard exercise={item} onPress={() => exerciseClick(item)} isSelected={isSelected(item)} />}
                numColumns={2}
                contentContainerStyle={styles.list}
            />
        </View>
    )
  }

  return (
            <CustomBottomSheetModal show={show}
                            onClose={close.bind(this)}
                            renderContent={renderContent}
                            size={"80%"}
            />

  )

  function isSelected (exercise) {
    const id = exercise?.id
    if (typeof id !== "string") return false
    if (typeof selectedExercises[id] === "undefined") return false
    return true
  }

  function exerciseClick (exercise) {
    const id = exercise?.id
    if (typeof id !== "string") return

    Analytics.logEvent("ExerciseClick", { exercise: exercise.name })
    const newSelected = JSON.parse(JSON.stringify(selectedExercises))
    if (typeof newSelected[id] === "undefined") {
      newSelected[id] = exercise
    } else {
      delete newSelected[id]
    }

    setSelectedExericses(newSelected)

    const keys = Object.keys(newSelected)
    setSelectedIds([...keys])
  }

  function close () {
    if (typeof onClose !== "function") return
    onClose(selectedExercises)
  }
}

const styles = StyleSheet.create({
  exerciseCard: {
    alignItems: "center",
    backgroundColor: Theme.background,
    borderRadius: 16,
    height: 140,
    justifyContent: "center",
    margin: 6,
    padding: 8,
    width: 152
  },
  exerciseCardActive: {
    backgroundColor: Theme.primary
  },
  exerciseImage: {
    height: 82,
    width: 82
  },
  exerciseTitle: {
    alignSelf: "flex-end",
    color: FontColor.onBackground,
    fontWeight: "400",
    marginTop: 8,
    textAlign: "center",
    width: "100%"
  },
  exerciseTitleActive: {
    color: FontColor.onPrimary
  },
  list: {
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 96
  },
  muscleTitle: {
    fontSize: 20,
    fontWeight: "300",
    textAlign: "center",
    width: "100%"
  },
  panel: {
    backgroundColor: "white",
    height: "100%"
  }
})
