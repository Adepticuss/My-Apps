import { StyleSheet } from "react-native"
import Colors, { Theme } from "../../styles/Colors"

export default StyleSheet.create({
  container: {
    backgroundColor: Theme.background,
    flex: 1
  },
  flex: {
    flex: 1
  },
  help: {
    backgroundColor: "white",
    borderColor: Theme.secondary,
    borderWidth: 1
  },
  helpText: {
    fontSize: 16
  },
  muscleList: {
    flex: 1,
    paddingBottom: 154
  },
  page: {
    flex: 1
  },
  row: {
    flexDirection: "row"
  },
  screen: {
    flex: 1
  },
  selectedButton: {
    backgroundColor: Colors.blue
  },
  selectedText: {
    color: "black"
  }
})
