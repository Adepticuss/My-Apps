import React, { useState, useRef, useEffect } from "react"
import { View, Text, Platform } from "react-native"
import { Tooltip } from "react-native-elements"
import UUID from "react-native-uuid"
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet"
import * as Analytics from "expo-firebase-analytics"

import WorkoutName from "../../modules/WorkoutName"
import ButtonGroup from "../../modules/ButtonGroup"
import Storage from "../../controllers/Storage"

import MuscleList from "./components/MuscleList"
import CustomExercise from "./components/CustomExercise"
import AddedModal from "./components/AddedModal"

import Style from "./Style"
import { Theme } from "../../styles/Colors"

const Mode = {
  find: 0,
  custom: 1
}

export default function AddExercise ({ navigation, route }) {
  const [showControls, setShowControls] = useState(false)
  const [workoutName, setWorkoutName] = useState()
  const [workoutNameFocus, setWorkoutNameFocus] = useState()
  const [addMode, setAddMode] = useState(Mode.find)
  const [addedExercises, setAddedExercises] = useState({})
  const tooltipRef = useRef(null)

  useEffect(() => {
    if (showControls) return

    const name = workoutName?.trim()
    if (!workoutNameFocus && name?.length > 0) {
      setShowControls(true)
    }
  }, [workoutNameFocus])

  let controls
  if (showControls) {
    controls = (
      <View style={Style.flex}>
        <ButtonGroup
            options={["Find exercise", "Custom"]}
            selected={addModeToIndex(addMode)}
            onChange={x => setAddMode(indexToAddMode(x))}
        />

        <View style={Style.screen}>
            {addMode === Mode.find
              ? <MuscleList selected={addedExercises} onSelectedUpdate={onSelectedUpdate.bind(this)} />
              : <CustomExercise onCustomAdd={onCustomAdd.bind(this)} />
            }
        </View>

        {addMode === Mode.find && (workoutNameFocus !== true || Platform.OS === "ios")
          ? <AddedModal exercises={addedExercises} onDelete={updateExercises} onSave={save.bind(this)} />
          : null
        }
      </View>
    )
  }

  return (
        <BottomSheetModalProvider>
            <View style={Style.container}>
                {route.params?.edit === true
                  ? null
                  : addMode === Mode.find
                    ? <Tooltip
                        ref={tooltipRef}
                        popover={<Text>Please enter workout name</Text>}
                        containerStyle={Style.help}
                        width={200}
                        toggleOnPress={false}
                        pointerColor={Theme.secondary}>
                        <WorkoutName workoutName={workoutName} setWorkoutName={setWorkoutName} onFocusChange={setWorkoutNameFocus} />
                    </Tooltip>
                    : null
                }

                {controls}

            </View>
        </BottomSheetModalProvider>
  )

  function onSelectedUpdate (selected) {
    setAddedExercises(selected)
  }

  function onCustomAdd (exercise) {
    addedExercises[exercise.id] = exercise
    setAddedExercises(JSON.parse(JSON.stringify(addedExercises)))
    setAddMode(Mode.find)
  }

  function updateExercises (exercises) {
    setAddedExercises(exercises)
  }

  function save () {
    if (route.params?.edit === true) {
      navigation.navigate("EditOverview", { addedExercises: addedExercises })
    }

    const name = workoutName?.trim()
    if (name?.length > 0) {
      Analytics.logEvent("SaveWorkout")
      saveRoutine(name)
    } else {
      Analytics.logEvent("SaveWorkoutNoName")
      tooltipRef?.current?.toggleTooltip()
    }
  }

  function saveRoutine (name) {
    const current = Object.values(addedExercises)

    current.forEach((x) => {
      if (x.custom === true) {
        Storage.exercise.set(x.id, x)
      }
    })

    const id = UUID.v4()?.substring(0, 8)
    const seed = UUID.v4()?.substring(0, 8)
    const routine = {
      id: id,
      created: +new Date(),
      name: name,
      exercises: current,
      iconSeed: seed
    }

    Storage.routine.set(routine)

    navigation.reset({
      index: 0,
      routes: [
        { name: "Start" },
        { name: "Routine", params: { routine: routine } }
      ]
    })
  }

  function addModeToIndex (mode) {
    Analytics.logEvent("Custom_Find", { mode: mode })

    if (mode === Mode.find) {
      return 0
    } else if (mode === Mode.custom) {
      return 1
    }
  }

  function indexToAddMode (index) {
    if (index === 0) {
      return Mode.find
    } else if (index === 1) {
      return Mode.custom
    }
  }
}
