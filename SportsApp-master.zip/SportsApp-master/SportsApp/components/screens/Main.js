import React, { useState, useEffect } from "react"
import { StyleSheet, FlatList, Text, View, SafeAreaView, TouchableOpacity, TouchableHighlight, Alert, Dimensions, Platform } from "react-native"
import Constants from "expo-constants"
import { Icon, Tooltip } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"
import * as Notifications from "expo-notifications"
import * as Permissions from "expo-permissions"
import { ProgressChart } from "react-native-chart-kit"

import { RoundButton } from "../modules/basic/Buttons"
import { TextButtonCard } from "../modules/basic/Cards"

import Space from "../styles/Space"
import Colors, { Alpha } from "../styles/Colors"

import { Default } from "../constants/Settings"
import Storage from "../controllers/Storage"
import { parseSettings } from "../models/Settings"
import { createToken, createStreakToken } from "../models/Token"
import { createNewStreak, createWeekRecord, parseStreak } from "../models/Streak"
import { fastSplit, getDateText } from "../controllers/History"

const _backColor = "#ffffffcc"
const _frontColor = "#000000cc"
const _endpoint = "https://oko-simple-workout.herokuapp.com"

const _config = {
  backgroundColor: "#ffffff",
  backgroundGradientFrom: "#ffffff",
  backgroundGradientTo: "#ffffff",
  color: (opacity = 1) => `rgba(84, 221, 255, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`
}

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: true
  })
})

const RoutineCard = ({ routineKey, navigation, deleteClick }) => {
  const [routine, setRoutine] = useState({})

  useEffect(() => {
    console.log("loading:" + routineKey)
    Storage.item.get(routineKey, (val) => {
      if (!val) return

      const routine = JSON.parse(val)
      if (!routine) return

      setRoutine(routine)
    })
  }, [routineKey])

  return (
    <TouchableOpacity onPress={() => { navigation.navigate("Routine", { routine: routine }) }} disabled={!routine?.name}>

      <TextButtonCard text={routine.name}
                      textStyle={[styles.routineText]}
                      buttonContent={<Text style={styles.routineText}>X</Text>}
                      style={[styles.routineCard, Space.margin]}
                      buttonClick={deleteClick} />

    </TouchableOpacity>
  )
}

const StreakButton = ({ currentStreak, bestStreak, updateWeek, endStreak }) => {
  const [currentCount, setCurrentCount] = useState(0)
  const [bestCount, setBestCount] = useState(0)
  const [currentTarget, setCurrentTarget] = useState()

  const [completeCount, setCompleteCount] = useState(0)
  const [weekComplete, setWeekComplete] = useState(false)
  const [today] = useState(new Date())
  const [weekStart, setWeekStart] = useState()
  const [weekEnd, setWeekEnd] = useState()

  useEffect(() => {
    if (bestStreak?.weeks) {
      const weekCount = Object.keys(bestStreak.weeks)?.length
      setBestCount(weekCount)
    }
  }, [bestStreak])

  useEffect(() => {
    if (!currentStreak) return
    processStreak(currentStreak)
  }, [currentStreak])

  useEffect(() => {
    setWeekComplete(completeCount >= currentTarget)

    if (typeof updateWeek !== "function") return
    if (!weekStart || !weekEnd) return
    const weekName = getDateText(weekStart) + "|" + getDateText(weekEnd)
    updateWeek(weekName, completeCount, currentTarget)
  }, [completeCount, currentTarget])

  const width = Dimensions.get("window").width - 24
  const streakMenu = (
    <View style={styles.streakMenu}>
      <Text style={styles.progressText}>This week&#39;s progress {completeCount}/{currentTarget} {weekComplete ? "(complete)" : ""}</Text>
      <ProgressChart data={{ data: [getChartProgress()] }}
                      width={width - 16}
                      height={160}
                      strokeWidth={16}
                      radius={48}
                      chartConfig={_config}
                      hideLegend={true} />

      <View style={styles.row}>
        <View style={styles.iconText}>
          <Icon name='fire' type='material-community' color={Colors.alpha.medium} />
          <Text style={styles.streakText}>Current streak: {currentCount}</Text>
        </View>

        {bestCount > 0 &&
        <View style={styles.iconText}>
          <Icon name='medal' type='material-community' color={Colors.alpha.medium} />
          <Text style={styles.streakText}>Best streak: {bestCount}</Text>
        </View>
        }

      </View>

    </View>
  )

  return (
    <Tooltip popover={streakMenu} height={321} width={width} containerStyle={styles.streakContainer} pointerColor={Colors.blue}>
      <View style={styles.streakButton}>
          <Icon name='fire' type='material-community' color={weekComplete ? Colors.blue : Colors.alpha.medium} />
          <Text style={styles.streakNumber}>{currentCount}</Text>
      </View>
    </Tooltip>
  )

  function getChartProgress () {
    if (!currentTarget) return 0
    return Math.min(completeCount, currentTarget) / currentTarget
  }

  function updateCompleteCount (weekStart, weekEnd) {
    Storage.history.getAll(keys => {
      const dates = {}
      keys?.forEach((key) => {
        const split = fastSplit(key)
        const date = split.date
        const workout = split.workout

        const d = new Date(date)
        if (d >= weekStart && d <= weekEnd) {
          if (!dates[date]) dates[date] = {}
          dates[date][workout] = true
        }
      })

      let count = 0
      for (const date in dates) {
        const workouts = dates[date]
        count += Object.keys(workouts)?.length ?? 0
      }

      setCompleteCount(count)
    })
  }

  function getWeekStartEnd (startDay) {
    if (!today) return
    if (typeof startDay === "undefined") return
    const weekday = today.getDay()
    let pre = weekday - startDay
    const post = (6 - pre) % 7
    if (pre < 0) pre = 6 - post

    return {
      start: getOffsetDate(pre * -1),
      end: getOffsetDate(post)
    }
  }

  function getOffsetDate (offset) {
    const date = new Date(today.getFullYear(), today.getMonth(), today.getDate() + offset)
    const text = getDateText(date)
    return new Date(text)
  }

  function processStreak (streak) {
    if (!streak) return

    const weeks = streak.weeks
    if (weeks) {
      let count = 0
      const keys = Object.keys(weeks)
      for (const key in weeks) {
        if (weeks[key].complete >= weeks[key].target) {
          count++
        } else if (key !== keys[keys.length - 1]) {
          if (typeof endStreak === "function") endStreak()
          return
        }
      }

      setCurrentCount(count)
    }

    const s = streak.settings
    if (!s) return

    setCurrentTarget(s.target)

    const week = getWeekStartEnd(s.startDay)
    if (!week) return

    setWeekStart(week.start)
    setWeekEnd(week.end)

    updateCompleteCount(week.start, week.end)
  }
}

export default function Main ({ navigation, route }) {
  const [expoPushToken, setExpoPushToken] = useState()
  const [routines, setRoutines] = useState([])
  const [currentStreak, setCurrentStreak] = useState()
  const [bestStreak, setBestStreak] = useState()

  useEffect(() => {
    if (route.params?.newRoutine) {
      addRoutine(route.params?.newRoutine)
    }
  }, [route.params?.newRoutine])

  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", () => {
      refreshStreak()
      refreshRoutines()
    })

    return unsubscribe
  }, [navigation])

  useEffect(() => {
    if (!expoPushToken) return

    Storage.settings.get((val) => {
      let enableNotifications = Default.streakEnable
      let notificationTime = Default.streakNotificationTime
      let startDay = Default.streakStartDay

      const json = parseSettings(val)
      if (json?.streak) {
        notificationTime = json.streak.notificationTime
        enableNotifications = json.streak.enabled
        startDay = json.streak.startDay
      }

      const body = createToken(expoPushToken,
        notificationTime,
        { startDay: startDay, enabled: enableNotifications })

      fetch(_endpoint + "/token", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      })
    })
  }, [expoPushToken])

  useEffect(() => {
    navigation.setOptions({
      headerRight: () => <StreakButton currentStreak={currentStreak} bestStreak={bestStreak} updateWeek={updateWeek.bind(this)} endStreak={endStreak.bind(this)} />
    })
  }, [currentStreak, bestStreak])

  useEffect(() => {
    refreshRoutines()
    setupNotifications()
  }, [])

  if (routines &&
      routines.length > 0) {
    return renderList(routines)
  }

  return renderEmpty()

  function renderEmpty () {
    return (
      <SafeAreaView style={styles.container}>

          {renderAddButton()}

          <View>
            <Text style={styles.explanationText}>You don&#39;t have any workouts yet</Text>
            <Text style={styles.explanationText}>Press &#39;+&#39; button to create a new one</Text>
          </View>

      </SafeAreaView>
    )
  }

  function renderList (list) {
    const bodyButton = (
      <TouchableHighlight onPress={gotoBodyStats.bind(this)} style={styles.menuButton} underlayColor={Colors.silver}>
        <View>
          <Icon name='human' type='material-community' />
          <Text style={styles.menuButtonText}>goals</Text>
        </View>
      </TouchableHighlight>
    )

    return (
      <SafeAreaView style={styles.container}>

        {renderAddButton()}

        <FlatList data={list}
                  renderItem={({ item, index }) => <RoutineCard routineKey={item} navigation={navigation} deleteClick={() => { deleteRoutineClick(index, item) }} />}
                  keyExtractor={(_, index) => `routine-${index}`} />

        <View style={styles.menuBack} />
        <View style={styles.menuBar}>
          <TouchableHighlight onPress={gotoHistory.bind(this)} style={styles.menuButton} underlayColor={Colors.silver}>
            <View>
              <Icon name='history' type='font-awesome' />
              <Text style={styles.menuButtonText}>history</Text>
            </View>
          </TouchableHighlight>

          {bodyButton}

          <TouchableHighlight onPress={gotoExercises.bind(this)} style={styles.menuButton} underlayColor={Colors.silver}>
            <View>
              <Icon name='run-fast' type='material-community' />
              <Text style={styles.menuButtonText}>exercises</Text>
            </View>
          </TouchableHighlight>

          <TouchableHighlight onPress={gotoSettings.bind(this)} style={styles.menuButton} underlayColor={Colors.silver}>
            <View>
              <Icon name='gears' type='font-awesome' />
              <Text style={styles.menuButtonText}>settings</Text>
            </View>
          </TouchableHighlight>

        </View>

      </SafeAreaView>
    )
  }

  function renderAddButton () {
    return (
      <View>
        <RoundButton content={<Text style={[styles.addButtonText]}>+</Text>}
                      style={[styles.addRoutineButton]}
                      onPress={gotoCreateRoutine.bind(this)} />
      </View>
    )
  }

  function setupNotifications () {
    registerForPushNotificationsAsync().then(token => setExpoPushToken(token))

    if (Platform.OS === "android") {
      Notifications.setNotificationChannelAsync("default", {
        name: "default",
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: "#FF231F7C"
      })
    }
  }

  async function registerForPushNotificationsAsync () {
    let token

    if (Constants.isDevice) {
      const { status: existingStatus } = await Permissions.getAsync(Permissions.NOTIFICATIONS)
      let finalStatus = existingStatus
      if (existingStatus !== "granted") {
        const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS)
        finalStatus = status
      }

      if (finalStatus !== "granted") {
        return
      }

      token = await Notifications.getExpoPushTokenAsync()
    }

    return token
  }

  function initializeStreak () {
    Storage.settings.get((val) => {
      let target = Default.streakTarget
      let startDay = Default.streakStartDay

      const json = parseSettings(val)
      if (json?.streak) {
        target = json.streak.target
        startDay = json.streak.startDay
      }

      const streak = createNewStreak(target, startDay)
      Storage.streak.current.set(streak)
      setCurrentStreak(streak)
    })
  }

  function updateWeek (name, complete, goal) {
    if (!currentStreak) return
    if (!currentStreak.weeks) currentStreak.weeks = {}

    const updatedStreak = JSON.parse(JSON.stringify(currentStreak))
    updatedStreak.weeks[name] = createWeekRecord(complete, goal)

    Storage.streak.current.set(updatedStreak)
    setCurrentStreak(updatedStreak)

    const streakToken = createStreakToken(expoPushToken, complete, goal)
    if (streakToken) {
      console.log("sending week token")
      fetch(_endpoint + "/streak", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify(streakToken)
      })
    }
  }

  function endStreak () {
    // save old streak with an end date
    const updatedStreak = JSON.parse(JSON.stringify(currentStreak))
    updatedStreak.endDate = +new Date()
    Storage.streak.set(updatedStreak.id, updatedStreak)

    // start new streak
    initializeStreak()
  }

  function refreshStreak () {
    setTimeout(() => {
      Storage.streak.current.get((val) => {
        const parsed = parseStreak(val)
        if (!parsed) {
          initializeStreak()
          return
        }

        setCurrentStreak(parsed)
      })

      Storage.streak.best.get((val) => {
        const parsed = parseStreak(val)
        if (!parsed) {
          return
        }

        setBestStreak(parsed)
      })
    }, 500)
  }

  function refreshRoutines () {
    setRoutines([])
    Storage.routine.getAll((keys) => {
      setRoutines(keys)
    })
  }

  function addRoutine (routine) {
    setRoutines([
      ...routines,
      routine
    ])
  }

  function gotoHistory () {
    navigation.navigate("History")
  }

  function gotoCreateRoutine () {
    navigation.navigate("CreateRoutine")
  }

  function gotoSettings () {
    navigation.navigate("Settings", { expoPushToken: expoPushToken })
  }

  function gotoExercises () {
    navigation.navigate("Exercises")
  }

  function gotoBodyStats () {
    navigation.navigate("BodyStats")
  }

  function deleteRoutineClick (key, val) {
    const name = val?.name ?? "this"
    Analytics.logEvent("DeleteRoutine", { stage: "click" })

    confirmationDialog("Delete workout?",
      "Do you want to delete '" + name + "' workout?",
      () => {
        Analytics.logEvent("DeleteRoutine", { stage: "confirm" })
        deleteRoutine(key, val)
      },
      () => {
        Analytics.logEvent("DeleteRoutine", { stage: "cancel" })
      })
  }

  function deleteRoutine (key, val) {
    routines.splice(key, 1)
    setRoutines([...routines])

    Storage.routine.delete(val.id)
  }

  function confirmationDialog (title, text, yesFunc, noFunc) {
    Alert.alert(
      title,
      text,
      [
        {
          text: "No",
          style: "cancel",
          onPress: noFunc
        },
        {
          text: "Yes",
          onPress: yesFunc
        }
      ]
    )
  }
}

const styles = StyleSheet.create({
  addButtonText: {
    fontSize: 24,
    marginTop: -2
  },
  addRoutineButton: {
    backgroundColor: "white",
    borderColor: Colors.blue + Alpha.light,
    borderWidth: 1,
    left: "50%",
    marginBottom: 7,
    marginLeft: -25,
    marginTop: 7
  },
  container: {
    flex: 1
  },
  explanationText: {
    color: Colors.alpha.heavy,
    marginTop: 8,
    textAlign: "center"
  },
  iconText: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row",
    justifyContent: "center"
  },
  menuBack: {
    backgroundColor: "white",
    bottom: 0,
    height: 60,
    position: "absolute",
    width: "100%"
  },
  menuBar: {
    backgroundColor: "white",
    borderColor: Colors.alpha.medium,
    borderTopWidth: 1,
    flexDirection: "row",
    height: 60,
    paddingHorizontal: 4
  },
  menuButton: {
    alignItems: "center",
    flex: 1,
    padding: 8
  },
  menuButtonText: {
    fontSize: 12
  },
  progressText: {
    fontSize: 20,
    textAlign: "center"
  },
  routineCard: {
    backgroundColor: _backColor,
    borderColor: Colors.blue + Alpha.light,
    borderWidth: 1,
    padding: 14
  },
  routineText: {
    color: _frontColor,
    fontSize: 18
  },
  row: {
    flexDirection: "row"
  },
  streakButton: {
    alignItems: "center",
    flexDirection: "row",
    padding: 12
  },
  streakContainer: {
    backgroundColor: "white",
    borderColor: Colors.blue,
    borderWidth: 1
  },
  streakMenu: {
    flex: 1,
    width: "100%"
  },
  streakNumber: {
    fontSize: 18
  },
  streakText: {
    fontSize: 15
  }
})
