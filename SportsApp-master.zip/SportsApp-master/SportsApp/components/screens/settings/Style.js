import { StyleSheet } from "react-native"

import Colors, { Theme, FontColor } from "../../styles/Colors"

export const IconColor = FontColor.onBackground
export const ActiveColor = Theme.primary
export const DisabledColor = Theme.background

export default StyleSheet.create({
  activeButton: {
    backgroundColor: Theme.primary,
    borderRadius: 16,
    margin: 4
  },
  activeButtonText: {
    color: FontColor.onPrimary,
    fontSize: 16,
    fontWeight: "400"
  },
  block: {
    alignSelf: "center",
    backgroundColor: Theme.surface,
    borderRadius: 8,
    marginVertical: 4,
    padding: 8,
    paddingHorizontal: 12,
    width: "90%"
  },
  container: {
    flex: 1
  },
  disabledButtonText: {
    color: FontColor.onBackground,
    fontSize: 16,
    fontWeight: "400"
  },
  flex: {
    flex: 1
  },
  flexEnd: {
    width: 64
  },
  helpButton: {
    alignItems: "flex-end"
  },
  helpOverlay: {
    height: "auto",
    width: "85%"
  },
  helpText: {
    fontSize: 18
  },
  helpView: {
    paddingHorizontal: 4,
    paddingVertical: 8
  },
  questionText: {
    color: Colors.alpha.medium,
    flex: 1,
    fontSize: 14
  },
  row: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 4
  },
  rowText: {
    color: FontColor.onSurface,
    fontSize: 16,
    fontWeight: "500",
    marginRight: 6
  },
  slider: {
    flex: 1,
    paddingLeft: 16,
    paddingRight: 8
  },
  sliderRow: {
    marginTop: 8
  },
  sliderThumb: {
    height: 20,
    width: 20
  },
  streakValue: {
    backgroundColor: Colors.lightSilver,
    borderRadius: 10,
    height: 42,
    justifyContent: "center",
    padding: 4,
    width: 42
  },
  streakValueText: {
    fontSize: 24,
    textAlign: "center"
  },
  switchBlockContainer: {
    backgroundColor: Theme.background,
    borderRadius: 16,
    borderWidth: 0,
    flex: 1,
    height: 36,
    marginRight: 0
  },
  techData: {
    flex: 1,
    justifyContent: "flex-end",
    marginBottom: 16,
    opacity: 0.5,
    padding: 2,
    paddingHorizontal: 16
  },
  textCenter: {
    color: Colors.alpha.medium,
    textAlign: "center"
  },
  textWithHelp: {
    alignItems: "center",
    flexDirection: "row"
  },
  timeButton: {
    backgroundColor: Colors.alpha.extraLight,
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 2
  },
  timeText: {
    color: Colors.deepBlue,
    fontSize: 16
  },
  weightButton: {
    alignItems: "center",
    backgroundColor: Colors.silver,
    borderRadius: 4,
    height: 32,
    justifyContent: "center",
    marginLeft: 4,
    width: 32
  }
})
