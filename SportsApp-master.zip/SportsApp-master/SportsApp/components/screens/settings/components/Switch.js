import React, { useState, useEffect } from "react"
import { ButtonGroup } from "react-native-elements"

import Style from "../Style"

export default function Switch ({ selected, options, onChange }) {
  const [index, setIndex] = useState(selected)

  useEffect(() => {
    setIndex(selected)
  }, [selected])

  useEffect(() => {
    if (typeof index === "undefined") return
    onChange(index)
  }, [index])

  return (
      <ButtonGroup onPress={(index) => { setIndex(index) }}
                    selectedIndex={index}
                    buttons={options}
                    innerBorderStyle={{ width: 0 }}
                    containerStyle={Style.switchBlockContainer}
                    selectedButtonStyle={Style.activeButton}
                    selectedTextStyle={Style.activeButtonText}
                    textStyle={Style.disabledButtonText} />
  )
}
