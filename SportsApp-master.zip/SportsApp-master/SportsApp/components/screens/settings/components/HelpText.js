import React from "react"
import { View, Text } from "react-native"

import Style from "../Style"

export function MillisecondsHelp () {
  return (
        <View style={Style.helpView}>
            <Text style={Style.helpText}>
            Show milliseconds while using stopwatch for time-based exercises
            </Text>
        </View>
  )
}

export function WorkoutsPerWeekHelp () {
  return (
        <View style={Style.helpView}>
            <Text style={Style.helpText}>
            Set the consistency of how many workouts you would like to have per week
            </Text>
        </View>
  )
}

export function StartDayHelp () {
  return (
        <View style={Style.helpView}>
            <Text style={Style.helpText}>
            Choose your first day of the week for your weekly streaks
            </Text>
        </View>
  )
}

export function StreakNotificationsHelp () {
  return (
        <View style={Style.helpView}>
            <Text style={Style.helpText}>
            Choose the time you would like to receive your update on your streaks. You receive it only twice a week
            </Text>
        </View>
  )
}

export function AutoCollapseHelp () {
  return (
        <View style={Style.helpView}>
            <Text style={Style.helpText}>
            Automatically close the exercise view on the workout page upon completion
            </Text>
        </View>
  )
}
