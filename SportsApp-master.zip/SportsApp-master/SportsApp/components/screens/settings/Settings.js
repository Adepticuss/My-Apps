import React, { useState, useEffect } from "react"
import { Text, View, SafeAreaView, Switch, TouchableOpacity, Platform } from "react-native"
import PropTypes from "prop-types"
import Constants from "expo-constants"
import { Icon, Slider, ButtonGroup, Overlay, Button } from "react-native-elements"
import DateTimePicker from "@react-native-community/datetimepicker"

import Colors from "../../styles/Colors"
import Storage from "../../controllers/Storage"
import { pad } from "../../controllers/History"
import { createSettingsDefault, createSettings, parseSettings } from "../../models/Settings"
import { parseStreak } from "../../models/Streak"
import { createToken } from "../../models/Token"
import { Default, WeightType, WeekDay } from "../../constants/Settings"
import SwitchBlock from "./components/Switch"
import { MillisecondsHelp, AutoCollapseHelp, WorkoutsPerWeekHelp, StartDayHelp, StreakNotificationsHelp } from "./components/HelpText"

import Style, { IconColor, ActiveColor, DisabledColor } from "./Style"

const _endpoint = "https://oko-simple-workout.herokuapp.com/token"

function SettingsScreen ({ pushToken }) {
  const [expoPushToken, setExpoPushToken] = useState()
  const [settings, setSettings] = useState()
  const [weightUnit, setWeightUnit] = useState()
  const [showMillisec, setShowMillisec] = useState()
  const [autoCollapse, setAutoCollapse] = useState()
  const [streakEnable, setStreakEnable] = useState()
  const [streakValue, setStreakValue] = useState()
  const [streakStartDay, setStreakStartDay] = useState()
  const [notificationTime, setNotificationTime] = useState()

  const [showTimePicker, setShowTimePicker] = useState(Platform.OS === "ios")
  const [dayIndex, setDayIndex] = useState(0)
  const [showOverlay, setShowOverlay] = useState(false)
  const [overlayText, setOverlayText] = useState()

  useEffect(() => {
    Storage.settings.get(x => {
      let settings = parseSettings(x)
      if (!settings) {
        settings = createSettingsDefault()
      }

      setWeightUnit(settings.weightUnit)
      setShowMillisec(settings.showMillisec)
      setAutoCollapse(settings.autoCollapse)
      setStreakEnable(settings.streak?.enabled)
      setStreakValue(settings.streak?.target)
      setStreakStartDay(settings.streak?.startDay)
      setNotificationTime(new Date(settings.streak?.notificationTime))
      setSettings(settings)
    })
  }, [])

  // Effect (Route)
  useEffect(() => {
    if (pushToken) {
      setExpoPushToken(pushToken)
    }
  }, [pushToken])

  useEffect(() => {
    let index = Default.streakStartDay
    if (streakStartDay === WeekDay.sunday ||
            streakStartDay === WeekDay.monday) {
      index = streakStartDay
    }

    setDayIndex(index)
  }, [streakStartDay])

  useEffect(() => {
    if (!settings) return
    Storage.settings.set(settings)
  }, [settings])

  useEffect(() => {
    if (!settings) return
    Storage.streak.current.get(x => {
      const streak = parseStreak(x)
      if (!streak?.settings ||
                !streak?.weeks) return
      /*
            ! DON't update, ask first
            json.settings.count = streakValue

            if     json.weeks has only 1 key -> delete and update settings.startDay
            else   don't update settings.startDay. Maybe prompt
            json.settings.startDay = streakStartDay
            Storage.streak.current.set(json)
            */

      streak.settings.target = streakValue
      const weeks = Object.keys(streak.weeks)?.length
      if (weeks <= 1) {
        streak.weeks = {}
        streak.settings.startDay = streakStartDay
      }

      Storage.streak.current.set(streak)
    })
  }, [streakStartDay, streakValue])

  useEffect(() => {
    if (!expoPushToken) return
    if (typeof streakStartDay === "undefined" ||
            typeof notificationTime === "undefined") return

    const body = createToken(expoPushToken,
      notificationTime,
      { startDay: streakStartDay, enabled: streakEnable })

    fetch(_endpoint, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    })
  }, [streakStartDay, notificationTime, streakEnable])

  useEffect(() => {
    if (!settings) return
    const newSettings = createSettings(weightUnit, showMillisec, autoCollapse, streakEnable, streakValue, streakStartDay, notificationTime)
    setSettings(newSettings)
  }, [weightUnit, showMillisec, autoCollapse, streakEnable, streakValue, streakStartDay, notificationTime])

  const oldGroup = (
    <View style={Style.flex}>
        <ButtonGroup onPress={(index) => { setDayIndex(index); setStreakStartDay(index) }}
                        selectedIndex={dayIndex}
                        buttons={["Sunday", "Monday"]}
                        selectedButtonStyle={Style.activeButton}
                        selectedTextStyle={Style.activeButtonText} />
    </View>
  )

  const oldWeight = (
    <View>
      <TouchableOpacity onPress={() => { setWeightUnit(WeightType.kg) }} style={getWeightButtonStyle(WeightType.kg)}>
          <Icon name='weight-kilogram' type='material-community' color={Colors.alpha.medium} />
      </TouchableOpacity>
      <TouchableOpacity onPress={() => { setWeightUnit(WeightType.lb) }} style={getWeightButtonStyle(WeightType.lb)}>
          <Icon name='weight-pound' type='material-community' color={Colors.alpha.medium} />
      </TouchableOpacity>
    </View>
  )

  return (
        <View style={Style.container}>

            <Overlay isVisible={showOverlay}
                      onBackdropPress={() => { setShowOverlay(false) }}
                      overlayStyle={Style.helpOverlay} >
                {overlayText}
            </Overlay>

            <View style={[Style.block, Style.row]}>
                <Text style={Style.rowText}>Weight units</Text>
                <View style={Style.flex} />
                <SwitchBlock options={["Kg", "Lb"]}
                              selected={weightTypeToIndex(weightUnit)}
                              onChange={x => setWeightUnit(indexToWeightType(x))} />
            </View>

            <View style={[Style.block, Style.row]}>
                <View style={Style.textWithHelp}>
                  <Text style={Style.rowText}>Show milliseconds</Text>
                  <Button icon={<Icon name='info-outline' type='material' color={IconColor} />}
                              type='clear' onPress={showStopwatchHelp.bind(this)}/>
                </View>

                <Switch onValueChange={() => { setShowMillisec(!showMillisec) }}
                        value={showMillisec}
                        trackColor={{ true: ActiveColor, false: DisabledColor } }
                        thumbColor={Platform.OS === "android" ? "white" : null} />

            </View>

            <View style={[Style.block, Style.row]}>
                <View style={Style.textWithHelp}>
                  <Text style={Style.rowText}>Auto-collapse</Text>
                  <View style={Style.helpButton}>
                    <Button icon={<Icon name='info-outline' type='material' color={IconColor} />}
                            type='clear' onPress={showAutoCollapseHelp.bind(this)}/>
                  </View>
                </View>

                <Switch onValueChange={() => { setAutoCollapse(!autoCollapse) }}
                        value={autoCollapse}
                        trackColor={{ true: ActiveColor, false: Colors.alpha.light } }
                        thumbColor={Platform.OS === "android" ? "white" : null} />
            </View>

            <View style={[Style.block]}>
                <View style={Style.textWithHelp}>
                    <Text style={Style.rowText}>Weekly streaks</Text>
                    <Text style={Style.questionText}>(Workouts per week)</Text>
                    <View style={Style.helpButton}>
                        <Button icon={<Icon name='info-outline' type='material' color={IconColor} />}
                                type='clear' onPress={showWorkoutsPerWeekHelp.bind(this)}/>
                    </View>
                </View>

                <View style={Style.row}>
                    <View style={Style.streakValue}>
                      <Text style={Style.streakValueText}>{streakValue}</Text>
                    </View>

                    {streakValue &&
                    <View style={Style.slider}>
                      <Slider value={streakValue}
                              onValueChange={setStreakValue}
                              maximumValue={20} minimumValue={1} step={1}
                              thumbStyle={Style.sliderThumb}
                              thumbTintColor={ActiveColor}
                              minimumTrackTintColor={Colors.alpha.medium} />
                    </View>
                    }

                </View>

                <View style={Style.row}>
                  <View style={Style.textWithHelp}>
                    <Text style={Style.rowText}>Start day</Text>
                    <Button icon={<Icon name='info-outline' type='material' color={IconColor} />}
                                type='clear' onPress={showStartDayHelp.bind(this)}/>
                  </View>

                  <SwitchBlock options={["Sunday", "Monday"]}
                                selected={weekDayToIndex(streakStartDay)}
                                onChange={x => setStreakStartDay(indexToWeekDay(x))} />
                </View>

                <View style={Style.row}>
                  <View style={Style.textWithHelp}>
                    <Text style={Style.rowText}>Notifications</Text>
                    <Button icon={<Icon name='info-outline' type='material' color={IconColor} />}
                                type='clear' onPress={showStreakNotificationsHelp.bind(this)}/>
                  </View>

                  <Switch onValueChange={() => { setStreakEnable(!streakEnable) }}
                      value={streakEnable}
                      trackColor={{ true: ActiveColor, false: Colors.alpha.light } }
                      thumbColor={Platform.OS === "android" ? "white" : null} />
                </View>

                {streakEnable &&
                <View style={Style.row}>
                    <Text style={Style.rowText}>Notification time</Text>
                    {Platform.OS === "android" &&
                    <TouchableOpacity style={Style.timeButton} onPress={() => { setShowTimePicker(true) }}>
                        <Text style={Style.timeText}>{notificationTime?.getHours()}:{pad(notificationTime?.getMinutes(), 2)}</Text>
                    </TouchableOpacity>
                    }

                    {showTimePicker &&
                    <DateTimePicker value={notificationTime ?? new Date()}
                                    testID="dateTimePicker"
                                    mode='time'
                                    is24Hour={true}
                                    display="default"
                                    minuteInterval={30}
                                    style={[Style.flexEnd]}
                                    onChange={(_, time) => { setShowTimePicker(Platform.OS === "ios"); setNotificationTime(time || notificationTime) }} />
                    }
                </View>
                }

            </View>

            <View style={[Style.techData]}>
                <Text style={Style.textCenter}>app version: {Constants.nativeAppVersion}</Text>
            </View>

        </View>
  )

  function weightTypeToIndex (selected) {
    if (selected === WeightType.kg) {
      return 0
    } else if (selected === WeightType.lb) {
      return 1
    }
  }

  function indexToWeightType (index) {
    if (index === 0) {
      return WeightType.kg
    } else if (index === 1) {
      return WeightType.lb
    }
  }

  function weekDayToIndex (selected) {
    if (selected === WeekDay.sunday) {
      return 0
    } else if (selected === WeekDay.monday) {
      return 1
    }
  }

  function indexToWeekDay (index) {
    if (index === 0) {
      return WeekDay.sunday
    } else if (index === 1) {
      return WeekDay.monday
    }
  }

  function getWeightButtonStyle (type) {
    const style = [Style.weightButton]
    if (type === weightUnit) style.push(Style.activeButton)
    return style
  }

  function showStopwatchHelp () {
    showHelpText(<MillisecondsHelp />)
  }

  function showAutoCollapseHelp () {
    showHelpText(<AutoCollapseHelp />)
  }

  function showWorkoutsPerWeekHelp () {
    showHelpText(<WorkoutsPerWeekHelp />)
  }

  function showStartDayHelp () {
    showHelpText(<StartDayHelp />)
  }

  function showStreakNotificationsHelp () {
    showHelpText(<StreakNotificationsHelp />)
  }

  function showHelpText (text) {
    if (!text) return
    setOverlayText(text)
    setShowOverlay(true)
  }
}

SettingsScreen.propTypes = {
  pushToken: PropTypes.object
}

function Settings ({ route }) {
  return (
    <SafeAreaView style={Style.container}>
      <SettingsScreen pushToken={route.params?.expoPushToken} />
    </SafeAreaView>
  )
}

Settings.propTypes = {
  route: PropTypes.element
}

export { SettingsScreen }
export default Settings
