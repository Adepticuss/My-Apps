import React, { useEffect, useState } from "react"
import { SafeAreaView, FlatList, Platform } from "react-native"
import KeyboardSpacer from "react-native-keyboard-spacer"

import { createWeightGoal, parseGoal, getGoalIcon, GoalId } from "../../models/Goal"
import { parseSettings } from "../../models/Settings"
import Storage from "../../controllers/Storage"
import { Default } from "../../constants/Settings"

import StatsCard from "./components/StatsCard"

import Style from "./Style"

const StatsCardUnparsed = ({ goal, weightUnit }) => {
  const [icon, setIcon] = useState()

  useEffect(() => {
    if (!goal) return
    if (!goal.icon) {
      setIcon(getGoalIcon(goal.id, weightUnit, Style.goalTypeIcon))
    }
  }, [goal, weightUnit])

  return (
        <StatsCard name={goal?.name}
                    icon={icon}
                    pastData={goal?.data?.pastData}
                    goal={goal?.data?.goal}
                    units={weightUnit}
                    onChange={update.bind(this)} />
  )

  function update (data) {
    console.log("onChange:" + JSON.stringify(data))
    if (!data) return
    goal.data = data
    Storage.goal.set(goal?.id, goal)
  }
}

function BodyStatsScreen ({ navigation }) {
  const [stats, setStats] = useState([])
  const [weightUnit, setWeightUnit] = useState()

  useEffect(() => {
    Storage.goal.get(GoalId.weight, x => {
      let goal = parseGoal(x)
      if (!goal) {
        goal = createWeightGoal()
        Storage.goal.set(GoalId.weight, goal)
      }

      setStats([goal])
    })

    Storage.settings.get(x => {
      let weightUnit = Default.weightUnit

      const parsed = parseSettings(x)
      if (parsed) {
        weightUnit = parsed.weightUnit
      }

      setWeightUnit(weightUnit)
    })
  }, [])

  let spacer
  if (Platform.OS === "ios") {
    spacer = (<KeyboardSpacer />)
  }

  return (
        <SafeAreaView style={Style.flex}>

            <FlatList data={stats}
                      renderItem={({ item }) => (
                          <StatsCardUnparsed goal={item} weightUnit={weightUnit} />
                      )}
                      keyExtractor={({ _, i }) => `goal-${i}`}
                      keyboardShouldPersistTaps={"handled"}
                      style={Style.flex} />

            {spacer}

        </SafeAreaView>
  )
}

export { BodyStatsScreen }

export default function BodyStats ({ navigation, route }) {
  return (
        <SafeAreaView style={Style.flex}>

            <BodyStatsScreen navigation={navigation} />

        </SafeAreaView>
  )
}
