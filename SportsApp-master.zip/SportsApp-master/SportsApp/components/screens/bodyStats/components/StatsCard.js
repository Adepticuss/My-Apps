import React, { useEffect, useState } from "react"
import { View, Text, Alert, Image } from "react-native"
import { Button } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"

import ButtonGroup from "../../../modules/ButtonGroup"
import { createGoalData } from "../../../models/Goal"

import StatsGraph from "./StatsGraph"
import StatsList from "./StatsList"
import StatsInput from "./StatsInput"

import Style, { InputColorGoal, InputColorValue } from "../Style"

const _buttons = ["Graph", "List"]
const _modes = {
  graph: 1,
  list: 2
}

export default function StatsCard ({ name, icon, pastData, goal, units, onChange }) {
  const [rawData, setRawData] = useState(pastData ?? [])
  const [lastValue, setLastValue] = useState()
  const [mode, setMode] = useState(_modes.graph)
  const [input, setInput] = useState()
  const [goalValue, setGoalValue] = useState(goal)

  useEffect(() => {
    update(goalValue, rawData)
    const values = rawData?.map(x => x.value)

    if (!(values?.length > 0)) {
      return
    }

    const lastValue = values[values.length - 1]
    setLastValue(lastValue + "")
  }, [rawData, goalValue])

  return (
    <View>
      <ButtonGroup options={_buttons}
                    selected={cardModeToIndex(mode)}
                    onChange={x => setMode(indexToCardMode(x))}
      />

      <View style={Style.cardBlock}>
        <View style={Style.row}>
          <Text style={Style.cardInputLabel}>Your weight</Text>
          <Text style={Style.cardInputLabel}>Goal</Text>
        </View>

        <View style={Style.row}>
          <View style={Style.flex}>
            <StatsInput
              value={input}
              placeholder={lastValue ?? ""}
              onUpdate={x => addNewRecord(x)}
              icon={icon}
              activeColor={InputColorValue}
            />
          </View>

          <View style={Style.inputSeparator} />

          <View style={Style.flex}>
            <StatsInput
              value={goalValue}
              placeholder={goalValue ?? ""}
              onUpdate={goalUpdate.bind(this)}
              icon={<Image resizeMode='contain' style={Style.goalIcon} source={require("../../../../assets/icons/menu_bar/target.png")} />}
              activeColor={InputColorGoal}
            />
          </View>

        </View>
      </View>

      {mode === _modes.graph
        ? (
          <View style={Style.cardBlock}>
              <StatsGraph rawData={rawData} goalValue={goalValue} />
          </View>
          )
        : (
          <View>
              <StatsList rawData={rawData} updateValue={updateValue.bind(this)} icon={icon} />
              <Button title="Delete all"
                      type='clear'
                      style={Style.deleteAllButton}
                      titleStyle={Style.deleteButtonText}
                      onPress={deleteClick.bind(this)} />
          </View>
          )
      }
  </View>
  )

  function goalUpdate (v) {
    Analytics.logEvent("GoalUpdate")
    setGoalValue(v)
  }

  function cardModeToIndex (mode) {
    Analytics.logEvent("Graph_List", { mode: mode })

    if (mode === _modes.graph) {
      return 0
    } else if (mode === _modes.list) {
      return 1
    }
  }

  function indexToCardMode (index) {
    if (index === 0) {
      return _modes.graph
    } else if (index === 1) {
      return _modes.list
    }
  }

  function update (newGoal, newPastData) {
    if (typeof onChange !== "function") return
    onChange({
      goal: newGoal,
      pastData: newPastData
    })
  }

  function updateValue (newVal, index) {
    const forDelete = newVal == null
    const sameValue = newVal === rawData[index].value
    const newNumber = parseFloat(newVal?.replace(",", "."))
    console.log(`${newVal}{${newNumber}} [${index}] (delete: ${forDelete}; same: ${sameValue})`)

    if (sameValue) return

    const item = rawData[index]
    if (forDelete) {
      confirmationDialog("Delete record",
                                `Do you want to delete record for ${new Date(item.timestamp).toLocaleDateString()}?`,
                                () => {
                                  rawData.splice(index, 1)
                                  setRawData([...rawData])
                                },
                                () => { })
    } else {
      if (!newNumber) return
      item.value = newNumber
      rawData[index] = item
      setRawData([...rawData])
    }
  }

  function addNewRecord (value) {
    if (!value) return

    Analytics.logEvent("GoalNewRecord")
    const newItem = createGoalData(parseFloat(value.replace(",", ".")), +new Date(), units)

    if (!(rawData?.length > 0)) {
      setRawData(new Array(newItem))
    } else {
      setRawData([...rawData, newItem])
    }

    setInput(value)
  }

  function deleteClick () {
    confirmationDialog("Delete data",
      "Do you want to delete " + name?.toLowerCase() + " data?",
      () => {
        setRawData([])
        setGoalValue(null)
        setLastValue(null)
        update()
      },
      () => {
      })
  }

  function confirmationDialog (title, text, yesFunc, noFunc) {
    Alert.alert(
      title,
      text,
      [
        {
          text: "No",
          style: "cancel",
          onPress: noFunc
        },
        {
          text: "Yes",
          onPress: yesFunc
        }
      ]
    )
  }
}
