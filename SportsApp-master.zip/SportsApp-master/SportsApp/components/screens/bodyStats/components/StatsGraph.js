import React, { useEffect, useState } from "react"
import { View, ScrollView, ActivityIndicator } from "react-native"
import { LineChart } from "react-native-chart-kit"
import { Text as TextSVG, Svg, Circle } from "react-native-svg"

import { Margin, BackColor, FrontColor, DotColor, DotColorAlt, DotColorBlank, GraphBackColor, GraphColor, GraphColorGoal } from "../Style"

const _goalText = "Goal"
const _config = {
  backgroundColor: GraphBackColor,
  backgroundGradientFrom: GraphBackColor,
  backgroundGradientTo: GraphBackColor,
  color: GraphColor,
  labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
  useShadowColorFromDataset: true
}

export default function StatsGraph ({ rawData, goalValue }) {
  const [data, setData] = useState()
  const [showGraph, setShowGraph] = useState()
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0, visible: false, value: 0 })

  useEffect(() => {
    const labels = rawData?.map(x => x.timestamp ?? x.time)
    const values = rawData?.map(x => x.value)

    if (!(values?.length > 0)) {
      setData(null)
      return
    }

    setShowGraph(false)
    setTimeout(() => { loadData(values, labels) }, 100)
  }, [rawData, goalValue])

  if (typeof data === "undefined" || data === null) {
    return <View />
  }

  if (!showGraph) {
    return <ActivityIndicator />
  }

  const delta = 64
  const width = data.labels.length * delta
  console.log(width)

  return (
    <ScrollView horizontal={true}>
      <LineChart
          data={data}
          width={width - Margin * 4}
          height={256}
          verticalLabelRotation={0}
          chartConfig={_config}
          withVerticalLines={false}
          withOuterLines={false}
          segments={3}
          formatXLabel={x => getFormattedDate(x)}
          getDotColor={(point, index) => getDotColor(point, index)}
          onDataPointClick={dataPointClick.bind(this)}
          decorator={getPointDecorator.bind(this)}
          bezier
      />
    </ScrollView>
  )

  function loadData (values, labels) {
    const lastValue = values[values.length - 1]
    const datasets = []

    const goalValues = [...values]
    if (goalValue) {
      goalValues.push(goalValue)
      values.push(lastValue)
      labels.push(_goalText)

      // Goal graph
      datasets.push({
        data: goalValues,
        color: (opacity = 1) => GraphColorGoal(opacity)
      })
    }

    // Values graph
    datasets.push({
      data: values,
      color: (opacity = 1) => GraphColor(opacity * 3)
    })

    const ld = {
      labels: labels,
      datasets: datasets
    }

    console.log("rawParse:" + JSON.stringify(ld))
    setData(ld)
    setShowGraph(true)
  }

  function getFormattedDate (time) {
    if (time === _goalText) return time
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const date = new Date(time)
    return monthNames[date.getMonth()] + " " + date.getDate()
  }

  function getDotColor (point, index) {
    if (!goalValue) return DotColor
    if (index >= rawData?.length) {
      if (point === goalValue) return DotColorAlt

      return DotColorBlank
    }
    return DotColor
  }

  function dataPointClick (data) {
    if (data.index >= rawData?.length &&
                data.value !== goalValue) return

    const isSamePoint = (tooltipPos.x === data.x &&
                               tooltipPos.y === data.y)

    if (isSamePoint) {
      setTooltipPos((previousState) => {
        return {
          ...previousState,
          value: data.value,
          visible: !previousState.visible
        }
      })
    } else {
      setTooltipPos({ x: data.x, value: data.value, y: data.y, visible: true })
    }
  }

  function getPointDecorator () {
    if (!tooltipPos.visible) return
    const isGoal = tooltipPos.value === goalValue

    return (
                <View>
                    <Svg>
                        <Circle cx={tooltipPos.x}
                            cy={tooltipPos.y + 22}
                            r={20}
                            fill={BackColor}
                            strokeWidth={1}
                            stroke={isGoal ? DotColorAlt : DotColor} />
                            <TextSVG
                                x={tooltipPos.x}
                                y={tooltipPos.y + 25}
                                fill={FrontColor}
                                fontSize={11}
                                textAnchor="middle">
                                {tooltipPos.value}
                            </TextSVG>
                    </Svg>
                </View>
    )
  }
}
