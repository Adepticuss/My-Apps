import React, { useEffect, useState } from "react"
import { View, Text, TouchableOpacity, Image } from "react-native"
import { Button, Icon, Divider } from "react-native-elements"

import NumberInput from "../../routine/components/NumberInput"
import StatsInput from "./StatsInput"

import Style, { ButtonAlpha, InputColorValue } from "../Style"

export default function StatsListItem ({ value, timestamp, icon, onUpdate }) {
  const [editMode, setEditMode] = useState(false)
  const [localValue, setLocalValue] = useState()

  useEffect(() => {
    setLocalValue(value + "")
  }, [value])

  const editBlock = (
        <View style={Style.listItemValue}>
            <NumberInput value={localValue} onUpdate={x => setLocalValue(x)} style={[Style.flex]} />
            <Button icon={<Icon name='checkmark-circle-outline' type='ionicon' color={ButtonAlpha} />}
                    type='clear'
                    onPress={saveValue.bind(this)} />
            <Button icon={<Icon name='close-circle-outline' type='ionicon' color={ButtonAlpha} />}
                    type='clear'
                    onPress={discardValue.bind(this)} />
        </View>
  )

  const valueBlock = (
        <View style={Style.listItemValue}>
            <Text style={Style.listItemText}>{value}</Text>
            <Button icon={<Icon name='playlist-edit' type='material-community' color={ButtonAlpha} />}
                    type='clear'
                    onPress={() => { setEditMode(true) }} />
        </View>
  )

  const input = (
    <StatsInput
      value={localValue}
      placeholder={localValue}
      onUpdate={saveValue}
      icon={icon}
      activeColor={InputColorValue}
    />
  )

  return (
        <View style={[Style.statsListItem, Style.cardBlock]}>

            { input }

            <View style={Style.listItemPadding}/>

            <View style={Style.listItemDate}>
                <Text style={Style.listItemText}>{getFormattedDate(timestamp)}</Text>
            </View>

            <TouchableOpacity onPress={deleteValue.bind(this)} >
                <Image resizeMode='contain' style={Style.deleteIcon} source={require("../../../../assets/icons/action/delete.png")} />
            </TouchableOpacity>

        </View>
  )

  function getFormattedDate (time) {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    const date = new Date(time)
    return monthNames[date.getMonth()] + " " + date.getDate()
  }

  function saveValue (value) {
    setLocalValue(value)
    onUpdate(value)
  }

  function discardValue () {
    setLocalValue(value + "")
    setEditMode(false)
  }

  function deleteValue () {
    onUpdate(null)
  }
}
