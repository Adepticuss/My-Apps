import React, { useEffect, useState } from "react"
import { View, Text, TouchableOpacity, TouchableWithoutFeedback, TouchableHighlight, Image } from "react-native"

import NumberInput from "../../routine/components/NumberInput"
import Style from "../Style"

export default function StatsInput ({ value, placeholder, icon, activeColor, onUpdate }) {
  const [input, setInput] = useState()
  const [editMode, setEditMode] = useState(false)

  useEffect(() => {
    if (typeof value === "undefined") return
    setInput(value)
  }, [value])

  if (editMode === true) {
    return (
            <View style={Style.inputBlock}>
                <NumberInput
                    value={input}
                    placeholder={placeholder}
                    onUpdate={setInput.bind(this)}
                    style={[Style.flex, Style.input, { borderColor: activeColor }]}
                />
                <TouchableHighlight style={[Style.inputEditSave, { backgroundColor: activeColor }]} onPress={onEditSave.bind(this)}>
                    <Image resizeMode='contain' style={Style.inputEditIcon} source={require("../../../../assets/icons/action/check.png")} />
                </TouchableHighlight>
            </View>

    )
  }

  return (
        <TouchableWithoutFeedback onPress={() => { setEditMode(true) }}>
            <View style={[Style.inputBlock, Style.inputDisabled]}>
                {icon}
                <Text style={Style.inputText}>{placeholder}</Text>
                <TouchableOpacity style={Style.inputEditButton} onPress={() => { setEditMode(true) }}>
                    <Image resizeMode='contain' style={Style.inputEditIcon} source={require("../../../../assets/icons/header/edit.png")} />
                </TouchableOpacity>
            </View>
        </TouchableWithoutFeedback>
  )

  function onEditSave () {
    setEditMode(false)
    if (typeof onUpdate !== "function") return
    onUpdate(input)
  }
}
