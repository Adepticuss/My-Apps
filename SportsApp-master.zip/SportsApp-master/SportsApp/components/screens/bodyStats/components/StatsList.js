import React from "react"
import { FlatList } from "react-native"

import StatsListItem from "./StatsListItem"

export default function StatsList ({ rawData, updateValue, icon }) {
  return (
        <FlatList
            data={rawData}
            renderItem={({ item, index }) => {
              return (
                    <StatsListItem value={item.value}
                                    timestamp={item.timestamp}
                                    icon={icon}
                                    onUpdate={(val) => { updateValue(val, index) }} />
              )
            }
            }
            keyboardShouldPersistTaps={"handled"}
            keyExtractor={(_, i) => `listItem-${i}`}
        />
  )
}
