import { StyleSheet } from "react-native"
import Colors, { FontColor, Theme } from "../../styles/Colors"

export const Margin = 12
export const BackColor = "#ffffffcc"
export const FrontColor = "#000000cc"
export const ButtonAlpha = Colors.alpha.medium
export const DotColor = `${Theme.primary}`
export const DotColorAlt = `${Theme.secondary}`
export const DotColorBlank = `${Colors.alpha.transparent}`
export const GraphBackColor = "#ffffff"
export const GraphColor = (opacity = 1) => `rgba(84, 221, 255, ${opacity})`
export const GraphColorGoal = (opacity = 1) => `rgba(255, 166, 84, ${opacity})`
export const InputColorValue = Theme.primary
export const InputColorGoal = Theme.secondary

export default StyleSheet.create({
  block: {
    margin: Margin / 2
  },
  cardBlock: {
    backgroundColor: Theme.surface,
    borderRadius: 16,
    marginHorizontal: Margin,
    marginVertical: 8,
    padding: 12,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  cardInputLabel: {
    color: FontColor.onSurface,
    flex: 1,
    fontSize: 20,
    textAlign: "center"
  },
  center: {
    alignSelf: "center"
  },
  collapseButton: {
    flex: 1
  },
  deleteAllButton: {
    marginBottom: 16
  },
  deleteButton: {
    alignItems: "flex-start",
    flex: 1
  },
  deleteButtonText: {
    color: Colors.alpha.medium,
    fontSize: 14
  },
  deleteIcon: {
    height: 18,
    width: 18
  },
  divider: {
    backgroundColor: Colors.alpha.light,
    height: "50%",
    width: 1
  },
  flex: {
    flex: 1
  },
  goalButton: {
    backgroundColor: Colors.orange,
    marginLeft: 8
  },
  goalIcon: {
    height: 24,
    tintColor: Theme.secondary,
    width: 24
  },
  goalRow: {
    marginBottom: 8,
    marginHorizontal: 8
  },
  goalText: {
    alignSelf: "center",
    fontSize: 18,
    margin: 8,
    textAlign: "right"
  },
  goalTypeIcon: {
    height: 24,
    tintColor: Theme.primary,
    width: 24
  },
  graphBlock: {
    backgroundColor: GraphBackColor,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
    borderRadius: 8
  },
  helpText: {
    flex: 1,
    fontSize: 18,
    paddingTop: 8,
    textAlign: "center"
  },
  input: {
    backgroundColor: Theme.surface,
    borderRadius: 16,
    borderWidth: 1,
    height: 48,
    marginVertical: 8,
    paddingRight: 20
  },
  inputBlock: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row",
    height: 48,
    marginVertical: 8
  },
  inputDisabled: {
    backgroundColor: Theme.surface,
    borderColor: Colors.lightGrey,
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 4,
    paddingLeft: 8
  },
  inputEditButton: {
    alignItems: "center",
    height: "100%",
    justifyContent: "center",
    paddingHorizontal: 4
  },
  inputEditIcon: {
    height: 14,
    width: 14
  },
  inputEditSave: {
    alignItems: "center",
    borderRadius: 16,
    height: 48,
    justifyContent: "center",
    marginLeft: -24,
    width: 48
  },
  inputIcon: {
    backgroundColor: Colors.silver,
    borderBottomRightRadius: 8,
    borderTopRightRadius: 8,
    marginRight: 8,
    padding: 4
  },
  inputSeparator: {
    width: 20
  },
  inputText: {
    color: FontColor.onSurface,
    flex: 1,
    fontSize: 20,
    marginHorizontal: 8
  },
  listButtonText: {
    color: "black",
    fontSize: 14,
    textAlign: "center"
  },
  listItemDate: {
    marginHorizontal: 8
  },
  listItemPadding: {
    width: 70
  },
  listItemText: {
    fontSize: 18,
    textAlign: "center"
  },
  listItemValue: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row",
    marginHorizontal: 8
  },
  row: {
    alignItems: "center",
    flexDirection: "row"
  },
  rowSides: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  selectedButton: {
    backgroundColor: Colors.blue
  },
  selectedText: {
    color: "black"
  },
  statsCard: {
    backgroundColor: BackColor,
    margin: Margin,
    padding: Margin / 2
  },
  statsListItem: {
    alignItems: "center",
    flexDirection: "row",
    flex: 1,
    height: 70,
    justifyContent: "space-around",
    marginVertical: 4
  },
  titleBlock: {
    paddingBottom: 8
  },
  titleText: {
    fontSize: 18,
    paddingLeft: 4
  },
  valueButton: {
    backgroundColor: Colors.blue
  }
})
