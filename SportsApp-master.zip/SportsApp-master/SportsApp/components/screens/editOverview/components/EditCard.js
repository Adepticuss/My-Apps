import React, { useState, useEffect } from "react"
import { View, SafeAreaView, Text, Alert, TouchableOpacity, Image } from "react-native"
import { Icon } from "react-native-elements"

import Images, { getExerciseImage } from "../../../controllers/ExerciseImages"
import { InputMode } from "../../../constants/Input"
import { TextButton } from "../../../modules/Buttons"
import Style, { ActiveColor } from "../Style"

const _defaultType = InputMode.count | InputMode.weight

export const CardType = {
  default: 0,
  new: 1,
  delete: 2
}

export default function EditCard ({ exercise, drag, isActive, cardType, onPress, onTypePress, onDelete }) {
  const [title, setTitle] = useState()
  const [id, setId] = useState()
  const [type, setType] = useState(_defaultType)

  useEffect(() => {
    console.log(id)
  }, [id])

  useEffect(() => {
    if (exercise) {
      setTitle(exercise.name ?? exercise.text)
      if (typeof exercise.type !== "undefined") setType(exercise.type)
      if (typeof exercise.id !== "undefined") setId(exercise.id)
    }
  }, [exercise])

  const style = [Style.editCard]
  if (isActive) style.push(Style.editCardActive)
  if (cardType === CardType.delete) style.push(Style.editCardDelete)
  if (cardType === CardType.new) style.push(Style.editCardNew)

  let rightControl
  if (cardType === CardType.delete) {
    rightControl = (
            <TextButton text='Return' onPress={deleteClick.bind(this)} />
    )
  } else {
    rightControl = (
            <View style={Style.rowSimple}>
                <TouchableOpacity style={Style.typeBlock} onPress={onTypePress}>
                    <Icon name='dots-three-vertical' type='entypo' size={18} color={ActiveColor} />
                    {getTypeIcons(type)}
                </TouchableOpacity>
                <TouchableOpacity style={Style.deleteButton} onPress={deleteClick.bind(this)}>
                    <Image resizeMode='contain' style={Style.deleteIcon} source={require("../../../../assets/icons/action/delete.png")} />
                </TouchableOpacity>
            </View>
    )
  }

  return (
        <TouchableOpacity onLongPress={drag} onPress={onPress}>
            <View style={style}>
                <Image resizeMode='contain' style={Style.exerciseIcon} source={getExerciseImage(id, exercise.custom)} />
                <Text style={Style.cardTitleText}>{title}</Text>
                {rightControl}
            </View>
        </TouchableOpacity>
  )

  function deleteClick () {
    if (typeof onDelete !== "function") return
    onDelete()
  }

  function getTypeIcons (type) {
    const icons = []
    if (type & InputMode.count) {
      icons.push(<Image key='reps' resizeMode='contain' style={Style.typeBlockIcon} source={require("../../../../assets/icons/exercise_types/reps.png")} />)
    }
    if (type & InputMode.weight) {
      icons.push(<Image key='weight' resizeMode='contain' style={Style.typeBlockIcon} source={require("../../../../assets/icons/exercise_types/weight.png")} />)
    }
    if (type & InputMode.timer) {
      icons.push(<Image key='timer' resizeMode='contain' style={Style.typeBlockIcon} source={require("../../../../assets/icons/exercise_types/timer.png")} />)
    }
    if (type & InputMode.stopwatch) {
      icons.push(<Image key='stopwatch' resizeMode='contain' style={Style.typeBlockIcon} source={require("../../../../assets/icons/exercise_types/stopwatch.png")} />)
    }

    return icons
  }

  function getCardStyle (isActive, cardType) {
    const style = [Style.editCard]
    if (isActive) style.push(Style.editCardActive)
    return style
  }
}
