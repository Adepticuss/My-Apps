import React, { useEffect, useRef } from "react"
import { View, StyleSheet } from "react-native"
import BottomSheet from "@gorhom/bottom-sheet"
import { BlurView } from "expo-blur"
import Animated from "react-native-reanimated"

import { TypeButtons } from "../../../modules/TypeSelector"
import Style from "../Style"

export default function TypeModal ({ show, type, onChange, onClose }) {
  const bottomSheetRef = React.createRef()
  const fall = new Animated.Value(1)

  useEffect(() => {
    if (show === true) {
      bottomSheetRef?.current?.expand()
    }
  }, [show])

  const renderContent = () => (
        <View style={Style.bottomSheet}>
            <TypeButtons type={type} onChange={onChange} />
        </View>
  )

  const renderHeader = () => (
        <View style={Style.panelHeader}>
            <View style={Style.panelHandle} />
        </View>
  )

  if (show !== true) {
    return <View />
  }

  return (
        <BlurView intensity={66} style={StyleSheet.absoluteFill}>
            <BottomSheet
                ref={bottomSheetRef}
                snapPoints={[0, 300]}
                index={1}
                animatedPosition={fall}
                overDragResistanceFactor={2.5}
                handleComponent={renderHeader}
                onChange={onSheetChange.bind(this)}
            >
                {renderContent()}
            </BottomSheet>
        </BlurView>
  )

  function onSheetChange (index) {
    console.log(index)
    if (index === 0) {
      bottomSheetRef?.current?.close()
      sheetClose()
    }
  }

  function sheetClose () {
    if (typeof onClose !== "function") return
    onClose()
  }
}
