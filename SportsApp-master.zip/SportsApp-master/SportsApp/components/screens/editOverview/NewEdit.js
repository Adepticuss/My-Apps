import React, { useState, useEffect } from "react"
import { View, SafeAreaView, Text, Alert } from "react-native"
import { Input } from "react-native-elements"
import DraggableFlatList from "react-native-draggable-flatlist"

import WorkoutName from "../../modules/WorkoutName"
import { OutlineTextButton, TextButton } from "../../modules/Buttons"
import { confirmationDialog } from "../../controllers/Dialog"
import Storage from "../../controllers/Storage"
import Style from "./Style"

import EditCard, { CardType } from "./components/EditCard"
import TypeModal from "./components/TypeModal"

export default function Edit ({ navigation, route }) {
  const [routine, setRoutine] = useState({})
  const [exercisesCurrent, setExercisesCurrent] = useState([])
  const [routineName, setRoutineName] = useState("")
  const [showTypeModal, setShowTypeModal] = useState()
  const [selectedExercise, setSelectedExercise] = useState()

  useEffect(() => {
    if (routine?.name) {
      navigation.setOptions({
        title: "Edit \"" + routine.name + "\""
      })

      setRoutineName(routine.name)
    }

    if (routine?.exercises?.length > 0) {
      setExercisesCurrent([...routine?.exercises])
    }

    if (routine?.isNew === true) {
      gotoAddExercise()
    }
  }, [routine])

  useEffect(() => {
    if (route.params?.routine) {
      setRoutine(route.params.routine)
    }
  }, [route.params?.routine])

  useEffect(() => {
    const addedExercises = route.params?.addedExercises
    if (typeof addedExercises === "undefined") return

    const uniqueNew = Object.values(addedExercises).filter((val) => { return exercisesCurrent.findIndex(x => x.id === val.id) === -1 })
    uniqueNew.forEach(x => { x.new = true })

    setExercisesCurrent([...exercisesCurrent, ...uniqueNew])
  }, [route.params?.addedExercises])

  useEffect(() => {
    navigation.removeListener("beforeRemove", _beforeRemove)
    navigation.addListener("beforeRemove", _beforeRemove)
  }, [navigation, route, routine, routineName, exercisesCurrent])

  const _beforeRemove = (e) => {
    // Do nothing for new routines
    if (routine.isNew === true) return

    let hasChanges = false

    // Find changes (new/removed exercises) for existing routine
    const changes = exercisesCurrent?.filter(x => x.toRemove || x.new)
    if (changes?.length > 0) hasChanges = true

    console.log(routineName)
    // Check if input name is the same as existing name
    if (routineName && routineName !== routine.name) hasChanges = true

    if (!hasChanges) return

    e.preventDefault()

    confirmationDialog("Save changes",
      "You have unsaved changes, would you like to save them?",
      () => {
        saveRoutine()
      },
      () => {
        // Clean exercises to remove flag
        exercisesCurrent.forEach(x => {
          delete x.toRemove
        })

        navigation.dispatch(e.data.action)
      })
  }

  return (
        <SafeAreaView style={Style.container}>
            <WorkoutName workoutName={routineName} setWorkoutName={setRoutineName} />

            <DraggableFlatList
                data={exercisesCurrent}
                renderItem={({ item, index, drag, isActive }) => (
                    <EditCard key={index}
                                exercise={item}
                                drag={drag}
                                isActive={isActive}
                                cardType={getCardType(item)}
                                onPress={() => { navigation.navigate("ExerciseDetails", { exercise: item }) }}
                                onTypePress={() => { showModal(item, index) }}
                                onDelete={() => { removeExercise(index, item) }}
                    />
                )}
                keyExtractor={(_, i) => `listItem-${i}`}
                onDragEnd={({ data }) => setExercisesCurrent(data)}
                style={Style.list}
            />

            <View style={Style.rowCenter}>
                <View style={Style.bottomButton}>
                    <OutlineTextButton text='Add exercise' onPress={() => { navigation.navigate("CreateRoutine", { edit: true }) }} />
                </View>
                <View style={Style.bottomButton}>
                    <TextButton text='Save' onPress={saveRoutine.bind(this)} />
                </View>
            </View>

            <TypeModal show={showTypeModal}
                        onClose={() => { setShowTypeModal(false) }}
                        type={selectedExercise?.exercise?.type}
                        onChange={modalTypeChange.bind(this)}
            />
        </SafeAreaView>
  )

  function saveRoutine () {
    const current = exercisesCurrent?.filter(x => !x.toRemove) ?? []
    if (!current.length) {
      return
    }

    current.forEach((x) => {
      delete x.new

      if (x.custom === true) {
        Storage.exercise.set(x.id, x)
      }
    })

    routine.exercises = current
    routine.name = routineName

    Storage.routine.set(routine)
    setExercisesCurrent(JSON.parse(JSON.stringify(current)))

    navigation.reset({
      index: 0,
      routes: [
        { name: "Start" },
        { name: "Routine", params: { routine: routine } }
      ]
    })
  }

  function getCardType (item) {
    if (item.new === true) {
      return CardType.new
    } else if (item.toRemove === true) {
      return CardType.delete
    } else {
      return CardType.default
    }
  }

  function removeExercise (index, item) {
    if (item.new === true) {
      exercisesCurrent.splice(index, 1)
    } else if (item.toRemove === true) {
      delete item.toRemove
    } else {
      item.toRemove = true
    }

    setExercisesCurrent([...exercisesCurrent])
  }

  function showModal (exercise, index) {
    setSelectedExercise({
      exercise: exercise,
      index: index
    })
    setShowTypeModal(true)
  }

  function modalTypeChange (type) {
    console.log(type)
    console.log(selectedExercise)
    const copy = JSON.parse(JSON.stringify(exercisesCurrent))
    copy[selectedExercise.index].type = type
    setExercisesCurrent(copy)
    setShowTypeModal(false)
  }
}
