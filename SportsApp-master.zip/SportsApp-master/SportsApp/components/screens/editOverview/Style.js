import { StyleSheet } from "react-native"
import Colors, { Theme, FontColor } from "../../styles/Colors"

export const TooltipColor = Colors.blue
export const ActiveColor = Theme.primary

const _margin = 12

const oldStyle = StyleSheet.create({
  addButtonText: {
    color: Colors.alpha.heavy,
    fontSize: 24,
    marginTop: -2
  },
  addExercisesButton: {
    backgroundColor: Colors.lightYellow
  },
  buttonPanel: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    margin: 12,
    paddingHorizontal: 8
  },
  container: {
    flex: 1
  },
  disabledButton: {
    backgroundColor: Colors.grey
  },
  explanation: {
    color: Colors.alpha.medium,
    fontSize: 18,
    textAlign: "center"
  },
  help: {
    backgroundColor: "white",
    borderColor: Colors.blue,
    borderWidth: 1
  },
  helpText: {
    fontSize: 16
  },
  list: {
    flex: 1,
    paddingLeft: 8,
    paddingRight: 8
  },
  nameInput: {
    flex: 1,
    marginHorizontal: 8
  },
  saveButton: {
    backgroundColor: Colors.blue
  }
})

const newStyle = StyleSheet.create({
  bottomButton: {
    marginHorizontal: 4
  },
  bottomSheet: {
    backgroundColor: Theme.surface,
    height: "100%",
    paddingBottom: 32,
    width: "100%"
  },
  cardTitleText: {
    flex: 1,
    paddingHorizontal: 4,
    textAlign: "center"
  },
  container: {
    backgroundColor: Theme.background,
    flex: 1
  },
  deleteButton: {
    alignItems: "center",
    height: "70%",
    justifyContent: "center",
    marginHorizontal: 8
  },
  deleteIcon: {
    alignItems: "center",
    height: 18,
    width: 18
  },
  editCard: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    margin: 2,
    marginBottom: 4,
    padding: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  editCardActive: {
    marginHorizontal: _margin,
    opacity: 0.5
  },
  editCardDelete: {
    opacity: 0.25
  },
  editCardNew: {
    backgroundColor: Theme.primary
  },
  exerciseIcon: {
    borderRadius: 16,
    height: 72,
    marginVertical: 8,
    width: 72
  },
  flex: {
    flex: 1
  },
  fullContainer: {
    height: "100%",
    position: "absolute",
    width: "100%"
  },
  list: {
    flex: 1,
    marginTop: 8,
    paddingHorizontal: _margin
  },
  nameBlock: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flexDirection: "row",
    marginHorizontal: _margin,
    marginTop: _margin,
    paddingVertical: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  nameTextContainer: {
    flex: 1,
    flexDirection: "row"
  },
  nameTextInputContainer: {
    alignItems: "center",
    borderColor: Theme.primary,
    borderRadius: 9,
    borderWidth: 1,
    justifyContent: "center",
    paddingHorizontal: 12,
    paddingVertical: 4
  },
  nameTitleBlock: {
    marginLeft: 16
  },
  nameTitleTextBig: {
    color: FontColor.onSurface,
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: -12
  },
  nameTitleTextExclamation: {
    color: Theme.primary,
    fontSize: 24,
    fontWeight: "bold"
  },
  nameTitleTextSmall: {
    color: FontColor.onSurface,
    fontSize: 16,
    marginBottom: 2
  },
  panelHandle: {
    backgroundColor: "black",
    borderRadius: 4,
    height: 3,
    width: 40
  },
  panelHeader: {
    alignItems: "center",
    backgroundColor: "white",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingVertical: 20
  },
  row: {
    alignItems: "flex-end",
    flexDirection: "row"
  },
  rowCenter: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 32,
    marginTop: 8
  },
  rowSimple: {
    alignItems: "center",
    flexDirection: "row",
    height: "100%"
  },
  typeBlock: {
    backgroundColor: Theme.background,
    borderRadius: 12,
    height: "100%",
    justifyContent: "space-between",
    padding: 8
  },
  typeBlockIcon: {
    height: 18,
    marginVertical: 4,
    width: 18
  },
  typeButton: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    height: 85,
    justifyContent: "center",
    marginHorizontal: 4,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07,
    width: 80
  },
  typeButtonActive: {
    backgroundColor: Theme.primary,
    shadowOpacity: 0
  },
  typeButtonIcon: {
    height: 24,
    marginHorizontal: 2,
    width: 24
  },
  typeButtonIconActive: {
    tintColor: FontColor.onPrimary
  },
  typeButtonRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 8
  },
  typeButtonText: {
    color: FontColor.onSurface,
    marginTop: 4,
    textAlign: "center"
  },
  typeButtonTextActive: {
    color: FontColor.onPrimary
  }
})

export default newStyle
