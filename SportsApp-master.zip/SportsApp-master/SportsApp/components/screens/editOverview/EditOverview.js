import React, { useState, useEffect, useRef } from "react"
import { View, SafeAreaView, Text, Alert, AsyncStorage } from "react-native"
import { Icon, Tooltip, Input } from "react-native-elements"
import DraggableFlatList from "react-native-draggable-flatlist"
import * as Analytics from "expo-firebase-analytics"

import Storage from "../../controllers/Storage"
import { RoundButton } from "../../modules/basic/Buttons"
import EditCard, { EditCardType } from "../../modules/EditCard"
import { InputMode } from "../../constants/Input"
import TypeSelector from "../../modules/TypeSelector"

import Style, { TooltipColor } from "./Style"

export default function EditOverview ({ navigation, route }) {
  const [routine, setRoutine] = useState({})
  const [exercisesCurrent, setExercisesCurrent] = useState([])
  const [routineName, setRoutineName] = useState("")

  const [showModal, setShowModal] = useState(false)
  const [exerciseClicked, setExerciseClicked] = useState({})
  const helpRef = useRef(null)

  useEffect(() => {
    if (routine?.name) {
      navigation.setOptions({
        title: "Edit \"" + routine.name + "\""
      })

      setRoutineName(routine.name)
    }

    if (routine?.exercises?.length > 0) {
      setExercisesCurrent([...routine?.exercises])
    }

    if (routine?.isNew === true) {
      gotoAddExercise()
    }
  }, [routine])

  useEffect(() => {
    if (route.params?.routine) {
      setRoutine(route.params.routine)
    }
  }, [route.params?.routine])

  useEffect(() => {
    if (route.params?.newExercise?.length > 0) {
      if (routine.isNew && exercisesCurrent.length === 0) {
        showHelp(helpRef)
      }

      const uniqueNew = route.params.newExercise.filter((val) => { return exercisesCurrent.findIndex(x => x.id === val.id) === -1 })
      uniqueNew.forEach(x => { x.new = true })
      setExercisesCurrent([...exercisesCurrent, ...uniqueNew])
    }
  }, [route.params?.newExercise])

  useEffect(() => {
    navigation.removeListener("beforeRemove", _beforeRemove)
    navigation.addListener("beforeRemove", _beforeRemove)
  }, [navigation, route, routine, routineName, exercisesCurrent])

  const _beforeRemove = (e) => {
    // Do nothing for new routines
    if (routine.isNew) return

    let hasChanges = false

    // Find changes (new/removed exercises) for existing routine
    const changes = exercisesCurrent?.filter(x => x.toRemove || x.new)
    if (changes?.length > 0) hasChanges = true

    console.log(routineName)
    // Check if input name is the same as existing name
    if (routineName && routineName !== routine.name) hasChanges = true

    if (!hasChanges) return

    e.preventDefault()

    confirmationDialog("Save changes",
      "You have unsaved changes, would you like to save them?",
      () => {
        Analytics.logEvent("EditUnsavedChangesSaved", { exercise: changes.length + "" })
        saveRoutine()
      },
      () => {
        Analytics.logEvent("EditUnsavedChangesDropped", { exercise: changes.length + "" })
        // Clean exercises to remove flag
        exercisesCurrent.forEach(x => {
          delete x.toRemove
        })

        navigation.dispatch(e.data.action)
      })
  }

  const saveHelpText = (
        <Text style={Style.helpText}>Press to save workout</Text>
  )

  let saveButton, explanation
  if (exercisesCurrent?.length > 0) {
    saveButton = (<RoundButton content={<Icon name='content-save-outline' type='material-community' />}
                                    style={[Style.saveButton]}
                                    onPress={saveRoutine.bind(this)} />

    )
  } else {
    saveButton = (<RoundButton content={<Icon name='content-save-outline' type='material-community' />}
                                    style={[Style.disabledButton]}
                                    disabled={true} />)
    explanation = (<Text style={Style.explanation}>Press &#39;+&#39; to add exercise(s)</Text>)
  }

  return (
        <SafeAreaView style={Style.container}>

            <View style={Style.buttonPanel}>
                <RoundButton content={<Text style={Style.addButtonText}>+</Text>}
                                style={[Style.addExercisesButton]}
                                onPress={gotoAddExercise.bind(this)} />

                <Input placeholder='Workout name'
                        value={routineName}
                        onChangeText={val => setRoutineName(val)}
                        containerStyle={Style.nameInput} />

                <Tooltip ref={helpRef} popover={saveHelpText} height={80} toggleOnPress={false} containerStyle={Style.help} pointerColor={TooltipColor}>
                    {saveButton}
                </Tooltip>
            </View>

            {explanation}

            <DraggableFlatList data={exercisesCurrent}
                                renderItem={({ item, index, drag, isActive }) => <EditCard key={index} exercise={item} drag={drag} isActive={isActive} type={getCardType(item)}
                                                                                            click={() => { navigation.navigate("ExerciseDetails", { exercise: item }) }}
                                                                                            typeClick={() => { typeClick(index, item) }}
                                                                                            removeClick={() => { removeExercise(index, item) }} />}
                                keyExtractor={(_, i) => i.toString()}
                                onDragEnd={({ data }) => setExercisesCurrent(data)}
                                style={Style.list} />

            <TypeSelector visible={showModal} type={exerciseClicked?.val?.type ?? InputMode.count | InputMode.weight} closed={() => { setShowModal(false) }} typeClicked={typeSelected} />

        </SafeAreaView>
  )

  function showHelp (helpRef) {
    AsyncStorage.getItem("firstNewRoutineScreenComplete", (_, r) => {
      if (r === "true") return
      setTimeout(() => { helpRef.current.toggleTooltip() }, 333)
      AsyncStorage.setItem("firstNewRoutineScreenComplete", "true")
    })
  }

  function getCardType (item) {
    if (item.toRemove) return EditCardType.remove
    if (item.new) return EditCardType.new
    return EditCardType.current
  }

  function typeClick (key, val) {
    setExerciseClicked({ key: key, val: val })
    setShowModal(true)
  }

  function typeSelected (type) {
    const copy = JSON.parse(JSON.stringify(exercisesCurrent))
    copy[exerciseClicked.key].type = type
    setExercisesCurrent(copy)
    setShowModal(false)
  }

  function removeExercise (index, item) {
    if (item.new) {
      Analytics.logEvent("EditRemove", { action: "remove_new" })
      exercisesCurrent.splice(index, 1)
    } else if (item.toRemove) {
      Analytics.logEvent("EditRemove", { action: "remove" })
      delete item.toRemove
    } else {
      Analytics.logEvent("EditRemove", { action: "recover" })
      item.toRemove = true
    }

    setExercisesCurrent([...exercisesCurrent])
  }

  function saveRoutine () {
    const current = exercisesCurrent?.filter(x => !x.toRemove) ?? []
    if (!current.length) {
      Analytics.logEvent("EditSave", { emptyList: "true", new: routine.isNew + "" })
      return
    }

    Analytics.logEvent("EditSave", { emptyList: "false", new: routine.isNew + "" })

    current.forEach((x) => {
      delete x.new

      if (x.custom === true) {
        Storage.exercise.set(x.id, x)
      }
    })

    const isNew = routine.isNew
    routine.exercises = current
    routine.name = routineName
    routine.isNew = false

    Storage.routine.set(routine)
    setExercisesCurrent(JSON.parse(JSON.stringify(current)))

    if (!isNew) {
      navigation.navigate("Routine", { routine: routine })
      return
    }

    navigation.reset({
      index: 0,
      routes: [
        { name: "Home", params: { newRoutine: routine } },
        { name: "Routine", params: { routine: routine } }
      ]
    })
  }

  function gotoAddExercise () {
    navigation.navigate("AddExercise")
  }

  function confirmationDialog (title, text, yesFunc, noFunc) {
    Alert.alert(
      title,
      text,
      [
        {
          text: "No",
          style: "cancel",
          onPress: noFunc
        },
        {
          text: "Yes",
          onPress: yesFunc
        }
      ]
    )
  }
}
