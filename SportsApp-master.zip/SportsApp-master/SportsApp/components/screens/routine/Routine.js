import React, { useState, useEffect } from "react"
import { View, SafeAreaView, FlatList, Alert, TouchableOpacity, Text, Platform, Image, Keyboard, ActivityIndicator } from "react-native"
import UUID from "react-native-uuid"
import KeyboardSpacer from "react-native-keyboard-spacer"
import * as Analytics from "expo-firebase-analytics"
import { useKeepAwake } from "expo-keep-awake"
import { AdMobBanner } from "expo-ads-admob"
import { BottomSheetModalProvider } from "@gorhom/bottom-sheet"

import Storage from "../../controllers/Storage"
import { parseSettings, createSettingsDefault } from "../../models/Settings"

import StatusBar from "./components/StatusBar"
import ExerciseCard from "./components/ExerciseCard"
import { ExerciseModal, OverviewModal, HistoryModal } from "./components/Modals"
import Style from "./Style"

const EditButton = ({ onPress }) => {
  return (
        <TouchableOpacity onPress={onPress} style={Style.editButton}>
            <Text style={Style.headerRightText}>Edit</Text>
            <Image resizeMode='contain' style={Style.headerRightIcon} source={require("../../../assets/icons/header/edit.png")} />
        </TouchableOpacity>
  )
}

export default function Routine ({ navigation, route }) {
  const [workoutId] = useState(UUID.v4())

  const [isLoading, setIsLoading] = useState(false)
  const [started, setStarted] = useState(false)
  const [complete, setComplete] = useState(false)
  const [showDetails, setShowDetails] = useState(false)
  const [showOverview, setShowOverview] = useState(false)
  const [showHistory, setShowHistory] = useState(false)

  const [completeExercise] = useState({})
  const [workoutData] = useState({})
  const [routine, setRoutine] = useState({})
  const [detailsExercise, setDetailsExercise] = useState()
  const [historyExercise, setHistoryExercise] = useState()
  const [completeCount, setCompleteCount] = useState()
  const [duration, setDuration] = useState()
  const [weightUnit, setWeightUnit] = useState()
  const [showMillisec, setShowMillisec] = useState()
  const [autoCollapse, setAutoCollapse] = useState()

  const [list, setList] = useState(null)

  useKeepAwake()

  useEffect(() => {
    if (complete) setShowOverview(true)
    console.log(JSON.stringify(workoutData))
  }, [complete])

  useEffect(() => {
    let headerRight
    if (!started) {
      headerRight = <EditButton onPress={() => { navigation.navigate("EditOverview", { routine: routine }) }} />
    }

    navigation.setOptions({
      headerRight: () => headerRight
    })
  }, [started])

  useEffect(() => {
    if (routine?.name) {
      navigation.setOptions({
        title: routine.name,
        headerRight: () => <EditButton onPress={() => { navigation.navigate("EditOverview", { routine: routine }) }} />
      })
    }
  }, [routine])

  useEffect(() => {
    navigation.removeListener("beforeRemove", _beforeRemove)
    navigation.addListener("beforeRemove", _beforeRemove)
  }, [navigation, started, complete, routine])

  const _beforeRemove = (e) => {
    if (!started) {
      Analytics.logEvent("WorkoutBackNotStarted", { exercise: routine?.exercises?.length + "" })
      return
    }

    if (!complete) {
      e.preventDefault()

      confirmationDialog("Cancel workout",
        "You are about to cancel workout, are sure?",
        () => {
          Analytics.logEvent("WorkoutBackDroped", { exercise: routine?.exercises?.length + "" })
          navigation.dispatch(e.data.action)
        },
        () => {
          Analytics.logEvent("WorkoutBackCancel", { exercise: routine?.exercises?.length + "" })
        },
        "Cancel",
        "Continue")
    }
  }

  useEffect(() => {
    Storage.settings.get((x) => {
      let settings = parseSettings(x)
      if (!settings) {
        settings = createSettingsDefault()
      }

      setWeightUnit(settings.weightUnit)
      setShowMillisec(settings.showMillisec)
      setAutoCollapse(settings.autoCollapse)
    })
  }, [])

  // Effect (Route)
  useEffect(() => {
    if (route.params?.routine) {
      const id = route.params.routine?.id
      setIsLoading(true)
      Storage.routine.get(id, (val) => {
        if (!val) {
          setIsLoading(false)
          return
        }

        const routine = JSON.parse(val)
        setRoutine(routine)
        setIsLoading(false)
      })
    }
  }, [route.params?.routine])

  let spacer
  if (Platform.OS === "ios") {
    spacer = (<KeyboardSpacer />)
  }

  if (isLoading) {
    return <ActivityIndicator size='large' />
  }

  return (
    <BottomSheetModalProvider>
        <SafeAreaView style={Style.container}>

            <ExerciseModal exerciseId={detailsExercise?.id} visible={showDetails} close={() => { setShowDetails(false) }} />
            <OverviewModal duration={duration} data={workoutData} id={workoutId} visible={showOverview} close={() => { setShowOverview(false); navigation.goBack() }} />
            <HistoryModal exerciseId={historyExercise?.id} visible={showHistory} close={() => { setShowHistory(false) }} />

            <View style={Style.screenBlock}>
              <View style={[]}>
              <AdMobBanner bannerSize='smartBannerPortrait'
                           adUnitID="ca-app-pub-3117874155560622/9588748317"
                           onDidFailToReceiveAdWithError={(x) => console.log(JSON.stringify(x))}/>
              </View>

              <FlatList data={routine?.exercises}
                        ref={ref => { setList(ref) }}
                        renderItem={({ item }) => (
                            <ExerciseCard exercise={item} routineId={routine?.id} disabled={!started}
                                          weightUnit={weightUnit} showMillisec={showMillisec} autoCollapse={autoCollapse}
                                          infoClick={() => { setDetailsExercise(item); setShowDetails(true); Keyboard.dismiss() }}
                                          historyClick={() => { setHistoryExercise(item); setShowHistory(true); Keyboard.dismiss() }}
                                          onUpdate={(sets, complete, lastResults) => { updateExercise(item, sets, complete, lastResults) }} />
                        )}
                        keyExtractor={item => `exercise-${item.id}`}
                        keyboardShouldPersistTaps={"handled"}
                        style={Style.flex} />
            </View>

            <View style={Style.footerBlock}>
              <StatusBar started={started} complete={complete}
                              totalExercise={routine?.exercises?.length} completeExercise={completeCount}
                              startClick={startClick.bind(this)}
                              finishClick={(ms) => { tryFinishWorkout(ms) }}
                              progressClick={progressClick.bind(this)} />
                  {/* status bar */}
            </View>

            {spacer}

        </SafeAreaView>
    </BottomSheetModalProvider>
  )

  function startClick () {
    setStarted(true)
    Analytics.logEvent("StartWorkout", { exercise: routine?.exercises?.length + "" })
  }

  function progressClick () {
    if (!routine?.exercises?.length) return

    for (let i = 0; i < routine.exercises.length; i++) {
      const item = routine.exercises[i]

      if (!item?.id) continue
      if (completeExercise[item.id] === true) continue

      list?.scrollToIndex({ animated: true, index: i })
      break
    }
  }

  function tryFinishWorkout (ms) {
    if (routine?.exercises?.length === completeCount) {
      finishWorkout(ms)
    } else {
      confirmationDialog("Incomplete workout",
        "You didn't enter result(s) for some exercises. Do you want to finish workout?",
        () => {
          finishWorkout(ms)
        },
        () => {
        },
        "Finish",
        "Continue")
    }
  }

  function finishWorkout (ms) {
    console.log(ms)
    const completeness = (completeCount / routine?.exercises?.length).toFixed(1)
    const totalSeconds = Math.round(ms / 1000)

    setDuration(ms)
    setComplete(true)
    Analytics.logEvent("FinishWorkout", { seconds: totalSeconds + "", completeness: completeness + "" })
    saveAll()

    const workoutData = {
      id: workoutId,
      routine: routine.id,
      routineName: routine.name,
      duration: ms,
      counts: {
        exercisesComplete: completeCount,
        exercisesTotal: routine.exercises?.length
      },
      timestamp: +new Date()
    }

    saveWorkoutData(workoutData)
  }

  function saveWorkoutData (workoutData) {
    if (!workoutData?.id) return
    Storage.workout.set(workoutData?.id, workoutData)
  }

  function confirmationDialog (title, text, yesFunc, noFunc, yesTextOpt, noTextOpt) {
    const yesText = yesTextOpt ?? "Yes"
    const noText = noTextOpt ?? "No"

    Alert.alert(
      title,
      text,
      [
        {
          text: noText,
          style: "cancel",
          onPress: noFunc
        },
        {
          text: yesText,
          onPress: yesFunc
        }
      ]
    )
  }

  function updateExercise (exercise, sets, complete, lastResults) {
    if (!exercise?.id) return
    if (!started) {
      const merge = mergeSets(sets, lastResults)
      Storage.lastResult.set(routine.id, exercise.id, merge)
    }

    workoutData[exercise.id] = sets
    completeExercise[exercise.id] = complete
    setCompleteCount(countCompleteList(completeExercise))
  }

  function mergeSets (main, extra) {
    if (!extra) return main
    const array = new Array(main.length)

    for (let i = 0; i < array.length; i++) {
      array[i] = main[i]
      if (isEmptyObject(array[i]) && extra[i]) {
        array[i] = extra[i]
      }
    }

    return array
  }

  function isEmptyObject (obj) {
    const values = Object.values(obj)
    let empty = true
    values.forEach(x => {
      if (x) empty = false
    })
    return empty
  }

  function countCompleteList (list) {
    let count = 0
    for (const key in list) {
      if (list[key] === true) count++
    }

    return count
  }

  function sanitizeReps (reps) {
    const clean = []
    if (!reps?.length) return clean

    for (let i = 0; i < reps.length; i++) {
      const rep = reps[i]
      if (!rep) continue

      const data = {}

      if (rep.weight) data.weight = rep.weight
      if (rep.count) data.reps = rep.count
      if (rep.reps) data.reps = rep.reps
      if (rep.time) data.time = rep.time
      if (typeof rep.elapsed !== "undefined") data.elapsed = rep.elapsed

      if (data.weight || data.reps || data.time) clean.push(data)
    }

    return clean
  }

  function saveHistorySingle (id) {
    const input = workoutData[id]
    if (!input || !workoutId) return

    const sanitized = sanitizeReps(input)
    if (sanitized.length === 0) return
    const val = {
      reps: sanitized,
      weightUnit: weightUnit,
      timestamp: +new Date()
    }

    Storage.history.set(workoutId, id, val)
    Storage.lastResult.set(routine.id, id, sanitized)
  }

  function saveAll () {
    if (!routine?.exercises) return

    routine.exercises.forEach(x => {
      saveHistorySingle(x.id)
    })
  }
}
