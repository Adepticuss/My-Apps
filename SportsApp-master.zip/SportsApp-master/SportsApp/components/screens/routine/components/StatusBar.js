import React, { useEffect, useState } from "react"
import { View, Text, TouchableOpacity } from "react-native"
import Tooltip from "react-native-walkthrough-tooltip"

import { runOnKeyNotSet } from "../../../shared/functions/FirstRun"
import Style from "../Style"
import Stopwatch from "./NewStopwatch"
import { TextButton } from "../../../modules/Buttons"

export default function StatusBar ({ started, complete, totalExercise, completeExercise, startClick, finishClick, progressClick }) {
  const [elapsed, setElapsed] = useState(0)
  const [showTooltip, setShowTooltip] = useState()

  useEffect(() => {
    runOnKeyNotSet("firstStatusBar", () => { setShowTooltip(true) })
  }, [])

  if (!started) {
    const startHelp = (
      <View style={Style.helpTextBlock}>
        <Text style={[Style.helpTextTitle, Style.textPrimary]}>Start</Text>
        <Text style={Style.helpText}>Click Start button to begin your workout session</Text>
        <Text style={[Style.helpTextTitle, Style.textSecondary]}>Finish</Text>
        <Text style={Style.helpText}>Click Finish when you complete your workout</Text>
        <Text style={Style.helpTextTitle}>Sets</Text>
        <Text style={Style.helpText}>Click sets+ to add sets, they will be saved for you</Text>
      </View>
    )

    return (
            <View style={[Style.statusBar, Style.statusBarStart, Style.row]}>

                <View style={Style.statusBarStartBlock}>
                    <Tooltip isVisible={showTooltip}
                             content={startHelp}
                             placement="top"
                             arrowSize={{ width: 16, height: 24 }}
                             childContentSpacing={4}
                             onClose={() => setShowTooltip(false)}>
                        <TextButton text='Press to start' onPress={startClick} />
                    </Tooltip>
                </View>

            </View>
    )
  }

  const progress = (completeExercise ?? 0) / (totalExercise ?? 1)

  return (
        <View style={[Style.statusBar, Style.row]}>

            <TouchableOpacity style={[Style.statusBarStartedBlock, Style.statusBarProgressBlock]} onPress={progressClick}>
              <View style={Style.streakCurrentProgressFront}>
                <View style={[Style.streakCurrentProgressFrontActive, { flex: progress }]}>
                </View>
                <Text style={Style.statusBarCompleteText}>{completeExercise ?? 0}/{totalExercise ?? 0}</Text>
              </View>
            </TouchableOpacity>

            <View style={[Style.statusBarStartedBlock, Style.statusBarStopwatch]}>
                <Stopwatch start={started && !complete}
                            reset={false}
                            onInterval={(ms) => { setElapsed(ms) } }
                            containerStyle={Style.stopwatchContainer}
                            textStyle={Style.stopwatchText}
                />
            </View>

            <View style={Style.flex}>
                <TextButton text="Finish" onPress={finish.bind(this)} style={Style.finishButton} />
            </View>

        </View>
  )

  function finish () {
    console.log(elapsed)
    finishClick(elapsed)
  }
}
