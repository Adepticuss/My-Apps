import React, { useState } from "react"
import { View, TouchableOpacity, Text } from "react-native"
import { Icon } from "react-native-elements"
import Stopwatch from "./NewStopwatch"

import { formatMillisecond } from "../../../controllers/Time"
import Style from "../Style"
import Colors from "../../../styles/Colors"
import { StopwatchModal } from "../components/Modals"

export default function FullStopwatch ({ startTime, showMillisec, placeholder, onPause, disabled }) {
  const [ms, setMs] = useState()
  const [start, setStart] = useState(false)
  const [reset, setReset] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [localStartTime, setLocalStartTime] = useState(0)

  useState(() => {
    if (typeof startTime !== "undefined") {
      setLocalStartTime(startTime)
    }
  }, [startTime])

  let playPauseButton, editButton
  if (!disabled) {
    playPauseButton = (
            <TouchableOpacity onPress={playPauseClick.bind(this)} style={Style.stopwatchButton}>
                <Icon name={start ? "pause" : "play-arrow"} type='material' color={Colors.alpha.heavy} />
            </TouchableOpacity>
    )

    if (!start) {
      editButton = (
                <TouchableOpacity onPress={showEdit.bind(this)} style={Style.stopwatchButton}>
                    <Icon name='playlist-edit' type='material-community' color={Colors.alpha.medium} />
                </TouchableOpacity>
      )
    } else {
      editButton = (<View style={Style.stopwatchButtonPlaceholder}/>)
    }
  }

  let stopwatch
  if (!showModal) {
    stopwatch = (<Stopwatch start={start}
                            reset={reset}
                            initialTime={localStartTime}
                            showMs={showMillisec}
                            onInterval={(ms) => { setMs(ms) } }
                            containerStyle={Style.stopwatchContainer}
                            textStyle={Style.stopwatchTextBig}
                />)
  } else {
    stopwatch = (<Text>*editing</Text>)
  }

  return (
        <View style={[Style.flex, Style.row, Style.stopwatch]}>
            {playPauseButton}

            <View style={Style.flex}>
                {stopwatch}
                <Text style={Style.stopwatchPlaceholder}>{formatMillisecond(placeholder)}</Text>
            </View>

            {editButton}

            <StopwatchModal visible={showModal} close={() => { setShowModal(false) }} time={localStartTime} updateTime={(val) => { updateTime(val) } } />
        </View>
  )

  function showEdit () {
    setShowModal(true)
  }

  function playPauseClick () {
    if (!start) {
      setReset(false)
    } else {
      updateTime(ms)
    }

    setStart(!start)
  }

  function updateTime (val) {
    setLocalStartTime(val)
    if (typeof onPause === "function") onPause(val)
  }
}
