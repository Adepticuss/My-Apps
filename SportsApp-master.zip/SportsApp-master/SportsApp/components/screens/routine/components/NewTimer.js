import React, { useState, useRef, useEffect } from "react"
import { View, Text } from "react-native"

export default function Timer ({ start, reset, totalDuration, showMs, onPause, onFinish, onInterval, containerStyle, textStyle }) {
  const [elapsed, setElapsed] = useState(0)
  const [isActive, setIsActive] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [startTime, setStartTime] = useState()
  const [intervalDuration] = useState(showMs ? 42 : 1000)
  const interval = useRef(null)

  useEffect(() => {
    console.log(totalDuration)
  }, [totalDuration])

  useEffect(() => {
    if (!reset) {
      if (start) {
        if (isPaused) {
          _resume()
        } else {
          _start()
        }
      } else {
        _pause()
      }
    } else {
      _reset()
    }

    return () => {
      clearInterval(interval.current)
    }
  }, [start, reset])

  return (
        <View style={containerStyle}>
            <Text style={textStyle}>{formatTime()}</Text>
        </View>
  )

  function _start () {
    console.log("start")
    setIsActive(true)
    setIsPaused(false)
    const newStartTime = new Date()
    setStartTime(newStartTime)
    interval.current = setInterval(() => { intervalFunction(newStartTime) }, intervalDuration)
  }

  function _pause () {
    console.log("pause")
    setIsPaused(true)
    clearInterval(interval.current)
    if (typeof onPause === "function") onPause(elapsed)
  }

  function _resume () {
    console.log("resume")
    setIsPaused(false)
    const newStartTime = new Date()
    setStartTime(newStartTime)
    interval.current = setInterval(() => { intervalFunction(newStartTime) }, intervalDuration)
  }

  function _reset () {
    console.log("reset")
    setIsActive(false)
    setIsPaused(false)
    setElapsed(0)
    clearInterval(interval.current)
  }

  function intervalFunction (startTime) {
    let newElapsed = elapsed + (new Date() - startTime)
    if (newElapsed >= totalDuration) {
      newElapsed = totalDuration
      clearInterval(interval.current)
      onFinish()
    }

    setElapsed(newElapsed)
    if (typeof onInterval === "function") onInterval(newElapsed)
  }

  function formatTime () {
    const timerMs = totalDuration - elapsed
    const ms = timerMs % 1000
    const seconds = parseInt(timerMs / 1000)
    const getSeconds = `0${(seconds % 60)}`.slice(-2)
    const minutes = `${Math.floor(seconds / 60)}`
    const getMinutes = `0${minutes}`.slice(-2)
    const getHours = `0${Math.floor(seconds / 3600)}`.slice(-2)

    let output = `${getMinutes}:${getSeconds}`
    if (showMs) {
      output = output + "." + `00${ms}`.slice(-3)
    }

    return output
  }
}
