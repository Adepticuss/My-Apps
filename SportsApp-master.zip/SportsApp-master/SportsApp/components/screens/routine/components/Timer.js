import React, { useEffect, useState } from "react"
import { View, TouchableOpacity, Text } from "react-native"
import { Icon } from "react-native-elements"
import { Audio } from "expo-av"

import Timer from "./NewTimer"
import { formatMillisecond } from "../../../modules/HistoryCard"
import Style, { FrontColor } from "../Style"
import Colors from "../../../styles/Colors"
import { StopwatchModal } from "../components/Modals"

const stopwatchOptions = {
  container: {
    backgroundColor: "rgba(0,0,0,0)",
    padding: 4
  },
  text: {
    fontSize: 26,
    textAlign: "center",
    color: FrontColor
  }
}

export default function FullTimer ({ duration, showMillisec, placeholder, onPause, onDurationChange, disabled }) {
  const msBuffer = 0
  const [ms, setMs] = useState()
  const [finished, setFinished] = useState(false)
  const [start, setStart] = useState(false)
  const [reset, setReset] = useState(false)
  const [showModal, setShowModal] = useState(false)
  const [totalDuration, setTotalDuration] = useState(0)

  useEffect(() => {
    if (duration) setTotalDuration(duration)
  }, [duration])

  let playPauseButton, editButton
  if (!disabled) {
    playPauseButton = (
            <TouchableOpacity onPress={playPauseClick.bind(this)} style={Style.stopwatchButton}>
                <Icon name={start ? "pause" : "play-arrow"} type='material' color={Colors.alpha.heavy} />
            </TouchableOpacity>
    )

    if (!start) {
      editButton = (
                <TouchableOpacity onPress={showEdit.bind(this)} style={Style.stopwatchButton}>
                    <Icon name='av-timer' type='material-community' color={Colors.alpha.medium} />
                </TouchableOpacity>
      )
    } else {
      editButton = (<View style={Style.stopwatchButtonPlaceholder}/>)
    }
  }

  let timer
  if (!showModal) {
    timer = (
            <TouchableOpacity onPress={showEdit.bind(this)}>
                <Timer start={start}
                        reset={reset}
                        totalDuration={totalDuration}
                        showMs={showMillisec}
                        onInterval={(ms) => { setMs(ms) } }
                        containerStyle={Style.stopwatchContainer}
                        textStyle={Style.stopwatchTextBig}
                        onFinish={finish.bind(this)} />
            </TouchableOpacity>
    )
  } else {
    timer = (
            <Timer start={false} reset={false} totalDuration={totalDuration} showMs={showMillisec} containerStyle={Style.stopwatchContainer} textStyle={Style.stopwatchTextBig} />
    )
  }
  /* if (!showModal) {
    stopwatch = (
            <TouchableOpacity onPress={showEdit.bind(this)}>
                <Timer start={start} reset={reset} totalDuration={totalDuration} msecs={showMillisec} getMsecs={(ms) => { msBuffer = ms } } handleFinish={finish.bind(this)} options={stopwatchOptions} />
            </TouchableOpacity>
    )
  } else {
    stopwatch = (
            <Timer start={false} reset={false} totalDuration={totalDuration} msecs={showMillisec} options={stopwatchOptions} />
    )
  } */

  return (
        <View style={[Style.flex, Style.row, Style.stopwatch]}>
            {playPauseButton}

            <View style={Style.flex}>
                {timer}
                <Text style={Style.stopwatchPlaceholder}>{formatMillisecond(placeholder)}</Text>
            </View>

            {editButton}

            <StopwatchModal visible={showModal} close={() => { setShowModal(false) }} time={totalDuration} updateTime={(val) => { setTotalDuration(val); onDurationChange(val) } } />
        </View>
  )

  function showEdit () {
    setShowModal(true)
  }

  function finish () {
    if (finished) return
    setFinished(true)
    setStart(false)
    if (typeof onPause === "function") onPause(0)
    playSound()
  }

  async function playSound () {
    if (finished) return
    console.log("Loading Sound")
    const { sound } = await Audio.Sound.createAsync(
      require("../../../../assets/audio/timer_finish.mp3")
    )

    console.log("Playing Sound")
    await sound.playAsync()
  }

  function playPauseClick () {
    if (!start) {
      setFinished(false)
      setReset(false)
    } else {
      if (typeof onPause === "function") onPause(ms)
    }

    setStart(!start)
  }
}
