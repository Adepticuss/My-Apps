import React, { useState, useEffect } from "react"
import { View, Text, Image } from "react-native"
import { Button, Icon } from "react-native-elements"

import { InputMode } from "../../../constants/Input"

import NumberInput from "./NumberInput"
import Stopwatch from "./Stopwatch"
import Timer from "./Timer"
import Style, { FrontColor } from "../Style"

export default function InputRow ({ index, values, placeholders, solo, disabled, type, showMillisec, onUpdate, onDelete }) {
  const [weight, setWeight] = useState()
  const [reps, setReps] = useState()
  const [time, setTime] = useState()
  const [elapsed, setElapsed] = useState()

  useEffect(() => {
    if (!values) return

    if (values?.weight) setWeight(values?.weight)
    if (values?.reps) setReps(values?.reps)

    if (type & InputMode.stopwatch) {
      if (values?.time) setTime(values?.time)
    } else if (type & InputMode.timer) {
      if (values?.time) {
        setTime(values?.time)
      } else if (placeholders?.time) {
        setTime(placeholders?.time)
      }

      if (values?.elapsed) setElapsed(values?.elapsed)
    }
  }, [values])

  let weightInput, repsInput, stopwatch, timer
  if (type & InputMode.weight) {
    weightInput = (
            <NumberInput value={weight} placeholder={placeholders?.weight} disabled={disabled} onEndEditing={update.bind(this)} onUpdate={(val) => { setWeight(val) }} style={[Style.flex, Style.rowInput]} />
    )
  }

  if (type & InputMode.count) {
    repsInput = (
            <NumberInput value={reps} placeholder={placeholders?.reps} disabled={disabled} onEndEditing={update.bind(this)} onUpdate={(val) => { setReps(val) }} style={[Style.flex, Style.rowInput]} />
    )
  }

  if (type & InputMode.stopwatch) {
    stopwatch = (
            <Stopwatch startTime={values?.time} placeholder={placeholders?.time} onPause={stopwatchPause.bind(this)} disabled={disabled} showMillisec={showMillisec} />
    )
  }

  if (type & InputMode.timer) {
    timer = (
            <Timer duration={placeholders?.time} onPause={timerPause.bind(this)} onDurationChange={timerDurationChange.bind(this)} disabled={disabled} showMillisec={showMillisec} />
    )
  }

  let deleteButton
  if (solo !== true) {
    deleteButton = (
            <Button
                icon={<Image resizeMode='contain' style={Style.inputRowRemoveButtonIcon} source={require("../../../../assets/icons/action/delete.png")} />}
                type='clear' onPress={onDelete}
                buttonStyle={Style.inputRowRemoveButton}
                iconContainerStyle={Style.inputRowRemoveButtonIcon}
            />
    )
  } else {
    deleteButton = (<View style={Style.inputRowRemoveButton} />)
  }

  return (
        <View style={[Style.row, Style.inputRow]}>

            {solo !== true &&
                <Text style={[Style.exerciseCardText, Style.inputRowIndex]}>{index + 1}</Text>
            }

            <View style={Style.inputRowBlock}>
              {weightInput}
              {repsInput}
              {timer}
              {stopwatch}
            </View>

            {deleteButton}

        </View>
  )

  function stopwatchPause (ms) {
    updateTime(ms)
  }

  function timerPause (ms) {
    console.log(`timer pause: ${ms}`)
    updateTime(null, ms)
  }

  function timerDurationChange (ms) {
    updateTime(ms)
  }

  function updateTime (msTime, msElapsed) {
    let t = msTime ?? time
    if (!Number.isInteger(t)) t = null
    setTime(t)

    let e = msElapsed ?? elapsed
    if (!Number.isInteger(e)) e = null
    setElapsed(e)

    update(t, e)
  }

  function update (time, elapsed) {
    const t = Number.isInteger(time) ? time : null
    const e = Number.isInteger(elapsed) ? elapsed : null

    const data = {
      weight: weight,
      reps: reps,
      time: t,
      elapsed: e
    }

    console.log(`update: ${JSON.stringify(data)}`)

    onUpdate(data)
  }
}
