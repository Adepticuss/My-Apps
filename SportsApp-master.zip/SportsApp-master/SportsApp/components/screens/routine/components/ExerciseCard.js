import React, { useEffect, useState } from "react"
import { View, Text, FlatList, TouchableOpacity, Image } from "react-native"
import { Icon, Button, Divider } from "react-native-elements"
import * as Analytics from "expo-firebase-analytics"

import { InputMode } from "../../../constants/Input"
import Storage from "../../../controllers/Storage"
import { getExerciseImage } from "../../../controllers/ExerciseImages"
import { getWeightIcon } from "../../../controllers/Icons"

import { WeightType } from "../../../constants/Settings"
import Card from "../../../modules/basic/Cards"

import InputRow from "./InputRow"
import Style, { FrontColor, PrimaryColor, OnPrimaryColor, SecondaryColor } from "../Style"
import { FontColor } from "../../../styles/Colors"

const Legend = ({ type, onPress, weightUnit, isComplete }) => {
  let weightText, repsText, stopwatchText

  const iconStyle = [Style.legendIcon]
  let textStyle = [Style.exerciseCardText, Style.legendText]
  if (isComplete) {
    iconStyle.push({ tintColor: OnPrimaryColor })
    textStyle.push({ color: OnPrimaryColor })
  }

  if (type & InputMode.weight) {
    weightText = (
            <View style={[Style.row]}>
                <Image resizeMode='contain' style={iconStyle} source={getWeightIcon(weightUnit)} />
                <Text style={textStyle}>Weight</Text>
            </View>
    )
  }

  if (type & InputMode.count) {
    repsText = (
            <View style={[Style.row]}>
                <Image resizeMode='contain' style={iconStyle} source={require("../../../../assets/icons/exercise_types/reps.png")} />
                <Text style={textStyle}>Reps</Text>
            </View>
    )
  }

  if (type & InputMode.timer) {
    stopwatchText = (
            <View style={[Style.row]}>
                <Image resizeMode='contain' style={iconStyle} source={require("../../../../assets/icons/exercise_types/timer.png")} />
                <Text style={textStyle}>Timer</Text>
            </View>
    )
  }

  if (type & InputMode.stopwatch) {
    stopwatchText = (
            <View style={[Style.row]}>
                <Image resizeMode='contain' style={iconStyle} source={require("../../../../assets/icons/exercise_types/stopwatch.png")} />
                <Text style={textStyle}>Stopwatch</Text>
            </View>
    )
  }

  textStyle = [Style.exerciseCardText, Style.setsPlusButtonText]
  if (isComplete) {
    textStyle.push({ color: FontColor.onPrimary })
  }

  return (
        <View>
          <Button title='+ Add set' type='clear' onPress={onPress} titleStyle={textStyle} buttonStyle={Style.setsPlusButton} />
          <View style={[Style.legend]}>
            {weightText}
            {repsText}
            {stopwatchText}
          </View>
        </View>

  )
}

export default function ExerciseCard ({ exercise, routineId, disabled, weightUnit, showMillisec, autoCollapse, onUpdate, infoClick, historyClick }) {
  const [collapse, setCollapse] = useState(false)
  const [sets, setSets] = useState([{}])
  const [lastResults, setLastResults] = useState()
  const [completeCount, setCompleteCount] = useState()

  useEffect(() => {
    if (!routineId && !exercise?.id) return

    Storage.lastResult.get(routineId, exercise?.id, res => {
      const oldVal = normalizeLastResults(JSON.parse(res))
      setLastResults(oldVal)
    })
  }, [exercise, routineId])

  useEffect(() => {
    setCollapse(disabled)
  }, [disabled])

  useEffect(() => {
    if (!lastResults) return
    while (lastResults.length > sets.length) {
      sets.push({})
    }

    setSets([...sets])
  }, [lastResults])

  useEffect(() => {
    if (typeof onUpdate !== "function") return
    const completeCount = getCompleteSetsCount(sets, exercise?.type)
    setCompleteCount(completeCount)

    const complete = completeCount === sets.length
    onUpdate(sets, complete, lastResults)

    if (complete) {
      const type = exercise?.type
      Analytics.logEvent("ExerciseComplete", { type: type + "", sets: sets?.length + "" })

      if (autoCollapse &&
                type !== InputMode.stopwatch &&
                type !== InputMode.timer) {
        setCollapse(true)
      }
    }
  }, [sets])

  const cardComplete = completeCount === sets.length

  const iconStyle = [Style.infoButtonIcon]
  const textStyle = [Style.exerciseCardText, Style.titleText]
  if (cardComplete) {
    iconStyle.push({ tintColor: OnPrimaryColor })
    textStyle.push({ color: OnPrimaryColor })
  }
  const header = (
        <View>
            <View style={[Style.row, Style.titleRow]}>
                <Image resizeMode='contain' style={Style.exerciseIcon} source={getExerciseImage(exercise?.id, exercise?.custom)} />
                <Text style={textStyle}>{exercise?.name}</Text>

                {exercise?.custom !== true
                  ? <Button
                    icon={<Image resizeMode='contain' style={iconStyle} source={require("../../../../assets/icons/action/info.png")} />}
                    type='clear'
                    onPress={infoClick}
                    buttonStyle={Style.infoButton} />
                  : null}

                <Button
                    icon={<Image resizeMode='contain' style={iconStyle} source={require("../../../../assets/icons/menu_bar/history.png")} />}
                    type='clear'
                    onPress={historyClick}
                    style={Style.infoButton} />
            </View>
            <Divider />
        </View>

  )

  let progressInfo
  if (!disabled) {
    const textStyle = [Style.exerciseCardText]
    if (cardComplete) {
      textStyle.push({ color: OnPrimaryColor })
    }

    progressInfo = (
            <View style={Style.flex}>
                <Text style={textStyle}>{completeCount}/{sets.length}</Text>
            </View>
    )
  } else if (!collapse) {
    progressInfo = <View style={Style.flex} />
  } else {
    const type = exercise?.type
    let weightIcon, repsIcon, stopwatchIcon

    if (type & InputMode.weight) {
      weightIcon = <Image resizeMode='contain' style={Style.legendIcon} source={getWeightIcon(weightUnit)} />
    }

    if (type & InputMode.count) {
      repsIcon = <Image resizeMode='contain' style={Style.legendIcon} source={require("../../../../assets/icons/exercise_types/reps.png")} />
    }

    if (type & InputMode.timer) {
      stopwatchIcon = <Image resizeMode='contain' style={Style.legendIcon} source={require("../../../../assets/icons/exercise_types/timer.png")} />
    }

    if (type & InputMode.stopwatch) {
      stopwatchIcon = <Image resizeMode='contain' style={Style.legendIcon} source={require("../../../../assets/icons/exercise_types/stopwatch.png")} />
    }

    progressInfo = (
            <View style={[Style.flex, Style.row]}>
                <Text style={Style.exerciseCardText}>{sets.length} sets</Text>
                {weightIcon}
                {repsIcon}
                {stopwatchIcon}
            </View>
    )
  }

  const contentColor = cardComplete ? OnPrimaryColor : PrimaryColor
  let content
  if (!collapse) {
    content = (
            <View>
                {header}

                <Legend type={exercise?.type} onPress={addSet.bind(this)} weightUnit={weightUnit} isComplete={cardComplete} />

                <FlatList data={sets}
                            renderItem={({ item, index }) => (
                                <InputRow index={index} disabled={disabled} showMillisec={showMillisec}
                                            values={item} placeholders={getPlaceholder(index)}
                                            solo={sets?.length === 1} type={exercise?.type}
                                            onUpdate={(val) => { sets[index] = val; setSets([...sets]) }}
                                            onDelete={() => { removeSet(index) }} />
                            )}
                            keyExtractor={(_, i) => `input_row-${i}`}
                            style={Style.inputRowList} />

                <View style={[Style.row, Style.cardEnd]}>
                    <View style={Style.flex} />

                    <TouchableOpacity style={Style.flex} onPress={collapseSwitch.bind(this)}>
                      <Image resizeMode='contain' style={[Style.chevronIcon, { tintColor: contentColor }]} source={require("../../../../assets/icons/action/chevron_up.png")}/>
                    </TouchableOpacity>

                    <View style={Style.flex} />
                </View>

            </View>
    )
  } else {
    content = (
            <View>
                {header}

                <View style={[Style.row, Style.cardEnd]}>
                    {progressInfo}

                    <TouchableOpacity style={Style.flex} onPress={collapseSwitch.bind(this)}>
                      <Image resizeMode='contain' style={[Style.chevronIcon, { tintColor: contentColor }]} source={require("../../../../assets/icons/action/chevron.png")}/>
                    </TouchableOpacity>

                    <View style={Style.flex} />
                </View>
            </View>
    )
  }

  return (
        <Card content={content} style={getCardStyle()} />
  )

  function collapseSwitch () {
    if (collapse && disabled) {
      Analytics.logEvent("ExpandExercise", { type: exercise?.type, sets: sets?.length })
    }

    setCollapse(!collapse)
  }

  function getCardStyle () {
    const style = [Style.exerciseCard]

    if (completeCount === sets.length) {
      style.push(Style.exerciseCardComplete)
    } else if (completeCount > 0) {
      style.push(Style.exerciseCardIncomplete)
    }

    return style
  }

  function addSet () {
    setSets([...sets, {}])
  }

  function normalizeLastResults (data) {
    data?.forEach(x => {
      if (x.count) {
        x.reps = x.count
        delete x.count
      }
    })

    return data
  }

  function getPlaceholder (index) {
    if (!lastResults?.length || lastResults.length <= index) return
    return lastResults[index]
  }

  function getCompleteSetsCount (sets, type) {
    if (!sets?.length) return 0

    let count = 0

    for (let i = 0; i < sets.length; i++) {
      const item = sets[i]

      if ((type & InputMode.count) && (type & InputMode.weight)) {
        if (item?.weight && item?.reps) {
          count++
        }
      } else if (type & InputMode.count) {
        if (item?.reps) {
          count++
        }
      } else if (type & InputMode.weight) {
        if (item?.weight) {
          count++
        }
      } else if (type & InputMode.timer) {
        if (item?.time && item.elapsed === 0) {
          count++
        }
      } else if (type & InputMode.stopwatch) {
        if (item?.time) {
          count++
        }
      } else {
        continue
      }
    }

    return count
  }

  function removeSet (index) {
    if (sets.length <= 1) return

    sets.splice(index, 1)
    setSets([...sets])
  }
}
