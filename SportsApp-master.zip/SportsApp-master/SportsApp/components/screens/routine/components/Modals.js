import React, { useState, useEffect } from "react"
import { View, Text, Dimensions, Platform, Modal, StyleSheet } from "react-native"
import PropTypes from "prop-types"
import ConfettiCannon from "react-native-confetti-cannon"
import { Button, Icon, Overlay } from "react-native-elements"
import { BottomSheetModal, BottomSheetModalProvider } from "@gorhom/bottom-sheet"

import Storage from "../../../controllers/Storage"
import { fastSplit } from "../../../controllers/History"
import { getExercise } from "../../../controllers/ExerciseData"
import BottomSheet, { CustomBottomSheetModal } from "../../../modules/BottomSheet"
import { TextButton } from "../../../modules/Buttons"

import { DetailsCard, History } from "../../exerciseDetails/components/DetailsCard"
import WorkoutDetails from "../../../modules/WorkoutDetails"
import Colors from "../../../styles/Colors"
import NumberInput from "./NumberInput"

import Style from "../Style"
import KeyboardSpacer from "react-native-keyboard-spacer"

const ExerciseModal = ({ visible, close, exerciseId }) => {
  if (typeof exerciseId === "undefined") {
    return <View/>
  }

  const renderContent = () => {
    return (
      <View style={Style.exerciseDetails}>
        <DetailsCard id={exerciseId} isModal={true} />
      </View>

    )
  }

  return (
        <CustomBottomSheetModal show={visible}
            onClose={close}
            renderContent={renderContent}
            size={"80%"}
        />
  )
}

ExerciseModal.propTypes = {
  visible: PropTypes.bool,
  close: PropTypes.func
}

const StopwatchModal = ({ visible, close, time, updateTime }) => {
  const [minutes, setMinutes] = useState()
  const [seconds, setSeconds] = useState()

  useEffect(() => {

  }, [visible])

  useEffect(() => {
    if (!time) return

    const s = parseInt((time ?? 0) / 1000)
    const m = parseInt(s / 60)

    setMinutes(m + "")
    setSeconds((s % 60) + "")
  }, [time])

  const renderContent = () => {
    return (
      <View style={Style.stopwatchBlock}>
          <View style={Style.stopwatchInputRow}>
              <NumberInput value={minutes} placeholder='Minutes' onUpdate={(val) => { setMinutes(val) }} style={[Style.flex, Style.stopwatchInput]} />
              <NumberInput value={seconds} placeholder='Seconds' onUpdate={(val) => { setSeconds(val) }} style={[Style.flex, Style.stopwatchInput]} />
          </View>

          <View style={Style.stopwatchSaveRow}>
              <TextButton text='Save' onPress={closeClick.bind(this)} />
          </View>

          <KeyboardSpacer />
      </View>
    )
  }

  return (
      <CustomBottomSheetModal show={visible}
                  onClose={closeClick}
                  renderContent={renderContent}
                  size={500}
      />

  )

  function closeClick () {
    const lm = !minutes ? 0 : minutes
    const ls = !seconds ? 0 : seconds

    const m = parseInt(lm * 60)
    const s = m + parseInt(ls)
    const ms = s * 1000

    if (close) close()
    if (updateTime) updateTime(ms)
  }
}

StopwatchModal.propTypes = {
  visible: PropTypes.bool,
  close: PropTypes.func,
  time: PropTypes.number,
  updateTime: PropTypes.func
}

const HistoryModal = ({ visible, close, exerciseId }) => {
  const [exercise, setExercise] = useState()
  const [keys, setKeys] = useState([])

  useEffect(() => {
    setExercise(getExercise(exerciseId))
  }, [exerciseId])

  useEffect(() => {
    if (!exercise?.id) return
    loadHistory()
  }, [exercise])

  if (typeof exerciseId === "undefined") {
    return <View/>
  }

  const renderContent = () => {
    return (
      <View style={Style.exerciseDetails}>
        <History keys={keys} name={exercise?.name} />
      </View>
    )
  }

  return (
      <CustomBottomSheetModal show={visible}
                    onClose={close}
                    renderContent={renderContent}
                    size={"80%"}
      />

  )

  function loadHistory () {
    if (!exercise?.id) return

    Storage.history.getAll((k) => {
      const item = {}
      k.forEach(x => {
        const split = fastSplit(x)
        if (!split || split.exercise !== exercise.id) return

        if (!item[split.date]) item[split.date] = []
        item[split.date].push(x)
      })

      if (Object.keys(item).length === 0) {
        setKeys([])
        return
      }

      setKeys([item])
    })
  }
}

HistoryModal.propTypes = {
  visible: PropTypes.bool,
  close: PropTypes.func,
  exerciseId: PropTypes.string
}

const OverviewModal = ({ data, close, visible, duration, id }) => {
  const [noteSaved, setNoteSaved] = useState(false)

  const testData = {
    cb955f00: [{ weight: "50", reps: "15", time: null, elapsed: null }, { weight: "50", reps: "15", time: null, elapsed: null }],
    "3f012fca": [{ weight: "40", reps: "10", time: null, elapsed: null }],
    cb6b813c: [{ reps: "20", time: null, elapsed: null }, { reps: "20", time: null, elapsed: null }]
  }

  const renderContent = () => {
    return (
      <View style={Style.exerciseDetails}>
        <WorkoutDetails data={data} duration={duration} onAddClick={addNote.bind(this)} noteSaved={noteSaved} />
      </View>

    )
  }

  return (
    <View>
      <CustomBottomSheetModal show={visible}
                    onClose={close}
                    renderContent={renderContent}
                    size={"80%"}
      />
      <ConfettiCannon explosionSpeed={500} fallSpeed={1000} count={33}
                      origin={{ x: Dimensions.get("window").width / 2, y: Dimensions.get("window").height }}
                      colors={[Colors.blue, Colors.deepBlue, Colors.yellow, Colors.pink, Colors.brightGreen]}
                      fadeOut={true} autoStart={true}
      />
    </View>
  )

  return (
        <Overlay onBackdropPress={close.bind(this)}
                    isVisible={visible}
                    overlayStyle={Style.overlayBig}>
            <View style={Style.flex}>
                <Button title="X" type="clear" titleStyle={Style.blackText} onPress={close} />

            </View>
        </Overlay>
  )

  function addNote (text) {
    if (!text) return

    Storage.note.set(id, text)
    setNoteSaved(true)
  }
}

OverviewModal.propTypes = {
  data: PropTypes.object,
  close: PropTypes.func,
  visible: PropTypes.bool,
  duration: PropTypes.number,
  id: PropTypes.string
}

export { ExerciseModal, StopwatchModal, HistoryModal, OverviewModal }
