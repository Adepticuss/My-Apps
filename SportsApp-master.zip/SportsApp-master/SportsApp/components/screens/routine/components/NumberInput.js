import React from "react"
import { TextInput } from "react-native"
import PropTypes from "prop-types"

import Style from "../Style"

function NumberInput ({ value, disabled, placeholder, onUpdate, style, onEndEditing }) {
  let s = [Style.numberInput]
  if (style) s = [...s, ...style]

  return (
        <TextInput style={s}
                    value={value}
                    editable={!disabled}
                    placeholder={placeholder}
                    keyboardType='numeric'
                    returnKeyType='done'
                    onEndEditing={onEndEditing}
                    maxLength={6}
                    onChangeText={(val) => { updateInput(val) }} />
  )

  function updateInput (val) {
    let newText = ""
    const allowedSymbols = "0123456789.,"

    for (let i = 0; i < val.length; i++) {
      const symbol = val[i]
      if (allowedSymbols.indexOf(symbol) > -1) {
        newText = newText + symbol
      } else {
        // do nothing
      }
    }

    if (newText.length > 1) {
      newText = trim(newText, "0")
    } else if (newText.length === 0) {
      newText = ""
    }

    onUpdate(newText)
  }

  function trim (s, c) {
    if (c === "]") c = "\\]"
    if (c === "\\") c = "\\\\"
    return s.replace(new RegExp(
      "^[" + c + "]+|$", "g"
    ), "")
  }
}

NumberInput.propTypes = {
  value: PropTypes.string,
  disabled: PropTypes.bool,
  placeholder: PropTypes.string,
  onUpdate: PropTypes.func,
  style: PropTypes.array,
  onEndEditing: PropTypes.func
}

export default NumberInput
