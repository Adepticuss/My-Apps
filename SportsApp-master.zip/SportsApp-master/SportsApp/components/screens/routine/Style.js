import { StyleSheet } from "react-native"
import Colors, { FontColor, Theme } from "../../styles/Colors"

const margin = 20
const _borderRadius = 28

export const BackColor = "#ffffffcc"
export const FrontColor = "#000000cc"
export const PrimaryColor = Theme.primary
export const OnPrimaryColor = FontColor.onPrimary
export const SecondaryColor = Theme.secondary

export default StyleSheet.create({
  ads: {
    alignSelf: "center",
    backgroundColor: "red",
    height: 50,
    width: 320
  },
  adsLarge: {
    height: 100
  },
  adsSmart: {
    height: 50,
    width: "100%"
  },
  blackText: {
    color: "black"
  },
  buttonBack: {
    backgroundColor: Colors.grey
  },
  buttonNext: {
    backgroundColor: Colors.blue
  },
  buttonNextText: {
    color: "black"
  },
  cardCloseButton: {
    alignSelf: "center",
    backgroundColor: "white",
    borderRadius: 8,
    height: 36,
    marginBottom: -8,
    padding: 8,
    width: "50%"
  },
  cardEnd: {
    marginTop: 8
  },
  center: {
    alignItems: "center",
    height: 36,
    justifyContent: "center"
  },
  chevronIcon: {
    alignSelf: "center",
    height: 20,
    width: 20
  },
  container: {
    backgroundColor: Theme.surface,
    flex: 1
  },
  editButton: {
    alignItems: "center",
    flexDirection: "row",
    padding: 12
  },
  exerciseCard: {
    backgroundColor: Theme.surface,
    marginHorizontal: margin,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  exerciseCardComplete: {
    backgroundColor: Colors.blue
  },
  exerciseCardIncomplete: {
    borderColor: Theme.secondary,
    borderWidth: 2
  },
  exerciseCardText: {
    color: FrontColor,
    fontSize: 18
  },
  exerciseDetails: {
    backgroundColor: "white",
    height: "100%",
    paddingBottom: 16
  },
  exerciseIcon: {
    borderRadius: 16,
    height: 43,
    margin: 4,
    width: 43
  },
  finishButton: {
    backgroundColor: Theme.secondary,
    borderWidth: 0
  },
  flex: {
    flex: 1
  },
  footerBlock: {
    backgroundColor: Theme.surface,
    height: 90,
    paddingBottom: 8,
    paddingTop: 8
  },
  headerRightIcon: {
    height: 14,
    marginLeft: 4,
    width: 14
  },
  headerRightText: {
    color: FontColor.onBackground,
    fontSize: 18,
    fontWeight: "400"
  },
  help: {
    backgroundColor: "white",
    borderColor: Colors.blue,
    borderWidth: 1
  },
  helpText: {
    color: FontColor.onBackground,
    fontSize: 16
  },
  helpTextBlock: {
    flex: 1,
    justifyContent: "space-between",
    paddingVertical: 8
  },
  helpTextTitle: {
    fontSize: 28,
    fontWeight: "500",
    marginBottom: 8,
    marginTop: 4
  },
  infoButton: {
    padding: 0
  },
  infoButtonIcon: {
    height: 24,
    padding: 0,
    width: 24
  },
  inputRow: {
    alignItems: "center",
    marginVertical: 4
  },
  inputRowBlock: {
    backgroundColor: Theme.background,
    borderRadius: 16,
    flex: 1,
    flexDirection: "row",
    padding: 8,
    paddingHorizontal: 4
  },
  inputRowIndex: {
    alignSelf: "center",
    textAlign: "center",
    width: 42
  },
  inputRowList: {
    marginVertical: 8
  },
  inputRowRemoveButton: {
    backgroundColor: "#00000000"
  },
  inputRowRemoveButtonIcon: {
    height: 18,
    width: 18
  },
  legend: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-around"
  },
  legendIcon: {
    alignSelf: "center",
    height: 24,
    marginHorizontal: 4,
    width: 24
  },
  legendText: {
    alignSelf: "center",
    textAlign: "center"
  },
  modalBack: {
    backgroundColor: Colors.alpha.heavy,
    flex: 1,
    padding: 16,
    paddingTop: 48
  },
  modalCloseButton: {
    backgroundColor: "white",
    elevation: 0,
    height: 36,
    padding: 8,
    position: "absolute",
    top: 0
  },
  modalHistory: {
    backgroundColor: "white",
    borderRadius: 12,
    flex: 1
  },
  numberInput: {
    backgroundColor: Colors.silver,
    borderRadius: 8,
    fontSize: 20,
    padding: 12
  },
  overlay: {
    height: "auto",
    width: "70%"
  },
  overlayBig: {
    flex: 1,
    marginVertical: 32,
    width: "85%"
  },
  overlayBottomSheet: {
    backgroundColor: "rgba(0,0,0,0)",
    flex: 1,
    width: "100%"
  },
  row: {
    alignItems: "center",
    flexDirection: "row"
  },
  rowInput: {
    backgroundColor: Theme.surface,
    borderRadius: 10,
    flex: 1,
    marginHorizontal: 4
  },
  screenBlock: {
    backgroundColor: Theme.background,
    borderBottomLeftRadius: _borderRadius,
    borderBottomRightRadius: _borderRadius,
    flex: 1
  },
  setsPlusButton: {
    borderColor: Colors.alpha.medium,
    borderRadius: 8,
    padding: 4
  },
  setsPlusButtonText: {
    color: Theme.primary,
    fontWeight: "400"
  },
  setupText: {
    color: Colors.alpha.medium,
    fontSize: 30,
    marginVertical: 8,
    textAlign: "center"
  },
  startButton: {
    backgroundColor: Colors.blue,
    borderColor: Colors.orange,
    borderRadius: 12,
    borderTopWidth: 0,
    borderWidth: 2,
    height: 92
  },
  startButtonText: {
    fontSize: 32,
    fontStyle: "italic",
    fontWeight: "bold"
  },
  statusBar: {
    backgroundColor: "white",
    marginHorizontal: 8,
    marginTop: 8
  },
  statusBarComplete: {
    borderBottomRightRadius: 4,
    borderTopRightRadius: 4
  },
  statusBarCompleteText: {
    alignSelf: "center",
    fontSize: 16,
    paddingHorizontal: 8,
    position: "absolute",
    textAlign: "center",
    width: "100%"
  },
  statusBarProgressBlock: {
    padding: 8
  },
  statusBarStart: {
    backgroundColor: "rgba(0,0,0,0)",
    height: 80
  },
  statusBarStartBlock: {
    alignItems: "center",
    flex: 1,
    justifyContent: "center"
  },
  statusBarStartedBlock: {
    alignItems: "center",
    backgroundColor: Theme.surface,
    borderRadius: 16,
    flex: 1,
    height: 48,
    justifyContent: "center",
    marginRight: 8,
    shadowOffset: { height: 1, width: 2 },
    shadowOpacity: 0.07
  },
  statusBarStopwatch: {
    alignSelf: "center"
  },
  stopwatch: {
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center"
  },
  stopwatchBlock: {
    backgroundColor: Theme.surface,
    height: 460
  },
  stopwatchBox: {
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: 8,
    height: 120,
    justifyContent: "flex-end",
    left: "50%",
    marginLeft: -130,
    marginTop: -60,
    top: "50%",
    width: 260
  },
  stopwatchBoxText: {
    alignSelf: "center",
    paddingTop: 8,
    textAlign: "center"
  },
  stopwatchButton: {
    marginRight: 8,
    padding: 4
  },
  stopwatchButtonPlaceholder: {
    width: 32
  },
  stopwatchContainer: {
    backgroundColor: "rgba(0,0,0,0)",
    padding: 4
  },
  stopwatchEdit: {
  },
  stopwatchInput: {
    backgroundColor: Theme.surface,
    borderColor: Colors.lightGrey,
    borderRadius: 10,
    borderWidth: 1,
    marginHorizontal: 4
  },
  stopwatchInputRow: {
    backgroundColor: Theme.background,
    borderRadius: 16,
    flexDirection: "row",
    marginHorizontal: 32,
    paddingHorizontal: 4,
    paddingVertical: 8
  },
  stopwatchPlaceholder: {
    alignSelf: "center",
    color: Colors.alpha.medium,
    marginTop: -8
  },
  stopwatchSaveRow: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 16
  },
  stopwatchText: {
    color: "black",
    fontSize: 18,
    textAlign: "center"
  },
  stopwatchTextBig: {
    color: "black",
    fontSize: 26,
    textAlign: "center"
  },
  streakCurrentProgressFront: {
    backgroundColor: "#ECFBFF",
    borderRadius: 50,
    flexDirection: "row",
    height: "100%",
    width: "100%"
  },
  streakCurrentProgressFrontActive: {
    backgroundColor: Theme.primary,
    borderRadius: 50,
    flex: 0
  },
  textPrimary: {
    color: Theme.primary
  },
  textSecondary: {
    color: Theme.secondary
  },
  titleRow: {
    flex: 1
  },
  titleText: {
    alignSelf: "center",
    flex: 1
  }
})
