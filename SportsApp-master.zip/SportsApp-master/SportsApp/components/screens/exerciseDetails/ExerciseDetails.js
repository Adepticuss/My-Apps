import React, { useEffect, useState } from "react"
import { View, SafeAreaView } from "react-native"

import Storage from "../../controllers/Storage"

import ButtonGroup from "../../modules/ButtonGroup"
import { fastSplit } from "../../controllers/History"
import styles from "./Style"
import { DetailsCard, History } from "../exerciseDetails/components/DetailsCard"

const Mode = {
  info: 0,
  history: 1
}

const Buttons = ["Info", "History"]

export default function ExerciseDetails ({ navigation, route }) {
  const [exercise, setExercise] = useState({})
  const [mode, setMode] = useState(Mode.info)
  const [keys, setKeys] = useState([])

  useEffect(() => {
    loadHistory()
  }, [mode])

  useEffect(() => {
    if (exercise?.name) {
      navigation.setOptions({
        title: exercise.name
      })
    }

    loadHistory()
  }, [exercise])

  useEffect(() => {
    setExercise(route.params?.exercise)
  }, [route.params?.exercise])

  let page
  if (mode === Mode.info) {
    page = (<DetailsCard id={exercise?.id} />)
  } else if (mode === Mode.history) {
    page = (<History keys={keys} name={exercise?.name} />)
  }

  return (
        <SafeAreaView style={styles.container}>
            <ButtonGroup
              options={Buttons}
              selected={detailsModeToIndex(mode)}
              onChange={x => setMode(indexToDetailsMode(x))}
            />

            <View style={styles.container}>
                {page}
            </View>

        </SafeAreaView>

  )

  function detailsModeToIndex (mode) {
    if (mode === Mode.info) {
      return 0
    } else if (mode === Mode.history) {
      return 1
    }
  }

  function indexToDetailsMode (index) {
    if (index === 0) {
      return Mode.info
    } else if (index === 1) {
      return Mode.history
    }
  }

  function loadHistory () {
    if (!exercise?.id) return

    Storage.history.getAll((k) => {
      const item = {}
      k.forEach(x => {
        const split = fastSplit(x)
        if (!split || split.exercise !== exercise.id) return

        if (!item[split.date]) item[split.date] = []
        item[split.date].push(x)
      })

      if (Object.keys(item).length === 0) {
        setKeys([])
        return
      }

      setKeys([item])
    })
  }
}
