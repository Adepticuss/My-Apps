import React, { useEffect, useState } from "react"
import { View, Text, Image, ScrollView, FlatList } from "react-native"
import Carousel, { Pagination } from "react-native-snap-carousel"
import * as Analytics from "expo-firebase-analytics"
import { BottomSheetView } from "@gorhom/bottom-sheet"

import { getExercise } from "../../../controllers/ExerciseData"
import Images from "../../../controllers/ExerciseImages"
import { HistoryMode } from "../../../controllers/History"
import HistoryCard from "../../history/components/Card"
import styles from "../Style"
import { LinkButton, VideoButton } from "./Buttons"
import Description from "./DescriptionText"

export function History ({ keys, name }) {
  if (keys.length <= 0) {
    return (<Text style={styles.emptyHistory}>no history</Text>)
  }

  return (
        <FlatList data={keys}
                  renderItem={({ item }) => <HistoryCard item={{ key: name, item: item }} mode={HistoryMode.exercise} expanded={true} />}
                  keyExtractor={(_, i) => i + ""}
                  style={styles.historyList} />
  )
}

const Picture = ({ image }) => {
  return (
        <Image style={styles.exerciseImage} imageStyle={styles.exerciseImage} source={image} />
  )
}

export function DetailsCard ({ id, isModal }) {
  const [exercise, setExercise] = useState({})
  const [images, setImages] = useState([])
  const [activeIndex, setActiveIndex] = useState(0)

  useEffect(() => {
    setExercise(getExercise(id))
  }, [id])

  useEffect(() => {
    if (Images[exercise?.id]) setImages(Images[exercise.id])

    if (exercise?.name) {
      Analytics.logEvent("ExerciseDetailsCard", { name: exercise.name, id: exercise.id })
    }
  }, [exercise])

  let videoButton, linkButton

  if (exercise?.url) {
    videoButton = <VideoButton url={exercise.url}/>
  }

  if (exercise?.link) {
    linkButton = <LinkButton url={exercise.link}/>
  }

  let pictures
  if (images?.length > 0) {
    pictures = (
            <View style={styles.pictures}>
                <Carousel
                    data={images}
                    renderItem={({ item }) => <Picture image={item} />}
                    onSnapToItem={(index) => setActiveIndex(index) }
                    sliderWidth={400}
                    itemWidth={300}
                    />

                <Pagination
                    style={styles.pagination}
                    activeDotIndex={activeIndex}
                    dotsLength={images.length}
                    containerStyle={styles.pagination}
                    />
            </View>
    )
  }

  return (
        <View style={styles.container}>

            {pictures}

            <View style={styles.info}>

                <View style={styles.flex}>
                  <Description text={exercise?.description} isModal={isModal} />
                </View>

                <View style={styles.linkButtonBlock}>
                  {linkButton}
                </View>

            </View>

        </View>
  )
}
