
import { Linking } from "react-native"
import React, { useCallback } from "react"

import styles from "../Style"
import { Button } from "react-native-elements"
import { OutlineTextButton } from "../../../modules/Buttons"

async function openURL (url) {
  if (!url) return

  // Checking if the link is supported for links with custom URL scheme.
  const supported = await Linking.canOpenURL(url)

  if (supported) {
    // Opening the link with some app, if the URL scheme is "http" the web link should be opened
    // by some browser in the mobile
    await Linking.openURL(url)
  }
}

export function VideoButton ({ url }) {
  const openVideo = useCallback(async () => {
    openURL(url)
  }, [url])

  return (
        <Button title='Video' buttonStyle={ styles.videoButton} containerStyle={styles.buttons} onPress={openVideo}/>
  )
}

export function LinkButton ({ url }) {
  const openLink = useCallback(async () => {
    openURL(url)
  }, [url])

  return (
        <OutlineTextButton text='Link to the source' onPress={openLink}/>
  )
}
