import React, { useState, useEffect } from "react"
import { View, Text, FlatList, ImageBackground } from "react-native"
import DashedLine from "react-native-dashed-line"
import { BottomSheetFlatList } from "@gorhom/bottom-sheet"

import Style, { PrimaryColor } from "../Style"

const TextBlock = ({ text, isLast }) => {
  const [description, setDescription] = useState()
  const [index, setIndex] = useState()

  useEffect(() => {
    if (typeof text !== "string") return
    const dotIndex = text.indexOf(". ")
    if (dotIndex === -1) return

    setIndex(text.substring(0, dotIndex))
    setDescription(text.substring(dotIndex + 2))
  }, [text])

  return (
        <View style={Style.descriptionBlock}>
            <View style={Style.descriptionIndexBlock}>
                <ImageBackground resizeMode='contain' style={Style.descriptionIndexHex} source={require("../../../../assets/icons/home/polygon.png")}>
                    <Text style={Style.descriptionIndexText}>{index}</Text>
                </ImageBackground>
                {isLast ? null : <DashedLine axis='vertical' dashLength={6} style={Style.descriptionIndexDashedLine} dashColor={PrimaryColor} />}

            </View>
            <View style={Style.descriptionTextBlock}>
                <Text style={Style.description}>{description}</Text>
            </View>
        </View>
  )
}

export default function DescriptionText ({ text, isModal }) {
  const [textRows, setTextRows] = useState([])

  useEffect(() => {
    setTextRows(formatText(text))
  }, [text])

  console.log("is modal:" + isModal)
  if (isModal === true) {
    return (<BottomSheetFlatList
            data={textRows}
            style={Style.flex}
            renderItem={({ item, index }) => (<TextBlock text={item} isLast={(index + 1) === textRows.length} />)}
            keyExtractor={(_, index) => `textBlock-${index}`}
        />)
  }

  return (
        <FlatList
            data={textRows}
            style={Style.flex}
            renderItem={({ item, index }) => (<TextBlock text={item} isLast={(index + 1) === textRows.length} />)}
            keyExtractor={(_, index) => `textBlock-${index}`}
        />
  )

  function formatText (text) {
    return text?.split("\n\n") ?? []
  }
}
