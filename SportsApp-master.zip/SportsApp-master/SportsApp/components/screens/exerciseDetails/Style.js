import { StyleSheet } from "react-native"
import Colors, { FontColor, Theme } from "../../styles/Colors"

export const PrimaryColor = Theme.primary

export default StyleSheet.create({
  buttonGroup: {
    borderRadius: 15,
    height: 60
  },
  buttons: {
    flex: 1,
    marginHorizontal: 6,
    paddingVertical: 8

  },
  container: {
    backgroundColor: Theme.background,
    flex: 1
  },
  description: {
    flex: 1,
    fontSize: 16
  },
  descriptionBlock: {
    alignItems: "center",
    flex: 1,
    flexDirection: "row"
  },
  descriptionIndexBlock: {
    alignItems: "center",
    height: "100%",
    justifyContent: "flex-start",
    width: 42
  },
  descriptionIndexDashedLine: {
    flex: 1
  },
  descriptionIndexHex: {
    alignItems: "center",
    height: 32,
    justifyContent: "center",
    marginBottom: 2,
    width: 32
  },
  descriptionIndexText: {
    color: FontColor.onPrimary
  },
  descriptionTextBlock: {
    flex: 1,
    paddingBottom: 8,
    paddingTop: 4
  },
  emptyHistory: {
    fontSize: 18,
    margin: 12
  },
  exerciseImage: {
    flex: 1,
    resizeMode: "contain",
    width: "100%"

  },
  flex: {
    flex: 1
  },
  high: {
    height: 300,
    margin: 32
  },
  historyList: {
    margin: 8
  },
  info: {
    flex: 1.5,
    padding: 16
  },
  linkButton: {
    alignSelf: "center",
    borderColor: "deepskyblue",
    width: "60%"
  },
  linkButtonBlock: {
    alignItems: "center",
    marginTop: 8
  },
  links: {
    flexDirection: "row"
    // borderWidth: 4,
    // borderColor: "#20232a",
    // borderRadius: 6,
  },
  muscle: {
    paddingTop: 8

  },
  page: {
    backgroundColor: Colors.lightRed,
    flexDirection: "column",
    height: 300
  },
  pagination: {
    bottom: 0,
    marginBottom: -16,
    position: "absolute"
  },
  pictures: {
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: 16,
    flex: 1,
    justifyContent: "center",
    marginHorizontal: 12,
    overflow: "hidden"
  },
  selectedButton: {
    backgroundColor: Colors.blue,
    borderRadius: 15,
    margin: 8
  },
  selectedText: {
    fontSize: 15
  },
  textStyle: {
    fontSize: 15
  },
  videoButton: {
    backgroundColor: Colors.lightRed
  }
})
