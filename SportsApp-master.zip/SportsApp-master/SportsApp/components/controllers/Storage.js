import AsyncStorage from "@react-native-async-storage/async-storage"
import * as Sentry from "sentry-expo"

const _routine = "routine"
const _exercise = "exercise"
const _history = "history"
const _workout = "workout"
const _noworkout = "noworkout"
const _settings = "settings"
const _lastResult = "lastresult"
const _note = "note"
const _streak = "streak"
const _lastWorkout = "lastworkout"
const _goal = "goal"

export const Consts = {
  routine: _routine,
  exercise: _exercise,
  history: _history,
  workout: _workout,
  noWorkout: _noworkout,
  settings: _settings,
  note: _note,
  streak: _streak,
  lastWorkout: _lastWorkout,
  goal: _goal
}

const Storage = {
  item: {
    get: (key, cb) => {
      AsyncStorage.getItem(key, (err, res) => {
        if (err) {
          cb(null, err)
          Sentry.Native.captureException(err)
          return
        }

        cb(res)
      })
    },
    remove: (key, cb) => {
      AsyncStorage.removeItem(key, cb)
    }
  },
  exercise: {
    getAll: (cb) => {
      AsyncStorage.getAllKeys((err, keys) => {
        if (err) {
          return
        }

        const exerciseKeys = keys.filter(x => x?.startsWith(_exercise))
        cb(exerciseKeys)
      })
    },
    get: (id, cb) => {
      AsyncStorage.getItem(_exercise + ":" + id, (err, res) => {
        if (err) {
          cb(null, err)
        }

        cb(res)
      })
    },
    set: (id, val) => {
      AsyncStorage.setItem(_exercise + ":" + id, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  },
  settings: {
    get: (cb) => {
      AsyncStorage.getItem(_settings, (err, res) => {
        if (err) {
          cb(null, err)
        }

        cb(res)
      })
    },
    set: (val) => {
      AsyncStorage.setItem(_settings, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  },
  routine: {
    get: (id, cb) => {
      AsyncStorage.getItem(_routine + ":" + id, (err, res) => {
        if (!err) {
          cb(res)
        }
      })
    },
    getAll: (cb) => {
      AsyncStorage.getAllKeys((err, keys) => {
        if (err) {
          return
        }

        const routineKeys = keys.filter(x => x?.startsWith(_routine))
        cb(routineKeys)
      })
    },
    set: (val) => {
      AsyncStorage.setItem(_routine + ":" + val.id, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    },
    delete: (id) => {
      AsyncStorage.removeItem(_routine + ":" + id, (error) => { if (error) { alert("error:" + error) } })
    }
  },
  history: {
    clear: (cb) => {
      Storage.history.getAll((keys) => {
        keys.forEach(key => AsyncStorage.removeItem(key))
        cb()
      })
    },
    getAll: (cb) => {
      AsyncStorage.getAllKeys((err, keys) => {
        if (err) {
          Sentry.Native.captureException(err)
          return
        }

        const historyKeys = keys.filter(x => x?.startsWith(_history))
        cb(historyKeys)
      })
    },
    set: (workoutId, exerciseId, data, success) => {
      if (!workoutId) workoutId = _noworkout

      const d = new Date()
      const datetext = d.getFullYear() + "-" + pad(d.getMonth() + 1, 2) + "-" + pad(d.getDate(), 2)

      const key = _history + ":" + datetext + ":" + workoutId + ":" + exerciseId
      const payload = JSON.stringify(data)

      AsyncStorage.setItem(key, payload, (error) => { if (error) { alert("error:" + error) } else if (success) { success() } })
    }
  },
  workout: {
    get: (id, cb) => {
      AsyncStorage.getItem(_workout + ":" + id, (err, res) => {
        if (!err) {
          cb(res)
        }
      })
    },
    set: (id, val) => {
      AsyncStorage.setItem(_workout + ":" + id, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  },
  lastResult: {
    get: (routineId, exerciseId, cb) => {
      AsyncStorage.getItem(_lastResult + ":" + routineId + ":" + exerciseId, (err, res) => {
        if (!err) {
          cb(res)
        }
      })
    },
    set: (routineId, exerciseId, val) => {
      AsyncStorage.setItem(_lastResult + ":" + routineId + ":" + exerciseId, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  },
  note: {
    get: (workoutId, cb) => {
      AsyncStorage.getItem(_note + ":" + workoutId, (err, res) => {
        if (!err) {
          cb(res)
        }
      })
    },
    set: (workoutId, val) => {
      AsyncStorage.setItem(_note + ":" + workoutId, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  },
  streak: {
    current: {
      get: (cb) => {
        AsyncStorage.getItem(_streak + ":current", (err, res) => {
          if (!err) {
            if (!res) {
              cb(null)
              return
            }

            const json = JSON.parse(res)
            if (!json?.id) {
              cb(null)
              return
            }

            Storage.streak.get(json.id, cb)
          }
        })
      },
      set: (val) => {
        if (!val?.id) return
        Storage.streak.set(val.id, val)
        const payload = { id: val.id }
        AsyncStorage.setItem(_streak + ":current", JSON.stringify(payload), (error) => { if (error) { alert("error:" + error) } })
      },
      clear: () => {
        AsyncStorage.setItem(_streak + ":current", JSON.stringify(null), (error) => { if (error) { alert("error:" + error) } })
      }
    },
    best: {
      get: (cb) => {
        AsyncStorage.getItem(">best:" + _streak, (err, res) => {
          if (!err) {
            cb(res)
          }
        })
      },
      set: (val) => {
        AsyncStorage.setItem(">best:" + _streak, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
      }
    },
    getAll: (cb) => {
      AsyncStorage.getAllKeys((err, keys) => {
        if (err) {
          return
        }

        const streakKeys = keys.filter(x => x?.startsWith(_streak))
        cb(streakKeys)
      })
    },
    get: (id, cb) => {
      AsyncStorage.getItem(_streak + ":" + id, (err, res) => {
        if (!err) {
          cb(res)
        }
      })
    },
    set: (id, val) => {
      AsyncStorage.setItem(_streak + ":" + id, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  },
  goal: {
    getAll: (cb) => {
      AsyncStorage.getAllKeys((err, keys) => {
        if (err) {
          return
        }

        const goalKeys = keys.filter(x => x?.startsWith(_goal))
        cb(goalKeys)
      })
    },
    get: (id, cb) => {
      AsyncStorage.getItem(_goal + ":" + id, (err, res) => {
        if (!err) {
          cb(res)
        }
      })
    },
    set: (id, val) => {
      AsyncStorage.setItem(_goal + ":" + id, JSON.stringify(val), (error) => { if (error) { alert("error:" + error) } })
    }
  }
}

export function formatDate (d) {
  return d.getFullYear() + "-" + pad(d.getMonth() + 1, 2) + "-" + pad(d.getDate(), 2)
}

function pad (n, width, z) {
  z = z || "0"
  n = n + ""
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n
}

export default Storage
