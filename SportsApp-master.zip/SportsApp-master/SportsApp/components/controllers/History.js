import Storage from "./Storage"
import { getExercise } from "./ExerciseData"

export const HistoryMode = {
  exercise: 1,
  date: 2,
  routine: 4
}

export function groupKeys (keys, mode) {
  const grouped = {}
  keys?.forEach((key) => {
    const split = fastSplit(key)

    const date = split.date
    const workout = split.workout
    const exerciseId = split.exercise

    let gKey1, gKey2
    if (mode === HistoryMode.exercise) {
      gKey1 = getExercise(exerciseId)?.name ?? exerciseId
      gKey2 = date
    } else if (mode === HistoryMode.date) {
      gKey1 = date
      gKey2 = exerciseId
    } else if (mode === HistoryMode.routine) {
      // TODO routine mode (get from storage)
      gKey1 = workout
      gKey2 = exerciseId
    } else {
      // default to exercise for now
      gKey1 = exerciseId
      gKey2 = date
    }

    if (!gKey1 || !gKey2) return

    if (!grouped[gKey1]) {
      grouped[gKey1] = {}
    }

    if (!grouped[gKey1][gKey2]) {
      grouped[gKey1][gKey2] = []
    }

    grouped[gKey1][gKey2].unshift(key)
  })

  const newHistory = []
  for (const key in grouped) {
    const item = grouped[key]
    const data = {
      key: key,
      item: item
    }

    newHistory.push(data)
  }

  newHistory.sort((a, b) => a.key < b.key)
  return newHistory
}

export function fastSplit (key) {
  const obj = {}

  // Get type
  const idxColon1 = key.indexOf(":")
  if (idxColon1 === -1) {
    return obj
  }

  obj.type = key.substring(0, idxColon1)

  // Get date
  const idxColon2 = key.indexOf(":", idxColon1 + 1)
  if (idxColon2 === -1) {
    return obj
  }

  obj.date = key.substring(idxColon1 + 1, idxColon2)

  // Get workout & exercise
  const idxColon3 = key.indexOf(":", idxColon2 + 1)
  if (idxColon3 === -1) {
    return obj
  }

  obj.workout = key.substring(idxColon2 + 1, idxColon3)
  obj.exercise = key.substring(idxColon3 + 1)

  return obj
}

export function formatMillisecond (ms) {
  if (!ms || typeof ms !== "number") return

  const seconds = parseInt(ms / 1000)
  const minutes = parseInt(seconds / 60)

  let time = seconds % 60 + "s"
  if (minutes) {
    time = minutes + "m : " + time
  }

  return time
}

export function getDateText (date) {
  if (!date) return

  return date.getFullYear() + "-" + pad(date.getMonth() + 1, 2) + "-" + pad(date.getDate(), 2)
}

export function formatDateString (dateString) {
  const split = dateString.split("-")
  const parts = {
    year: split[0],
    month: split[1],
    day: split[2]
  }

  return `${parts.day}.${parts.month}.${parts.year}`
}

export function formartExerciseName (exerciseName, callback) {
  Storage.exercise.get(exerciseName, (val, e) => {
    if (!val) {
      callback(exerciseName)
    } else {
      const j = JSON.parse(val)
      callback(j?.name)
    }
  })
}

export function formatPrimaryName (name, mode, callback) {
  if (typeof name === "undefined") return

  if (mode === HistoryMode.date) {
    callback(formatDateString(name))
  } else if (mode === HistoryMode.exercise) {
    formartExerciseName(name, callback)
  }
}

export function formatSecondaryName (name, mode, callback) {
  if (typeof name === "undefined") return

  if (mode === HistoryMode.exercise) {
    callback(formatDateString(name))
  } else if (mode === HistoryMode.date) {
    formartExerciseName(name, callback)
  }
}

export function pad (n, width, z) {
  z = z || "0"
  n = n + ""
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n
}
