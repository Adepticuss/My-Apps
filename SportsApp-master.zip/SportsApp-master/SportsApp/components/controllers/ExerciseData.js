const Exercises = require("../../assets/data/exercises.json")
const _muscles = require("../../assets/data/muscles.json")

export const Muscles = _muscles

export function getExercises (filter) {
  if (!filter) return Exercises

  const filterLow = filter.toLowerCase()
  return Exercises.filter((x) => { return x.name.toLowerCase().indexOf(filterLow) !== -1 })
}

export function getGroupedExercises () {
  const data = {}
  for (const key in Muscles) {
    if (!data[key]) data[key] = []

    const ids = Muscles[key]
    if (!(ids?.length > 0)) continue

    ids.forEach(x => {
      const exe = getExercise(x)
      if (exe) data[key].push(exe)
    })
  }

  return data
}

export function getExercise (id) {
  const e = Exercises.filter((x) => { return x.id === id })

  if (e.length > 0) return e[0]

  return null
}

export function getSuggestion (name) {
  const nameLow = name?.toLowerCase()
  const exercises = []

  if (!Muscles[nameLow]) return []

  Muscles[nameLow].forEach(x => {
    exercises.push(getExercise(x))
  })

  return exercises
}
