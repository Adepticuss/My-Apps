export const DefaultImage = require("../../assets/icons/muscles/icons-13.png")

export const Custom = require("../../assets/icons/muscles_full/Custom.png")

const _lowerBack = require("../../assets/icons/muscles_full/lower_back.png")
const _chest = require("../../assets/icons/muscles_full/Chest.png")
const _hamstrings = require("../../assets/icons/muscles_full/Hamstrings.png")
const _upperBack = require("../../assets/icons/muscles_full/upper_back.png")
const _quadriceps = require("../../assets/icons/muscles_full/quadriceps.png")

export const NewMuscles = {
  "lower back": _lowerBack,
  chest: _chest,
  hamstrings: _hamstrings,
  "upper back": _upperBack,
  quadriceps: _quadriceps,
  gluteal: require("../../assets/icons/muscles_full/gluteal.png"),
  deltoid: require("../../assets/icons/muscles_full/Deltoid.png"),
  trapezoid: require("../../assets/icons/muscles_full/Trapezoid.png"),
  biceps: require("../../assets/icons/muscles_full/Biceps.png"),
  gastro: require("../../assets/icons/muscles_full/gastro.png"),
  triceps: require("../../assets/icons/muscles_full/triceps.png"),
  core: require("../../assets/icons/muscles_full/Core.png"),
  forearms: require("../../assets/icons/muscles_full/Forearms.png")
}

export default {
  "lower back": require("../../assets/icons/muscles/icons-13.png"),
  chest: require("../../assets/icons/muscles/icons-06.png"),
  hamstrings: require("../../assets/icons/muscles/icons-15.png"),
  "upper back": require("../../assets/icons/muscles/icons-12.png"),
  quadriceps: require("../../assets/icons/muscles/icons-08.png"),
  gluteal: require("../../assets/icons/muscles/icons-14.png"),
  deltoid: require("../../assets/icons/muscles/icons-10.png"),
  trapezoid: require("../../assets/icons/muscles/icons-11.png"),
  biceps: require("../../assets/icons/muscles/icons-03.png"),
  gastro: require("../../assets/icons/muscles/icons-16.png"),
  triceps: require("../../assets/icons/muscles/icons-09.png"),
  core: require("../../assets/icons/muscles/icons-07.png"),
  forearms: require("../../assets/icons/muscles/icons-04.png")
}
