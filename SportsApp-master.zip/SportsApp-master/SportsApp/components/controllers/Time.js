export function formatMillisecond (ms) {
  if (!ms || typeof ms !== "number") return

  const seconds = parseInt(ms / 1000)
  const minutes = parseInt(seconds / 60)

  const time = `${pad(minutes, 2)}:${pad(seconds % 60, 2)}`

  return time
}

export function pad (n, width, z) {
  z = z || "0"
  n = n + ""
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n
}
