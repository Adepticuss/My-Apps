import { getExercise } from "./ExerciseData"
import { NewMuscles } from "./MuscleImages"

export function getExerciseImage (id, custom) {
  if (typeof id === "undefined") {
    return require("../../assets/icons/muscles_full/Core.png")
  }

  if (custom === true) {
    return require("../../assets/icons/muscles_full/Custom.png")
  }

  if (Images[id]) return Images[id][0]

  const exercise = getExercise(id)
  if (!exercise) return require("../../assets/icons/muscles_full/Chest.png")

  const muscle = NewMuscles[exercise.muscle[0]]
  if (muscle) return muscle

  return require("../../assets/icons/muscles_full/Chest.png")
}

const Images = {

  "0f27223f": [require("../../assets/images/Back-Extentions.png"), require("../../assets/images/Back-Extentions-2.png")],
  b8053441: [require("../../assets/images/Barbell-Hip-Thrust.png"), require("../../assets/images/Barbell-Hip-Thrust-2.png")],
  "36da4a3a": [require("../../assets/images/Barbell-Military-Press.png"), require("../../assets/images/Barbell-Military-Press-2.png")],
  dadd2dd5: [require("../../assets/images/Barbell-Squats.png"), require("../../assets/images/Barbell-Squats-2.png")],
  cb955f00: [require("../../assets/images/Bench-Press.png"), require("../../assets/images/Bench-Press-2.png")],
  "29244abb": [require("../../assets/images/Butt-Lift-Bridge.png"), require("../../assets/images/Butt-Lift-Bridge-2.png")],
  a0d9469e: [require("../../assets/images/Butterfly.png"), require("../../assets/images/Butterfly-2.png")],
  "4677418c": [require("../../assets/images/Crunches.png"), require("../../assets/images/Crunches-2.png")],
  "7c82de46": [require("../../assets/images/Deadlift.png"), require("../../assets/images/Deadlift-2.png")],
  cb6b813c: [require("../../assets/images/Dips.png"), require("../../assets/images/Dips-2.png")],
  "79e0433e": [require("../../assets/images/Dumbbell-Bench-Press.png"), require("../../assets/images/Dumbbell-Bench-Press-2.png")],
  "5345521b": [require("../../assets/images/Leg-Press.png"), require("../../assets/images/Leg-Press-2.png")],
  a62c9e5c: [require("../../assets/images/Leverage-High-Row.png"), require("../../assets/images/Leverage-High-Row-2.png")],
  "9e77584f": [require("../../assets/images/Plank.png")],
  "9d5da6fa": [require("../../assets/images/Pull-Through.png"), require("../../assets/images/Pull-Through-2.png")],
  "1c48c8f4": [require("../../assets/images/Pull-ups.png"), require("../../assets/images/Pull-ups-2.png"), require("../../assets/images/Pull-ups-3.png"), require("../../assets/images/Pull-ups-4.png"), require("../../assets/images/Pull-ups-5.png")],
  ded6b02b: [require("../../assets/images/Pushups.png"), require("../../assets/images/Pushups-2.png")],
  c06ad2f0: [require("../../assets/images/Seated-Horizontal-Cable-Row.png"), require("../../assets/images/Seated-Horizontal-Cable-Row-2.png")],
  ee73b119: [require("../../assets/images/Shrugs.png"), require("../../assets/images/Shrugs-2.png")],
  af914c24: [require("../../assets/images/Standing-Calf-Raise.png"), require("../../assets/images/Standing-Calf-Raise.png")]

}

export default Images
