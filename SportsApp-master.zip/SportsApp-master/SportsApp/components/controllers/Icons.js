import { WeightType } from "../constants/Settings"
import Images from "./ExerciseImages"

export function getWeightIcon (weightUnit) {
  if (weightUnit === WeightType.kg) {
    return require("../../assets/icons/exercise_types/weight_kg.png")
  } else if (weightUnit === WeightType.lb) {
    return require("../../assets/icons/exercise_types/weight_lb.png")
  } else {
    return require("../../assets/icons/exercise_types/weight.png")
  }
}

export function getExerciseImage (id) {
  if (typeof id === "undefined") {
    return require("../../assets/icons/muscles_full/Core.png")
  }

  if (Images[id]) return Images[id][0]

  return require("../../assets/icons/muscles_full/Chest.png")
}
