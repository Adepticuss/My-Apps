import { Alert } from "react-native"

export function confirmationDialog (title, text, yesFunc, noFunc) {
  Alert.alert(
    title,
    text,
    [
      {
        text: "No",
        style: "cancel",
        onPress: noFunc
      },
      {
        text: "Yes",
        onPress: yesFunc
      }
    ]
  )
}
