package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.CaseMap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Calculate extends AppCompatActivity {

    public TextView property;
    public TextView income;
    public TextView job;
    public TextView other;
    public TextView Expenses;
    public TextView grocery;
    public TextView utility;
    public TextView vehicle;
    public TextView otherExp;
    public TextView Description;
    public TextView title;
    public TextView rate;
    public TextView name;

    public EditText txtincome;
    public EditText txtOther;
    public EditText txtExpenses;
    public EditText txtGrocery;
    public EditText txtUtility;
    public EditText txtVehicle;
    public EditText txtOtherExp;
    public EditText txtRate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculate);

        income = findViewById(R.id.income);
        other = findViewById(R.id.other);
        job= findViewById(R.id.job);
        Expenses = findViewById(R.id.Expenses);
        property = findViewById(R.id.property);
        grocery = findViewById(R.id.grocery);
        utility = findViewById(R.id.utility);
        vehicle = findViewById(R.id.vehicle);
        otherExp = findViewById(R.id.otherExp);
        Description = findViewById(R.id.Description);
        title = findViewById(R.id.Title);
        rate = findViewById(R.id.rate);

        title.setText("Personal Assistant ");
        Button btnCalculate = findViewById(R.id.button_Calculate);
        btnCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtincome = findViewById(R.id.txtIncome);
                txtincome.getText().toString();
                String incomeTxt = txtincome.getText().toString();
                double income = Double.parseDouble(incomeTxt);

                txtRate = findViewById(R.id.txtRate);
                txtRate.getText().toString();
                String rateTxt = txtRate.getText().toString();
                double rate = Double.parseDouble(rateTxt);

                txtOther = findViewById(R.id.txtOther);
                String otherTxt = txtOther.getText().toString();
                double other = Double.parseDouble(otherTxt);

                double total = income* rate - ((income*rate) * 0.13) + other;

                txtExpenses = findViewById(R.id.txtExpenses);
                String expensesTxt = txtExpenses.getText().toString();
                double expenses = Double.parseDouble(expensesTxt);

                txtGrocery = findViewById(R.id.txtGrocery);
                String groceryTxt = txtGrocery.getText().toString();
                double grocery = Double.parseDouble(groceryTxt);

                txtUtility = findViewById(R.id.txtUtility);
                String utilityTxt = txtUtility.getText().toString();
                double utility = Double.parseDouble(utilityTxt);

                txtVehicle = findViewById(R.id.txtVehicle);
                String vehicleTxt = txtVehicle.getText().toString();
                double vehicle = Double.parseDouble(vehicleTxt);

                txtOtherExp = findViewById(R.id.txtOtherExp);
                String otherExpTxt = txtOtherExp.getText().toString();
                double expensesOther = Double.parseDouble(otherExpTxt);

                double GrandTotalExp = expenses + grocery + utility + vehicle + expensesOther;

                double Overall = total - GrandTotalExp;

                if(Overall < 0){
                   title.setText("Funds you earning is not enough to pay all of your bills: " +  Overall +"$");
                   Description.setText("");
                }else {
                    title.setText("Your monthly clear income is: " +  Overall +"$");
                    Description.setText("");
                }

            }
        });

        Button btnAbout = findViewById(R.id.button_About);
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
            }
        });

        Button btnBack = findViewById(R.id.button_Back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu1();
            }
        });

    }

    public void openMenu(){
        Intent intent = new Intent(this, Pop.class);
        startActivity(intent);
    }

    public void openMenu1(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
