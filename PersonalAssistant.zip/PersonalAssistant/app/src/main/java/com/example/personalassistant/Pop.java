package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.TextView;

public class Pop extends Activity {

    public TextView textView;
    public TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.pop);


        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int) (width*.9),(int) (height*.6));

        textView = findViewById(R.id.textView);
        textView.setText("Welcome to Personal Assistant" + "\n" + "This app will calculate" + "\n" + "your Net Income after" +"\n" + "taxes and your Assets" + "\n" +" and Liabilities");
    }
}
