package com.example.personalassistant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public TextView label1;
    public TextView label2;
    public TextView label3;
    public TextView name;
    public TextView title;
    public EditText txtName;
    public EditText txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        label1 = findViewById(R.id.label1);
        label2 = findViewById(R.id.label2);
        label3 = findViewById(R.id.label3);



        Button buttonStart = findViewById(R.id.button_Start);
        buttonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
                txtName = findViewById(R.id.txtName);
                txtName.getText().toString();
                String name = txtName.getText().toString();

                title = findViewById(R.id.Title);
                title.setText("Personal Assistant for " + name);
            }
        });
    }

    public void openMenu(){
        Intent intent = new Intent(this, Calculate.class);
        startActivity(intent);
    }
}
